<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );

class ApnsViewApns extends JViewLegacy
{

	function display($tpl = null)
	{
		JHtml::_('behavior.framework');
		$this->items = $this->get('Items');
		$this->addToolBar();
		JHtml::stylesheet('com_apns/admin.stylesheet.css', array(), true);
		$this->setDocument();
		parent::display($tpl);
	}

	protected function addToolBar($total=null)
	{
		JToolBarHelper::title( JText::_( 'COM_APNS_MAINTENANCE_MANAGER' ), 'maintenance_manager' );
	}

	function setDocument()
	{
		$document = JFactory::getDocument();
		$document->addStyleDeclaration('.icon-48-maintenance_manager {background-image:
								url(../media/com_apns/images/icon-48-cpanel.png);}');
	}
}