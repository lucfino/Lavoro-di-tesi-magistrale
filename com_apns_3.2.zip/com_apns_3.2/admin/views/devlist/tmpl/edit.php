<?php 

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$task = JRequest::getCmd('task');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

?>

<form action="index.php" method="post" name="adminForm" id="adminForm" class="form-validate" enctype = "multipart/form-data">
    <input type="hidden" name="option" value="<?=$option?>" />
    <input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="id" value="<?=$this->item->id?>" />
    <?php echo JHtml::_('form.token'); ?>
    
    <fieldset class="adminform">
        <legend><?=JText::_( 'COM_APNS_DEVLIST_DETAILS' ); ?></legend>
        <ul class="adminformlist">
<?php    foreach ($this->form->getFieldset() as $field) { ?>
            <li><?=$field->label?><?=$field->input?></li>
<?php    } ?>
        </ul>
    </fieldset>
</form>