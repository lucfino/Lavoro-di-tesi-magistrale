<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class ApnsControllerDevlists extends JControllerAdmin{

    public function getModel($name = 'Devlist', $prefix = 'ApnsModel', $config = array())
    {
        return parent::getModel($name, $prefix, $config);
    }

}