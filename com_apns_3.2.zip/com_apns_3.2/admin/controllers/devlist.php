<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class ApnsControllerDevlist extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'devlists';
		parent::__construct($config);
	}

}