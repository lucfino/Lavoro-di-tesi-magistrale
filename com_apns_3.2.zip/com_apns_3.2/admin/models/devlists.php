<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class ApnsModelDevlists extends JModelList{
    
    public function __construct($config = array())
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array('appName', 'appVersion', 'user', 'devName', 'devModel', 'devSo');
        }
        parent::__construct($config);
    }
    
    function getListQuery()
    {            
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__apns_devlist');
        $query->order($this->getState('list.ordering', 'id') .
                ' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    
}