<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class ApnsViewSendtoall extends JViewLegacy
{

	function display($tpl = null){

		JHtml::_('behavior.framework');
		
		$this->pagination = $this->get('Pagination');
		$this->state = $this->get('State');
		$this->items = $this->get('Items');

		JHtml::stylesheet('com_apns/site.stylesheet.css', array(), true);
		
		parent::display($tpl);
	}

}