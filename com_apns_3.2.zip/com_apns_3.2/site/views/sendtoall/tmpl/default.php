<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

?>

<h1><?= JText::_('COM_APNS_SEND_TO_ALL') ?></h1>

<jdoc:include type="message" />

<form action='index.php' method="post" name="siteForm" id="sendtoallForm">
	<input type="hidden" name="option" value="com_apns" />
	<input type="hidden" name="task" value="send.sendtoall" />

	<textarea class="textAreaSend" name="textArea" rows="10" cols="60">Nuova notifica !</textarea>
	
  <input class="buttonSend" type='submit' value='<?= JText::_('COM_APNS_SEND') ?>'>
</form>

