<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class ApnsViewSend extends JViewLegacy
{

	function display($tpl = null){

		JHtml::_('behavior.framework');

		$model = JModelLegacy::getInstance('Devlists', 'ApnsModel');
		$this->setModel( $model, true );

		$this->pagination = $this->get('Pagination');
		$this->state = $this->get('State');
		$this->items = $this->get('Items');

		JHtml::stylesheet('com_apns/site.stylesheet.css', array(), true);
		
		parent::display($tpl);
	}

}