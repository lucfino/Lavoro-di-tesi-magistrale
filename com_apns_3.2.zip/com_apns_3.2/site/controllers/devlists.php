<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class ApnsControllerDevlists extends JControllerAdmin{

    public function getModel($name = 'Devlists', $prefix = 'ApnsModel', $config = array())
    {
        return parent::getModel($name, $prefix, $config);
    }

    public function addDevice()
    {
        $appName = $_POST['appName'];
        $appVersion = $_POST['appVersion'];
        $pushBadge = $_POST['pushBadge'];
        $pushAlert = $_POST['pushAlert'];
        $pushSound = $_POST['pushSound'];
        $devUid = $_POST['devUid'];
        $devName = $_POST['devName'];
        $devModel = $_POST['devModel'];
        $devSO = $_POST['devSO'];
        $devToken = $_POST['devToken'];
        $user = $_POST['user'];

        $model = $this->getModel('DevLists');
        $model->addDevice($appName, $appVersion, $pushBadge, $pushAlert, $pushSound, 0, $devUid, $devName, $devModel, $devSO, $devToken, $user);
        
        $tmp = array('devlist' => $_POST);
        die(json_encode($tmp));
    }

    public function setUser()
    {
        $user = $_POST['user'];
        $devToken = $_POST['devToken'];

        $model = $this->getModel('DevLists');
        $model->setUser($user, $devToken);

        $tmp = array('devlist' => $_POST);
        die(json_encode($tmp));

    }

    public function resetBadge()
    {
        $devToken = $_POST['devToken'];
        $model = $this->getModel('DevLists');
        $model->updateBadge($devToken, "0");

        $tmp = array('devlist' => $_POST);
        die(json_encode($tmp));
    }

}