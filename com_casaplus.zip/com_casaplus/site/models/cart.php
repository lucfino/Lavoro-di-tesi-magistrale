<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelCart extends JModelList{
    
    function getListQuery()
    {   
        $user = JFactory::getUser();
        if (!$user->guest)
            $username = $user->username; 
        else
            $username = 'casa';

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('c.id, p.id as id_prod, p.nome as nome, p.img_path as img, c.quantita as quantita, p.prezzo');
        $query->from('#__casaplus_cart as c, #__casaplus_product as p');
        $query->where('p.id = c.id_prod AND c.user="'.$username.'"');
        $query->order($this->getState('list.ordering', 'id') .
            ' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    function getAllCartProducts($user)
    {
        $db = JFactory::getDBO();
        $query = "SELECT c.quantita as quantita, c.id_prod as id_prod, p.nome as nome, p.prezzo as prezzo, p.img_path as img_path, cat.nome as categoria FROM #__casaplus_cart as c, #__casaplus_product as p, #__casaplus_product_category as pc, #__casaplus_category as cat WHERE p.id=c.id_prod AND pc.product_id=p.id AND pc.category_id=cat.id AND c.user='".$user."'";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function addProduct($id, $quantita)
    {
        $user = JFactory::getUser();
        $username = $user->username;
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        if (!$user->guest)
            $insert = 'INSERT INTO `#__casaplus_cart`(`id_prod`, `quantita`, `user`) VALUES ('.$id.','.$quantita.',"'.$username.'")';
        else
            $insert = 'INSERT INTO `#__casaplus_cart`(`id_prod`, `quantita`) VALUES ('.$id.','.$quantita.')';
        $db->setQuery($insert);
        $db->query();  
    }

    function addNewProduct($id, $quantita)
    {
        $user = JFactory::getUser();
        $db = JFactory::getDBO();   
        $query = $db->getQuery(true);

        $insert = 'INSERT INTO `#__casaplus_product`(`id`, `nome`, `prezzo`, `pos_id`) VALUES ('.$id.',"",0,19)';
        $db->setQuery($insert);        
        $db->query();

        $insert = 'INSERT INTO `#__casaplus_product_category`(`product_id`, `category_id`) VALUES ('.$id.',41)';
        $db->setQuery($insert);        
        $db->query();

        $username = $user->username;
        if (!$user->guest)
            $insert = 'INSERT INTO `#__casaplus_cart`(`id_prod`, `quantita`, `user`) VALUES ('.$id.','.$quantita.',"'.$username.'")';
        else
            $insert = 'INSERT INTO `#__casaplus_cart`(`id_prod`, `quantita`) VALUES ('.$id.','.$quantita.')';
        $db->setQuery($insert);
        $db->query();  
    }

    function updateProduct($id, $quantita)
    {
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->update($db->quoteName('#__casaplus_cart'))->set('quantita="'.$quantita.'"')->where('id_prod='.$id);
        $db->setQuery($query);
        $db->query();  
    }

    function updateNameProduct($id, $name)
    {
        $db = JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->update($db->quoteName('#__casaplus_product'))->set('nome="'.$name.'"')->where('id='.$id);
        $db->setQuery($query);
        $db->query();  
        die(var_dump($db));
    }

    function removeProduct($id)
    {
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_cart'));   
        $query->where('id_prod='.$id);             
        $db->setQuery($query);
        $db->query();  
    }

    function removeNewProduct($id)
    {
        $db = JFactory::getDBO();   
        $query = $db->getQuery(true);

        $query->delete($db->nameQuote('#__casaplus_cart'));   
        $query->where('id_prod='.$id);             
        $db->setQuery($query);
        $db->query();  

        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_product'));   
        $query->where('id='.$id);             
        $db->setQuery($query);
        $db->query();

        die(var_dump($db));
    }
    
}


