<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelStores extends JModelList{

    function getAllStores()
    {
        $db = JFactory::getDBO();
        $query = "SELECT * FROM #__casaplus_store as s, #__casaplus_product_store as ps WHERE s.id=ps.store_id ORDER BY ps.product_id";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    
}


