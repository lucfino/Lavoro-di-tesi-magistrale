<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelSteps extends JModelList{
	
	public function __construct($config = array()){
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array('id');
		}
		parent::__construct($config);
	}

    function getRecipeSteps()
    {
        $db = JFactory::getDBO();
        $query = "SELECT * FROM #__casaplus_step WHERE id_ricetta=".$_POST['id']." ORDER BY posizione";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function getRecipeStepsById($id)
    {
        $db = JFactory::getDBO();
        $query = "SELECT * FROM #__casaplus_step WHERE id_ricetta=".$id;
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }
    
}