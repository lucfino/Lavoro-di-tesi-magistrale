<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelProducts extends JModelList{
    
    function getListQuery(){    

        $prezzo = JRequest::getVar('prezzo');
        switch ($prezzo) {
            case '0.01':
                $p = '0';
                break;
            case '0.02':
                $p = '0.01';
                break;
            case '0.05':
                $p = '0.02';
                break;
            case '0.10':
                $p = '0.05';
                break;
            case '0.20':
                $p = '0.10';
                break;
            case '0.50':
                $p = '0.20';
                break;
            case '1':
                $p = '0.50';
                break;
            case '2':
                $p = '1';
                break;
            case '5':
                $p = '2';
                break;
            case '10':
                $p = '5';
                break;
            case '20':
                $p = '10';
                break;
            case '50':
                $p = '20';
                break;
            case '100':
                $p = '50';
                break;
            case '200':
                $p = '100';
                break;
            case '500':
                $p = '200';
                break;
            default:
                $p = '-1';
                $prezzo = '10000';
        }

        // Create a new query object.           
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        // Select some fields
        $query->select('p1.id as id, p1.nome as nome, p2.nome as posizione, p1.quantita as quantita, p1.img_path as img, p1.prezzo as prezzo, p1.timestamp');
        // From 
        $query->from('#__casaplus_product AS p1, #__casaplus_position AS p2');
        // Where
        $query->where('p1.pos_id = p2.id AND p1.prezzo > '.$p.' AND p1.prezzo <= '.$prezzo);
        // Order by
        $query->order($this->getState('list.ordering', 'prezzo') .
                ' ' . $this->getState('list.direction', 'DESC'));
        return $query;
    }

    protected function populateState($ordering = null, $direction = null)
    {
        $this->setState('list.limit', 0);
    }    

    function getAllProducts(){
        $db = JFactory::getDBO();
        $query = "SELECT p1.id, p1.nome as nome, p2.nome as posizione, p1.quantita as quantita, p1.img_path as img, p1.prezzo as prezzo, c.nome as categoria, p1.timestamp FROM #__casaplus_product AS p1, #__casaplus_position AS p2, #__casaplus_category AS c, #__casaplus_product_category AS pc WHERE pc.category_id = c.id AND p1.pos_id = p2.id AND p1.id = pc.product_id AND p1.id > 0";
        $db->setQuery($query); 
        $tmp1 = $db->loadObjectList();

        $query = "SELECT p1.id, p1.nome as nome, p2.nome as posizione, p1.quantita as quantita, p1.img_path as img, p1.prezzo as prezzo, c.nome as categoria, p1.timestamp FROM #__casaplus_product AS p1, #__casaplus_position AS p2, #__casaplus_category AS c, #__casaplus_product_category AS pc, #__casaplus_cart as c1 WHERE user='admin' AND c1.id_prod = p1.id AND pc.category_id = c.id AND p1.pos_id = p2.id AND p1.id = pc.product_id";
        $db->setQuery($query); 
        $tmp2 = $db->loadObjectList();
        
        $results = array_merge($tmp1, $tmp2);

        return $results;
    }

    function getListCategory(){
        $db = JFactory::getDBO();
        $query = "SELECT p.id, c.nome as nome, c.id as catid FROM #__casaplus_product as p, #__casaplus_product_category as pc, #__casaplus_category as c WHERE p.id = pc.product_id AND c.id = pc.category_id";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;

    }

    function getAllCategory(){
        $db = JFactory::getDBO();
        $query = "SELECT * FROM #__casaplus_category";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

}