<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelRecipes extends JModelList{
	
	public function __construct($config = array()){
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array('nome');
		}
		parent::__construct($config);
	}
	
	function getListQuery()
    {	          
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('id, Nome, Descrizione, img, calorie, difficolta, persone');
        $query->from('#__casaplus_recipe');
        $query->where('categoria = '.$_GET['cat']);
        $query->order($this->getState('list.ordering', 'id') .
        		' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    function getRecipeDetails()
    {
        $db = JFactory::getDBO();
        $query = "SELECT * FROM #__casaplus_recipe WHERE id=".$_GET['id'];
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results[0];
    }


    function getAllRecipes()
    {
        $db = JFactory::getDBO();
        $query = "SELECT r.id as recipe_id, r.Nome, r.img as recipe_img, r.calorie, r.difficolta, r.persone, r.Descrizione as descrizione, r.enabled, cr.nome, cr.ordine, cr.img FROM #__casaplus_recipe as r, #__casaplus_category_recipe as cr WHERE cr.id = r.categoria";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }
    
}