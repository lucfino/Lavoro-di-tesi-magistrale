<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelIngredients extends JModelList{
    
    public function __construct($config = array()){
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array('id');
        }
        parent::__construct($config);
    }

    function getRecipeIngredients()
    {
        $db = JFactory::getDBO();
        $query = "SELECT p.id, p.nome, i.quantita, p.img_path FROM #__casaplus_ingredients AS i, #__casaplus_product AS p WHERE i.id_prod=p.id AND i.id_ricetta=".$_GET['id'];
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function getRecipeIngredientsById($id)
    {
        $db = JFactory::getDBO();
        $query = "SELECT p.id, p.nome, c.nome as nomeCat, i.quantita, p.img_path FROM #__casaplus_ingredients AS i, #__casaplus_product AS p, #__casaplus_category AS c, #__casaplus_product_category AS pc WHERE i.id_prod=p.id AND pc.product_id=p.id AND pc.category_id=c.id AND i.id_ricetta=".$id;
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }
    
}