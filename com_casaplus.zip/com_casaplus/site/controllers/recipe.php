<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerRecipe extends JControllerAdmin{

    public function getModel($name = 'Recipes', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }

    public function get_recipe()
    {
        $model = $this->getModel('Recipes');
        $data = $model->getAllRecipes();
        $tmp = array('recipe' => $data);
        die(json_encode($tmp));
    }

    public function get_ingredient()
    {
        $model = $this->getModel('Ingredients');
        $id = $_GET['id'];
        $data = $model->getRecipeIngredientsById($id);
        $tmp = array('ingredients' => $data);
        die(json_encode($tmp));
    }

    public function get_tools()
    {
        $model = $this->getModel('Tools');
        $id = $_GET['id'];
        $data = $model->getRecipeToolsById($id);
        $tmp = array('tools' => $data);
        die(json_encode($tmp));
    }

    public function get_steps()
    {
        $model = $this->getModel('Steps');
        $id = $_GET['id'];
        $data = $model->getRecipeStepsById($id);
        $tmp = array('steps' => $data);
        die(json_encode($tmp));
    }


}