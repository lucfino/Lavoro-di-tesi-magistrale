<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerProducts extends JControllerAdmin{

    public function getModel($name = 'Product', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }

    public function get_product()
    {
        $model = $this->getModel('Products');
        $data = $model->getAllProducts();
        $tmp = array('products' => $data);
        die(json_encode($tmp));
    }

}