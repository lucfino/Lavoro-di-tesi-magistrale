<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerCategories extends JControllerAdmin{

    public function getModel($name = 'Category', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }

    public function get_category()
    {
    	$model = $this->getModel('Categories');
		$data = $model->getAllCategories();
        $tmp = array('categories' => $data);
		die(json_encode($tmp));
    }
    
}