 <?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');
 
class CasaplusControllerLogin extends JController
{
	public function do_login() 
	{
   		$app = JFactory::getApplication();
		$jinput = $app->input;

		$credentials['username'] = $jinput->get('username', 'nome_utente', null);
		$credentials['password'] =  $jinput->get('passwd', 'password', null);

		$app->login($credentials);
		$user = JFactory::getUser();

		if($user->id) 
		{
			$data = array("logged" => true , "id" => $user->id, "password" => $user->password, "username" => $user->username , "name" => $user->name,  "email" => $user->email );
			$document = JFactory::getDocument();
			$document->setMimeEncoding('application/json');
		}
		else 
		{
			$data = array("logged" => false);
			$document = JFactory::getDocument();
			$document->setMimeEncoding('application/json');
		}
		
		die(json_encode($data));
	}
}