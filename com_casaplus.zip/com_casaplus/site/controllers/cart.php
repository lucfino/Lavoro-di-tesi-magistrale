<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerCart extends JControllerAdmin{

    public function getModel($name = 'Cart', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }

    public function get_cart()
    {
        $model = $this->getModel('Cart');
        $user = $_GET['username'];
        $data = $model->getAllCartProducts($user);
        $tmp = array('cart' => $data);
        die(json_encode($tmp));
    }

    public function add_products()
    {
        $products = $_GET['prodotti'];
        $recipe = $_GET['recipe'];
        $tmp = explode(";", $products);
        $model = $this->getModel('Cart');
        foreach ($tmp as $id) {
            $model->addProduct($id, '0');
        }
        echo "<script type='text/javascript'>if(!confirm('Ingredienti aggiunti al carrello! Vuoi visualizzarlo ora?')) document.location='index.php/component/casaplus/?task=dettagli&id=".$recipe."'; else document.location='index.php/component/casaplus/?task=carrello';</script>";
    }

    public function addProduct()
    {
        $id = JRequest::getVar('id');
        $quantita = JRequest::getVar('quantita');
        $model = $this->getModel('Cart');
        $model->addProduct($id, $quantita);
    }

    public function addNewProduct()
    {
        $id = JRequest::getVar('id');
        $quantita = JRequest::getVar('quantita');
        $model = $this->getModel('Cart');
        $model->addNewProduct($id, $quantita);
    }

    public function removeProduct()
    {
        $id = JRequest::getVar('id');
        $model = $this->getModel('Cart');
        $model->removeProduct($id);
    }

    public function removeNewProduct()
    {
        $id = JRequest::getVar('id');
        $model = $this->getModel('Cart');
        $model->removeNewProduct($id);
    }

    public function updateProduct()
    {
        $id = JRequest::getVar('id');
        $quantita = JRequest::getVar('quantita');
        $model = $this->getModel('Cart');
        $model->updateProduct($id, $quantita);
    }

    public function updateNameProduct()
    {
        $id = JRequest::getVar('id');
        $name = JRequest::getVar('name');
        $model = $this->getModel('Cart');
        $model->updateNameProduct($id, $name);
    }

}