<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerStore extends JControllerAdmin{

    public function getModel($name = 'Stores', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }

    public function get_store()
    {
        $model = $this->getModel();
        $data = $model->getAllStores();
        $tmp = array('stores' => $data);
        die(json_encode($tmp));
    }

}