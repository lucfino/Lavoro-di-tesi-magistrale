<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');


class CasaplusController extends JController{

	public function step($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Ricettario'));
		$view=$this->getView('Ricettario','html');
		$model = $this->getModel('Steps');
		$view->setModel($model, true);
		$view->displaySteps();
	}

	public function ricettario($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Ricettario'));
		$view=$this->getView('Ricettario','html');
		$model = $this->getModel('Categoriesrecipe');
		$view->setModel($model, true);
		$view->display();
	}

	public function ricette($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Ricettario'));
		$view=$this->getView('Ricettario','html');
		$model = $this->getModel('Recipes');
		$view->setModel($model, true);
		$view->displayRecipe();
	}

	public function dettagli($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Ricettario'));
		$view=$this->getView('Ricettario','html');
		$model = $this->getModel('Recipes');
		$modelIngredients = $this->getModel('Ingredients');
		$view->setModel($model, true);
		$view->setModel($modelIngredients);
		$view->displayRecipeDetails();
	}

	public function carrello($cachable = false){
		$user = JFactory::getUser();
        if (!$user->guest){
            $username = $user->username;
            $msg = 'Lista della spesa: La lista remota è stata modificata';
			$URL = JURI::base()."index.php?option=com_apns&task=send.do_sendByUser&textArea=".urlencode($msg)."&user=".$username;
			$db = JFactory::getDbo();
			$db->setQuery("SELECT enabled FROM #__extensions WHERE name = 'apns'");
			$is_enabled = $db->loadResult();
			if ($is_enabled){
   				$data = file_get_contents($URL);
			}
		}
		JRequest::setVar('view', JRequest::getCmd('view', 'Spesa'));
		$view=$this->getView('Spesa','html');
		$model = $this->getModel('Cart');
		$view->setModel($model, true);
		$view->displayCart();
	}

	public function listaSpesa($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Spesa'));
		$view=$this->getView('Spesa','html');
		$model = $this->getModel('Products');
		$modelCart = $this->getModel('Cart');
		$view->setModel($model, true);
		$view->setModel($modelCart);
		$view->display();
	}

	public function orologio($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Orologio'));
		$view=$this->getView('Orologio','html');
		$view->display();
	}
	
	public function euro($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Euro'));
		$view=$this->getView('Euro','html');
		$view->display();
	}

	public function listaEuro($cachable = false){
		$result = JFactory::getApplication()->input->get('prezzo');
		$type = JFactory::getApplication()->input->get('type');
		JRequest::setVar('prezzo', $result);
		$view=$this->getView('Euro','html');
		$model = $this->getModel('Products');
		$view->setModel($model, true);
		$view->listaEuro($type);
	}

	public function display($cachable = false, $urlparams = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Casaplus'));
		parent::display($cachable);
	}
	
}