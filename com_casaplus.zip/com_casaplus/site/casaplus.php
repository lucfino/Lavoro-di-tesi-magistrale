<?php

defined('_JEXEC') or die('Restricted access');
Jimport('joomla.application.component.controller');

$controller = JController::getInstance('Casaplus');     				
$input = JFactory::getApplication()->input;
$controller->execute($input->getCmd('task'));
$controller->redirect();