<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );

class CasaplusViewRicettario extends JView
{
	function display($tpl = null){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);

		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		
		parent::display($tpl);
	}

	function displayRecipe($tpl = null){

		JHtml::_('behavior.framework'); 
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);

		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		
		parent::display('recipe');
	}

	function displayRecipeDetails($tpl = null){

		JHtml::_('behavior.framework'); 
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);

		$this->item = $this->get('RecipeDetails');
		$this->ingredients = $this->get('RecipeIngredients', 'Ingredients');
	
		parent::display('recipedetails');
	}

	function displaySteps($tpl = null){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);

		$this->items = $this->get('RecipeSteps');
	
		parent::display('steps');
	}

}