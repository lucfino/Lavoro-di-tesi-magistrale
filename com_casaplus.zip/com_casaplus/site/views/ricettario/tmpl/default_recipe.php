<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');

?>

<form action="index.php" method="post" name="siteForm" id="recipeCategoryForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

    <h1><?=JText::_('COM_CASAPLUS_RICETTARIO_SELECT_RECIPE')?></h1>
   
	<div id="editcell">
		<table id="list_recipe" class="sitelist">

			<thead>
				<tr>
					<th><?=JText::_('COM_CASAPLUS_RECIPE_IMG')?></th>	
					<th width="50%"><?=JText::_('COM_CASAPLUS_RECIPE_NAME')?></th>	
					<th width="50%"><?=JText::_('COM_CASAPLUS_RECIPE_PERSON')?></th>
				</tr>
			</thead>

			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){
?>
					<tr class="row<?=$k?>" onclick="document.location='<?php echo JRoute::_("index.php?option=com_casaplus&task=dettagli&id=$row->id"); ?>'" onmouseover="this.style.cursor='pointer'">
						
							<td><img class="default-img-lista" src="./media/com_casaplus/images/<?=$row->img?>"></td>
							<td><?=strtoupper($row->Nome)?></td>
							<td><?=strtoupper($row->persone)?></td>
					</tr>
			
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>

</form>
