<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$items = $this->items;
$nome = $_POST['ric'];

$document = JFactory::getDocument();
$document->addScript(JURI::base() . './media/com_casaplus/js/ricettario.js');
$document->addScript(JURI::base() . './media/com_casaplus/js/meSpeak.js');

?>

<form action="index.php" method="post" name="siteForm" id="recipeCategoryForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	<h1><?=strtoupper($nome)?> : <?=JText::_('COM_CASAPLUS_STEP_DA_SEGUIRE')?></h1>

	<div id="editcell">
			<table class="noborder">

				<thead>
					<tr class="hidden">
						<th><?=JText::_('COM_CASAPLUS_STEP_POSITION')?></th>	
						<th><?=JText::_('COM_CASAPLUS_STEP_IMG')?></th>	
						<th width="100%"><?=JText::_('COM_CASAPLUS_STEP_DESC')?></th>
						<th width="50%"><?=JText::_('COM_CASAPLUS_STEP_TIMER')?></th>
						<th><?=JText::_('COM_CASAPLUS_STEP_START')?></th>
					</tr>
				</thead>

				<tbody class="noborder">
<?
				$k = 1;
				$max = count($items)-1;
				foreach ($items as &$row){
					$h = (int)($row->tempo / 3600);
					$m = (int)(($row->tempo - $h*3600) / 60);
					$s = (int)($row->tempo - $h*3600 - $m*60);
					$t = (($h)?(($h<10)?("0".$h):$h):"00").":".(($m)?(($m<10)?("0".$m):$m):"00").":".(($s)?(($s<10)?("0".$s):$s):"00");
					if ($row->posizione == 1)
						echo '<tr style="border:none;border:inset;" id="'.$row->id.'">';
					else 
						echo '<tr id="'.$row->id.'" style="display:none;border:inset;">';
?>
						<td><?=strtoupper($row->posizione)?> di <?=count($items)?></td>
						<td style="border-right:transparent;">
							<img class="default-img-step" src="./media/com_casaplus/images/<?=$row->img?>">
						</td>
						<td id="desc<?=$row->id?>" style="font-size:22px;border-left:transparent;">
							<?=strtoupper($row->descrizione)?>
						</td>
						<td id="vis<?=$row->id?>" style="font-size:20px;border-right:transparent;"><? if ($row->tempo == 0) echo "00:00:00"; else echo $t;?></td>
						<td id="timer" style="border-left:transparent;">
							<img id="start<?=$row->id?>" onmouseover="this.style.cursor='pointer'" onclick="startTimer('<?=$row->timer?>', '<?=$row->id?>', '<?=$row->tempo?>', '<?=$items[$k]->id?>', '<?=$items[$max]->id?>')" src="./media/com_casaplus/images/play.png">
							<img id="pause<?=$row->id?>" onmouseover="this.style.cursor='pointer'" onclick="pauseTimer('<?=$row->id?>')" style="display:none;" src="./media/com_casaplus/images/pause.png">
							<img id="restart<?=$row->id?>" onmouseover="this.style.cursor='pointer'" onclick="restartTimer('<?=$row->id?>', '<?=$row->tempo?>', '<?=$items[$k]->id?>', '<?=$items[$max]->id?>', '<?=$row->tempo?>')" style="display:none;" src="./media/com_casaplus/images/play.png">
							<img id="stop<?=$row->id?>" onmouseover="this.style.cursor='pointer'" onclick="stopTimer('<?=$row->id?>', '<?=$items[$k]->id?>', '<?=$items[$max]->id?>', '<?=$row->timer?>', '<?=$row->tempo?>')" style="display:none;" src="./media/com_casaplus/images/stop.png">
						</td>		
					</tr>
<?
					if ($row->posizione == 1)
						echo '<tr style="border:inset;" id="foot'.$row->id.'" ><td style="border-right:transparent;" colspan="2"><div id = "prev'.$row->id.'" style="visibility:hidden"><img src="./media/com_casaplus/images/forward-2-1.png" width="50"><div>INDIETRO</div></td>';
					else
						echo '<tr id="foot'.$row->id.'" style="display:none;border:inset;"><td style="border-right:transparent;" colspan="2" onclick="prev('.$row->id.', '.$items[$k-2]->id.','.$items[0]->id.','.$row->timer.','.$row->tempo.')" ><div id = "prev'.$row->id.'"><img src="./media/com_casaplus/images/back-2-1.png" width="50"><div>INDIETRO</div></td>';
?>
						<td style="border-left:transparent;border-right:transparent;"><div id="audio"><img onmouseover="this.style.cursor='pointer'" onclick="parla('<?=$row->id?>');" src="./media/com_casaplus/images/loudspeaker.png" width="70"></div></td>
						<td style="border-left:transparent;" id = "nextF<?=$row->id?>" colspan="2" onclick="next('<?=$row->id?>', '<?=$items[$k]->id?>', '<?=$items[$max]->id?>', '<?=$row->timer?>', '<?=$row->tempo?>')"><div id = "next<?=$row->id?>"><img id = "imgNextF<?=$row->id?>" src="./media/com_casaplus/images/forward-2-1.png" width="50"><div>AVANTI</div></td>	
					</tr>
					
<?
				$k++;
				}
?>
				</tbody>
			</table>

	</div>

</form>
