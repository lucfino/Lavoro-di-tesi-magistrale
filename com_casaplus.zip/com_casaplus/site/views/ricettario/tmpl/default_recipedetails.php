<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$item = $this->item;

$ingredients = $this->ingredients;
$prodotti = "";
for ($i=0; $i < count($ingredients); $i++) { 
	$prodotti .= $ingredients[$i]->id;
	$prodotti .= ";";
}

?>

<form action="index.php" method="post" name="siteForm" id="recipeCategoryForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="step" />
	<input type="hidden" name="id" value="<?=$item->id?>" />
	<input type="hidden" name="ric" value="<?=$item->Nome?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	<h1><?=strtoupper($item->Nome)?> per <?=$item->persone?> persone
		<a id="lista-carrello" onclick="document.getElementById('recipeCategoryForm').submit(); return false;" href="index.php?option=com_casaplus&task=step&id=<?=$item->id?>&ric=<?=$item->Nome?>">
	   		<img src="./media/com_casaplus/images/start.png" height="30" width="30">
	   	</a>
	   	<div id="iniziamo"><?=JText::_('COM_CASAPLUS_RECIPE_START')?></div>
	</h1>

	<div id="editcell">
		<table id="recipe_datail" class="sitelist">

			<thead>
				<tr>
					<th width="50%"><?=JText::_('COM_CASAPLUS_RECIPE_DIFFICULT')?></th>	
					<th width="50%"><?=JText::_('COM_CASAPLUS_RECIPE_CALORY')?></th>	
				</tr>
			</thead>

			<tbody>
				<tr>
					<td>
				<?
					if ($item->difficolta == 'Facile')
						echo '<img src="./media/com_casaplus/images/chef_h.png">';	
					if ($item->difficolta == 'Media')
						echo '<img src="./media/com_casaplus/images/chef_h.png"><img src="./media/com_casaplus/images/chef_h.png">';	
					if ($item->difficolta == 'Difficile')
						echo '<img src="./media/com_casaplus/images/chef_h.png"><img src="./media/com_casaplus/images/chef_h.png"><img src="./media/com_casaplus/images/chef_h.png">';	
				?>
					</td>
				<?
					if ($item->calorie == 'Magro')
						echo '<td><img src="./media/com_casaplus/images/magro1.png"></th>';
					else if ($item->calorie == 'Grasso')
						echo '<td><img src="./media/com_casaplus/images/grasso.png"></th>';
			 	?>
				</tr>
			</tbody>

		</table>

		<button onmouseover="this.style.cursor='pointer'" class="under-button" type="submit"><?=JText::_('COM_CASAPLUS_RECIPE_START1')?></button>

		<h1 id="h1lista"><?=JText::_('COM_CASAPLUS_RECIPE_INGREDIENTS_LIST')?> 
			<a id="lista-carrello" href="index.php?option=com_casaplus&task=cart.add_products&prodotti=<?=$prodotti?>&recipe=<?=$item->id?>">
				<img src="./media/com_casaplus/images/remotecart.png" height="30" width="30">
			</a>
			<div id="aggiungi-carrello"><?=JText::_('COM_CASAPLUS_RECIPE_CREA_LISTA')?> </div>
		</h1>

		<table>

			<thead>
				<tr class="hidden">
					<th><?=JText::_('COM_CASAPLUS_RECIPE_IMG')?></th>	
					<th width="50%"><?=JText::_('COM_CASAPLUS_RECIPE_NAME')?></th>	
					<th width="50%"><?=JText::_('COM_CASAPLUS_PRODUCT_QUANTITY')?></th>
				</tr>
			</thead>

			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($ingredients as &$row){
?>
					<tr class="row<?=$k?>">
						<td><img class="default-img-lista" src="./media/com_casaplus/images/<?=$row->img_path?>"></td>
						<td><?=strtoupper($row->nome)?></td>
						<td><?=strtoupper($row->quantita)?></td>	
					</tr>
			
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>

	</div> 

</form>

<button onmouseover="this.style.cursor='pointer'" class="under-button" onclick="document.location.href = 'index.php?option=com_casaplus&task=cart.add_products&prodotti=<?=$prodotti?>&recipe=<?=$item->id?>';"><?=JText::_('COM_CASAPLUS_RECIPE_CREA_LISTA1')?></button>
