<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

?>

<h1>Menù generale</h1>
		
<span class="casaplus-inner-icon" style="padding:70px">
	<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=euro"); ?>">
		<img src="./media/com_casaplus/images/euro.png" alt="" height="250px">
	</a>
</span>
	
<span class="casaplus-inner-icon" style="padding:70px">
	<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=orologio"); ?>">
		<img src="./media/com_casaplus/images/Orologio.png" alt="" height="250px">
	</a>
</span>
	
<div class="casaplus-icon"></div>

<span class="casaplus-inner-icon" style="padding:70px">
	<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaSpesa"); ?>">
		<img src="./media/com_casaplus/images/busta-lista.png" alt="" height="250px">
	</a>
</span>
		
<span class="casaplus-inner-icon" style="padding:70px">
	<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=ricettario"); ?>">
		<img src="./media/com_casaplus/images/ricette_sm1.png" alt="" height="250px" style="position:relative;left:-30px">
	</a>
</span>

