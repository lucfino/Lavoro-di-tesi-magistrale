<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );

class CasaplusViewOrologio extends JView
{
	function display($tpl = null){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);

		parent::display($tpl);
	}
}