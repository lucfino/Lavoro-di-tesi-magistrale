<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$document = JFactory::getDocument();
$document->addScript(JURI::base() . './media/com_casaplus/js/coolclock.js');
$document->addScript(JURI::base() . './media/com_casaplus/js/clock.js');
$document->addScript(JURI::base() . './media/com_casaplus/js/mespeak.js');

?>

<h1><span><?=JText::_('COM_CASAPLUS_OROLOGIO')?></span>
	<span id="altri-sfondi"><?=JText::_('COM_CASAPLUS_OROLOGIO_SFONDI')?>
		<select id="clock_backgrounds">
		  	<option value="0"><?=JText::_('COM_CASAPLUS_OROLOGIO_S0')?></option>
		    <option value="1"><?=JText::_('COM_CASAPLUS_OROLOGIO_S1')?></option>
		    <option value="2"><?=JText::_('COM_CASAPLUS_OROLOGIO_S2')?></option>
		    <option value="3"><?=JText::_('COM_CASAPLUS_OROLOGIO_S3')?></option>
		    <option value="4"><?=JText::_('COM_CASAPLUS_OROLOGIO_S4')?></option>
		    <option value="5"><?=JText::_('COM_CASAPLUS_OROLOGIO_S5')?></option>
		    <option value="6"><?=JText::_('COM_CASAPLUS_OROLOGIO_S6')?></option>
		    <option value="7"><?=JText::_('COM_CASAPLUS_OROLOGIO_S7')?></option>
		    <option value="8"><?=JText::_('COM_CASAPLUS_OROLOGIO_S8')?></option>
		    <option value="9"><?=JText::_('COM_CASAPLUS_OROLOGIO_S9')?></option>
		</select>
	</span>
</h1>

<div id="orologio-general">

	<canvas id="wewood" class="CoolClock:wewood300:200"></canvas>

	<div id="digital">
		<h2 id="digital-text"><?=JText::_('COM_CASAPLUS_OROLOGIO_ONOFF')?></h2>
		<img onmouseover="this.style.cursor='pointer'" id ="current_time_img" src="./media/com_casaplus/images/digital-clock.png" width="300px">
			<div onmouseover="this.style.cursor='pointer'" id ="current_time"></div>
		</img>
	</div>

</div>

<img onmouseover="this.style.cursor='pointer'" id="parla_orologio" onclick="parla();" src="./media/com_casaplus/images/loudspeaker.png" width="70">

