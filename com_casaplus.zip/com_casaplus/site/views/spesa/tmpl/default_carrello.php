<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$document = JFactory::getDocument();
$document->addScript(JURI::base() . './media/com_casaplus/js/carrello.js');
$document->addScript(JURI::base() . './media/com_casaplus/js/jquery-2.0.3.min.js');

$rowCount = 1;
$prezzo = 0;

?>

	<h1>
		<a id="lista-carrello" onclick="printTable('<?=count($this->items)?>');">
	   		<img src="./media/com_casaplus/images/print.png" height="30" width="30">
	   	</a>
		<div id="aggiungi-carrello"><?=JText::_('COM_CASAPLUS_PRINT')?></div>
		<?=JText::_('COM_CASAPLUS_CART')?>
	</h1>
   
	<div id="editcell">
		<table id="printTable" class="shoplist">

			<thead id="thead<?=$index?>">
				<tr>
					<th width="1%"><input id="checkAll" type="checkbox" name="checkAll" onclick="checkAll(this, '<?=count($this->items)?>')";></th>
					<th width="33%"><?=JText::_('COM_CASAPLUS_PRODUCT_IMG_PATH')?></th>	
					<th width="33%"><?=JText::_('COM_CASAPLUS_PRODUCT')?></th>
					<th width="33%"><?=JText::_('COM_CASAPLUS_PRODUCT_QUANTITY')?></th>
				</tr>
			</thead>

			<tbody id="tbody<?=$index?>">
<?				
				$i = 0;
				$k = 0;
				foreach ($this->items as &$row){
					$prezzo = $prezzo + $row->prezzo;
?>	
						<tr class="row<?=$k?>">
							<td>
								<input type="checkbox" name="checkDev" onclick="seleziona('<?=$rowCount?>');">
							</td>
							<td><img class="default-img-lista" src="./media/com_casaplus/images/<?=$row->img?>"></td>
							<td><?=strtoupper($row->nome)?></td>
							<td><?=$row->quantita?></td>
						</tr>
<?
					$k = 1 - $k;
					$rowCount++;
				}
?>
			
			</tbody> 
<?
	if ($prezzo != 0){
		$prezzo = floor($prezzo) +5 - ($prezzo % 5);
?>
			<tfoot>
				<tr>
					<th colspan="4" style="height:50px;text-align:center;font-size:20px">Spenderai circa <?=$prezzo?> €</th>
				</tr>
			</tfoot>
<? } ?>
		</table>

		<button class="under-button" onmouseover="this.style.cursor='pointer'" onclick="printTable('<?=count($this->items)?>');" ><?=JText::_('COM_CASAPLUS_PRINT1')?></button>

	</div>