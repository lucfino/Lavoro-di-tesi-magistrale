<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$categorie = $this->get('ListCategory');
$cat = $this->get('AllCategory');

$arraycat = array();
$in = 0;
foreach ($categorie as &$cate) {
	$arraycat[$cate->catid][$in] = $cate->id;
	$in++;
}
setcookie("num_cat", count($cat)-1);
setcookie("count", count($this->cartItems));

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');

$document = JFactory::getDocument();
$document->addScript(JURI::base() . './media/com_casaplus/js/spesa.js');
$document->addScript(JURI::base() . './media/com_casaplus/js/jquery-2.0.3.min.js');

?>

<form action="index.php" method="post" name="siteForm" id="cartForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="carrello" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	 <h1><?=JText::_('COM_CASAPLUS_CART')?>
	 	<? if (count($this->cartItems) != 0){  ?>
	   		<a id="lista-carrello" onclick="document.getElementById('cartForm').submit(); return false;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=carrello"); ?>">
	   	<? }else{ ?>
	   		<a id="lista-carrello" style="visibility:hidden" onclick="document.getElementById('cartForm').submit(); return false;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=carrello"); ?>">
	   	<? } ?>
	   		<img src="./media/com_casaplus/images/remotecart.png" height="30" width="30">
	   	</a>
		<div id="aggiungi-carrello"><?=JText::_('COM_CASAPLUS_CREATE_CART')?></div>
	</h1>
   
	<div id="editcell">

	<table class="shoplist">
	
<?
		if (count($this->cartItems) == 0)
			echo '<thead id="theadcart" class="hidden">';
		else
			echo '<thead id="theadcart">';
?>
				<tr>
					<th width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT_IMG_PATH')?></th>	
					<th width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT')?></th>
					<th width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT_QUANTITY')?></th>
					<th width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT_DELETE')?></th>
				</tr>
			</thead>

			<tbody id="tbodycart">
<?
		$k = 0;
		foreach ($this->cartItems as &$row){
?>
			
				<tr id= "cart<?=$row->id_prod?>" class="row<?=$k?>">
					<td><img class="default-img-lista" src="./media/com_casaplus/images/<?=$row->img?>"></td>
					<? if($row->id_prod > 0){ ?>
						<td><?=strtoupper($row->nome)?></td>
					<? }else{ ?>
						<td><input onblur="nameChange(this)" id="nome<?=$row->id_prod?>" type="text" name="nome" value="<?=strtoupper($row->nome)?>"></td>
					<? } ?>
					<td><input onblur="quantityChange(this)" id="quantita<?=$row->id_prod?>" type="text" name="quantita" value="<?=$row->quantita?>"></td>
					<td id="elimina<?=$row->id_prod?>" onclick="removeFromCart(this)"><img onmouseover="this.style.cursor='pointer'" height="100" width="100" src="./media/com_casaplus/images/cestino.png"></td>
				</tr>

<?
			$k = 1 - $k;
		}
?>
			</tbody> 
		

	</table>

	<? if (count($this->cartItems) != 0){  ?>
		<button id="crea-lista-button" onmouseover="this.style.cursor='pointer'" class="under-button"><?=JText::_('COM_CASAPLUS_CREATE_CART1')?></button>
	<? }else{ ?>
		<button id="crea-lista-button" onmouseover="this.style.cursor='pointer'" class="under-button" style="visibility:hidden"><?=JText::_('COM_CASAPLUS_CREATE_CART1')?></button>
	<? } ?>

	<div id="lista-all-products"><h1 id="h1-lista-all-products"><?=JText::_('COM_CASAPLUS_ALL_PRODUCTS')?></h1></div>

	<table class="shoplist">

<?	$index = 0;	
	foreach ($cat as &$c){  
		if($c->id != 41) {
?>

			<thead id="thead<?=$index?>">
				<tr class="shoptr">
					<th width="25%"><img class="default-img-lista" src="./media/com_casaplus/images/<?=$c->img?>"></th>	
					<th colspan="1" width="25%"><?=$c->nome?></th>
					<th colspan="1" width="25%"><img id="arrow<?=$index?>" style="float:right;position:relative;left:-30px;" height="30" width="30" src="./media/com_casaplus/images/down-arrow-icon.png"></th>
				</tr>
			</thead>

			<tbody id="tbody<?=$index?>" style="display:none;">
<?				
				$i = 0;
				$k = 0;
				foreach ($this->items as &$row){
            		if (isset($arraycat[$c->id]) && in_array($row->id, $arraycat[$c->id])) {  
            			$exist = 0;
            			$tmp = 0;
						foreach ($this->cartItems as &$rowCart){
							if ($rowCart->id_prod == $row->id){
								$tmp++;
								$exist = 1;
								break;
							}
							$tmp++;
						}
?>						
<?						if ($exist){
							echo '<tr id="'.$row->id.'" style="background-color:green">';
						}else{
							$click = "changeIt(this, '$row->img', '".strtoupper($row->nome)."', '$row->id')";
							echo '<tr id="'.$row->id.'" onclick="'.$click.'">';
						}
?>
							<td class="shoptd"><img class="default-img-lista" src="./media/com_casaplus/images/<?=$row->img?>"></td>
							<td class="shoptd"><?=strtoupper($row->nome)?></td>
							<td class="shoptd"><?=$row->prezzo?> €</td>
						</tr>
<?
					}
					$k = 1 - $k;
				}
?>
			
			</tbody> 
<? 	
		$index++;
		} 
	}
?>
		</table>
	</div>
</form>

<button class="under-button" onmouseover="this.style.cursor='pointer'" onclick="addNew();" ><?=JText::_('COM_CASAPLUS_ADD_NEW')?></button>