<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );

class CasaplusViewSpesa extends JView
{
	function display($tpl = null){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);

		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		$this->cartItems = $this->get('Items', 'Cart');

		$count = "";
		foreach ($this->cartItems as &$rowCart){
			$count .= $rowCart->id_prod;
			$count .= "-";
			$count .= $rowCart->quantita;
			$count .= " ";
		}
		setcookie("carrello", $count);
		
		parent::display($tpl);
	}

	function displayCart(){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);
		
		$this->state = $this->get('State');
		$this->items = $this->get('Items');
		
		parent::display('carrello');
	}

}