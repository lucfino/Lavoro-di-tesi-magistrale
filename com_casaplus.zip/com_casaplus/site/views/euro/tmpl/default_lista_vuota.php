<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

?>

<?
	if ($this->prezzo <= 0.05 ) {
?>
	<h1><?=JText::_('COM_CASAPLUS_EURO_VUOTA')?> <?= $this->prezzo?> €</h1>
<?
	} else {
?>
	<h1><?=JText::_('COM_CASAPLUS_EURO_LISTA_VUOTA')?> <?= $this->prezzo?> € <?=JText::_('COM_CASAPLUS_VUOTA')?></h1>
<?
	}
?>