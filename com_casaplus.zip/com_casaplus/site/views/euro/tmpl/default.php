<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

?>

<h1><?=JText::_('COM_CASAPLUS_RUBRICA_EURO')?></h1>

<div class="casaplus-manager">

		<span class="casaplus-icon-cent">
			<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=0.01&type=lista"); ?>">
				<img src="./media/com_casaplus/images/1-Cent-Euro_1.png" />
			</a>
		</span>

		<span class="casaplus-icon-cent">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=0.02&type=lista"); ?>">
					<img src="./media/com_casaplus/images/2-Cent-Euro_1.png" />
				</a>
		</span>

		<span class="casaplus-icon-cent">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=0.05&type=lista"); ?>">
					<img src="./media/com_casaplus/images/5-Cent-Euro_1.png" />
				</a>
		</span>

		<span class="casaplus-icon-cent">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=0.1&type=lista"); ?>">
					<img src="./media/com_casaplus/images/10-Cent-Euro_1.png" />
				</a>
		</span>

		<div class="spazio"></div>

		<span class="casaplus-icon-cent1">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=0.2&type=lista"); ?>">
					<img src="./media/com_casaplus/images/20-Cent-Euro_1.png" />
				</a>
		</span>

		<span class="casaplus-icon-cent1">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=0.5&type=lista"); ?>">
					<img src="./media/com_casaplus/images/50-Cent-Euro_1.png" />
				</a>
		</span>

		<span class="casaplus-icon-cent1">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=1&type=lista"); ?>">
					<img src="./media/com_casaplus/images/1-euro_1.png" />
				</a>
		</span>

		<span class="casaplus-icon-cent1">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=2&type=lista"); ?>">
					<img src="./media/com_casaplus/images/2-euro_1.png" />
				</a>
		</span>

		<div class="spazio"></div>

		<span class="casaplus-icon-euro">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=5&type=lista"); ?>">
					<img src="./media/com_casaplus/images/5-euro.png" />
				</a>
		</span>

		<span class="casaplus-icon-euro">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=10&type=lista"); ?>">
					<img src="./media/com_casaplus/images/10-euro.png" />
				</a>
		</span>

		<div class="spazio"></div>

		<span class="casaplus-icon-euro1">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=20&type=lista"); ?>">
					<img src="./media/com_casaplus/images/20-euro.png" />
				</a>
		</span>

		<span class="casaplus-icon-euro1">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=50&type=lista"); ?>">
					<img src="./media/com_casaplus/images/50-euro.png" />
				</a>
		</span>

		<div class="spazio"></div>

		<div class="casaplus-icon-euro2">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=100&type=lista"); ?>">
					<img src="./media/com_casaplus/images/100-euro.png" />
				</a>
		</div>

		<div class="spazio"></div>

		<div class="casaplus-icon-euro3">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=200&type=lista"); ?>">
					<img src="./media/com_casaplus/images/200-euro.png" />
				</a>
		</div>

		<div class="spazio"></div>

		<div class="casaplus-icon-euro4">
				<a style="background-color:transparent;" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=500&type=lista"); ?>">
					<img src="./media/com_casaplus/images/500-euro.png" />
				</a>
		</div>

</div>