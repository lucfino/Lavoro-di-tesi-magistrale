<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$categorie = $this->get('ListCategory');
$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');

?>

<form action="index.php" method="post" name="siteForm" id="siteForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

    <h1><?=JText::_('COM_CASAPLUS_EURO_PRODUCT')?> <?=$_GET['prezzo']?> €
	    <a class="lista-griglia-right" id="selezionato" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=".$_GET['prezzo']."&type=lista"); ?>">
	    	<img src="./media/com_casaplus/images/list-icon.png" height="15" width="15"> <?=JText::_('COM_CASAPLUS_EURO_LIST')?>
	    </a>
   		<a class="lista-griglia-left" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=".$_GET['prezzo']."&type=griglia"); ?>">
    		<img src="./media/com_casaplus/images/grid-icon.png" height="15" width="15"> <?=JText::_('COM_CASAPLUS_EURO_GRID')?>
	    </a>
	</h1>
   
	<div id="editcell">
		<table class="sitelist">
			<thead>
				<tr>
					<th id="product_euro_list" width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT_NAME');?></th>
					<th width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT_CATEGORY'); ?></th>	
					<th width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT_IMG_PATH'); ?></th>	
					<th width="25%"><?=JText::_('COM_CASAPLUS_PRODUCT_PRICE'); ?></th>
				</tr>
			</thead>

			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){
?>
					<tr class="row<?=$k?>">
						<td><?=strtoupper($row->nome)?></td>
						<td><ul>
							<? for ($i=0; $i<count($categorie); $i++) { ?>
            					<? if ($categorie[$i]->id == $row->id) { echo '<li>'.strtoupper($categorie[$i]->nome).'</li>';}?>
							<? } ?>
						</td></ul>
						<td><img class="default-img-lista" src="./media/com_casaplus/images/<?=$row->img?>"></td>
						<td><?=$row->prezzo?> €</td>
					</tr>
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>
</form>
