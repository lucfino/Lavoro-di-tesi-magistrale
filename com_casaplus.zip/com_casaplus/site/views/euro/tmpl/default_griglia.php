<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$categorie = $this->get('ListCategory');
$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');

?>

<form action="index.php" method="post" name="siteForm" id="siteForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

    <h1><?=JText::_('COM_CASAPLUS_EURO_PRODUCT')?> <?=$_GET['prezzo']?> €
    	<a class="lista-griglia-right" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=".$_GET['prezzo']."&type=lista"); ?>">
	    	<img src="./media/com_casaplus/images/list-icon.png" height="15" width="15"> <?=JText::_('COM_CASAPLUS_EURO_LIST')?>
	    </a>
   		<a class="lista-griglia-left" id="selezionato" href="<?php echo JRoute::_("index.php?option=com_casaplus&task=listaEuro&prezzo=".$_GET['prezzo']."&type=griglia"); ?>" >
    		<img src="./media/com_casaplus/images/grid-icon.png" height="15" width="15"> <?=JText::_('COM_CASAPLUS_EURO_GRID')?>
	    </a>
	</h1>

<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){
?>		
					<div id="griglia">
						<div id ="nome-griglia"><b><?=strtoupper($row->nome)?></b></div>
						<div id ="cat-griglia" >
							<? $cat = ""; ?>
							<? for ($i=0; $i<count($categorie); $i++) { ?>
            					<? if ($categorie[$i]->id == $row->id) { $cat .= strtoupper($categorie[$i]->nome)." ,";}?>
							<? } ?>
							<? echo substr($cat, 0,strlen($cat)-2) ?>
						</div>
						<div id ="img-griglia"><img class="default-img-griglia" src="./media/com_casaplus/images/<?=$row->img?>" height="100" width="100"></div>
						<div id ="prezzo-griglia">Prezzo: <b><?=$row->prezzo?> €</b></div>
					</div>
<?					
					$k = 1 - $k;
				}
?>
		
</form>
