<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );

class CasaplusViewEuro extends JView
{

	function display($tpl = null){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);
		
		parent::display($tpl);
	}

	function listaEuro($tpl){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/site.stylesheet.css', array(), true);

		$this->pagination = $this->get('Pagination');
		$this->state = $this->get('State');
		$this->items = $this->get('Items');

		if (isset($this->items[0])){	
			if (count((array)$this->items[0]) != 0){
				parent::display($tpl);
			}
		}else{
			$this->prezzo = JRequest::getVar('prezzo');
			parent::display('lista_vuota');
		}
	}

}