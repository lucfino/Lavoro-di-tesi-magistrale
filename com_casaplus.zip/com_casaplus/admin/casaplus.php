<?php

defined('_JEXEC') or die('Restricted access');
JLoader::register('CasaPlusHelper', dirname(__FILE__) . DS . 'helpers' . DS . 'casaplus.php');

Jimport('joomla.application.component.controller');
$controller = JController::getInstance('Casaplus'); 														
$input = JFactory::getApplication()->input;
$controller->execute($input->getCmd('task'));

$controller->redirect();