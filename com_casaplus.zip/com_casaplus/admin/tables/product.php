<?php

defined('_JEXEC') or die('Restricted access');

class TableProduct extends JTable{
    function __construct( &$db ) {
        parent::__construct('#__casaplus_product', 'id', $db);
    }
}