<?php

defined('_JEXEC') or die('Restricted access');

class TableCart extends JTable{
    function __construct( &$db ) {
        parent::__construct('#__casaplus_cart', 'id', $db);
    }
}