<?php

defined('_JEXEC') or die('Restricted access');

class TableStore extends JTable{
    function __construct( &$db ) {
        parent::__construct('#__casaplus_store', 'id', $db);
    }
}