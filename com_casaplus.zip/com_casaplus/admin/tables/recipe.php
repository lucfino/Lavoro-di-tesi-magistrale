<?php

defined('_JEXEC') or die('Restricted access');

class TableRecipe extends JTable{
    function __construct( &$db ) {
        parent::__construct('#__casaplus_recipe', 'id', $db);
    }
}