<?php

defined('_JEXEC') or die('Restricted access');

class TableRecipecategory extends JTable{
    function __construct( &$db ) {
        parent::__construct('#__casaplus_category_recipe', 'id', $db);
    }
}