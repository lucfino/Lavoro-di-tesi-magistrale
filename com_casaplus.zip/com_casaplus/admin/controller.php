<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');

class CasaplusController extends JController{
	
	public function categories($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Categories'));
		parent::display($cachable);
	}

	public function products($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Products'));
		parent::display($cachable);
	}

	public function positions($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Positions'));
		parent::display($cachable);
	}

	public function stores($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Stores'));
		parent::display($cachable);
	}

	public function display($cachable = false, $urlparams = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Casaplus'));
		parent::display($cachable);
	}
	
	public function recipes($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Recipes'));
		parent::display($cachable);
	}

	public function recipecategories($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Recipecategories'));
		parent::display($cachable);
	}
	
	public function steps($cachable = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Steps'));
		$view=$this->getView('Steps','html');
		$model = $this->getModel('Recipes');
		$view->setModel($model, true);
		$view->display($cachable);
	}

	public function step_detail($cachable = false){
		$id = JRequest::getVar('id');
		$nome = JRequest::getVar('nome');
		setcookie ('id_ricetta', $id);
		setcookie ('nome_ricetta', $nome);
		JRequest::setVar('view', JRequest::getCmd('view', 'Steps'));
		$view=$this->getView('Steps','html');
		$model = $this->getModel('Steps');
		$model->id = $id;
		$model->nome = $nome;
		$view->setModel($model, true);
		$view->display_recipe($cachable);
	}

	public function ingredients($cachable = false){
		$view=$this->getView('Recipe', 'html');
		$model = $this->getModel('Recipe');
		$view->setModel($model, true);
		$view->display_ingredients($cachable);
	}

	public function tools($cachable = false){
		$view=$this->getView('Recipe', 'html');
		$model = $this->getModel('Recipe');
		$view->setModel($model, true);
		$view->display_tool($cachable);
	}

}
