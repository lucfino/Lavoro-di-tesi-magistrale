<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');

$utensili = $this->get('ListUtensili');
$ingredienti = $this->get('ListIngredienti');

?>
<form action="index.php" method="post" name="adminForm" id="productsForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	<div id="editcell">
		<table class="adminlist">
			<thead>
				<tr>
					<th width="1%"><input type="checkbox" onclick="Joomla.checkAll(this)" title="<?=JText::_( 'Check All' )?>" value="" name="checkall-toggle"></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_NAME', 'Nome', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_DESC', 'Descriozione', $listDirn, $listOrder); ?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_TOOL', 'utensili', $listDirn, $listOrder); ?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_INGREDIENTS', 'ingredienti', $listDirn, $listOrder); ?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_CATEGORY', 'categorie', $listDirn, $listOrder); ?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_DIFFICULT', 'difficolta', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_IMG', 'immagine', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_CALORY', 'calorie', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_PERSON', 'persone', $listDirn, $listOrder); ?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_RECIPE_ENABLED', 'enabled', $listDirn, $listOrder); ?></th>		
				</tr>
			</thead>
			
			<tfoot>
                <tr>
                    <td colspan="11">
                        <?=$this->pagination->getListFooter()?>
                    </td>
                </tr>
            </tfoot>
			
			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){
					$checked = JHTML::_('grid.id', $i++, $row->id );
					$link = JRoute::_( 'index.php?option=' . $option . '&task=recipe.edit&id=' . $row->id );
?>
					<tr class="row<?=$k?>">
						<td><?=$checked?></td>
						<td><a href="<?=$link?>"><?=strtoupper($row->Nome)?></a></td>
						<td><a href="<?=$link?>"><?=strtolower($row->Descrizione)?></a></td>
						<td><select style="width:180px">
							<? $vuoto = true; ?>
							<? for ($i=0; $i<count($utensili); $i++) { ?>
            					<? if ($utensili[$i]->id == $row->id) { echo '<option>'.strtoupper($utensili[$i]->nome).'</option>'; $vuoto = false;}?>
							<? } ?>
							<? if ($vuoto) echo '<option>Nessun utensile</option>'; ?>
						</select></td>
						<td><select style="width:180px">
							<? $vuoto = true; ?>
							<? for ($i=0; $i<count($ingredienti); $i++) { ?>
            					<? if ($ingredienti[$i]->id == $row->id) { echo '<option>'.strtoupper($ingredienti[$i]->nome).'</option>'; $vuoto = false;}?>
							<? } ?>
							<? if ($vuoto) echo '<option>Nessun ingrediente</option>'; ?>
						</select></td>
						<td><a href="<?=$link?>"><?=$row->categoria?></a></td>
						<td><a href="<?=$link?>"><?=$row->difficolta?></a></td>
						<td><a href="<?=$link?>"><img class="default-img-product" src="../media/com_casaplus/images/<?=$row->img?>"></a></td>
						<td><a href="<?=$link?>"><?=$row->calorie?></a></td>
						<td><a href="<?=$link?>"><?=$row->persone?></a></td>
						<td><a href="<?=$link?>"><?=$row->enabled?></a></td>
					</tr>
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>
</form>
