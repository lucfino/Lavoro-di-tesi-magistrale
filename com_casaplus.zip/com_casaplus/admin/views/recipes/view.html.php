<?php

defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class CasaplusViewRecipes extends JView{
    
	function display($tpl = null){
		
		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);

		$this->addToolBar();
		$this->setDocument();
        CasaPlusHelper::addSubmenuRecipe('recipes');
		
		$this->pagination = $this->get('Pagination');
		$this->items = $this->get('Items');
		$this->state = $this->get('State');

        parent::display($tpl);
    }

    protected function addToolBar($total=null){
    
    	JToolBarHelper::title( JText::_( 'COM_CASAPLUS_RECIPE_MANAGER' ), 'users' );
    	JToolBarHelper::addNewX('recipe.add');
    	JToolBarHelper::editListX('recipe.edit');
    	JToolBarHelper::deleteList( JText::_( 'COM_CASAPLUS_RECIPE_CONFIRM_DELETE' ),'recipes.delete' );
    	JToolBarHelper::divider();
    	JToolBarHelper::back('Indietro', 'index.php?option=com_casaplus');
    }
    
    function setDocument(){
    	$document = JFactory::getDocument();
    	$document->addStyleDeclaration('.icon-48-users {background-image:
								url(../media/com_casaplus/images/ricetta.png);}');
    }
}
