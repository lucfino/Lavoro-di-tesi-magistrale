<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class CasaplusViewPosition extends JView{
	
    function display($tpl = null){

        JRequest::setVar('hidemainmenu', true);

        $item = $this->get( 'Item' );
        $form = $this->get( 'Form' );
        $isNew = ($item->id < 1);
        $this->addToolBar(null, $isNew);
        $this->setDocument();
        
        $this->item = $item;
        $this->form = $form;

        parent::display($tpl);
    }
    
    protected function addToolBar($total=null, $new)
    {
    	if ($new) {
    		JToolBarHelper::title( JText::_( 'COM_CASAPLUS_POSITION_NEW' ), 'users_add.png' );
    	} else {
    		JToolBarHelper::title( JText::_( 'COM_CASAPLUS_POSITION_EDIT' ), 'users_edit.png' );
    	}
    	
    	JToolBarHelper::apply('position.apply');
        JToolBarHelper::save('position.save');
        JToolBarHelper::save2new('position.save2new');
        JToolBarHelper::cancel('position.cancel', $new ? 'JTOOLBAR_CANCEL' : 'JTOOLBAR_CLOSE');
    }
    
    function setDocument()
    {
    	$document = JFactory::getDocument();
    	$document->addStyleDeclaration('.icon-48-users_add {background-image:
								url(../media/com_casaplus/images/icon-48-user-add.png);}');
    	$document->addStyleDeclaration('.icon-48-users_edit {background-image:
								url(../media/com_casaplus/images/icon-48-edit.png);}');
    }
}