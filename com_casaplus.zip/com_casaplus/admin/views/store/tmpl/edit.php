<?php 

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$task = JRequest::getCmd('task');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

$document = JFactory::getDocument();
$document->addScript("https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false");
$document->addScript(JURI::base() . '../media/com_casaplus/js/map.js');
?>

<form action="index.php" method="post" name="adminForm" id="store-admin-form" class="form-validate" enctype = "multipart/form-data">
    <input type="hidden" name="option" value="<?=$option?>" />
    <input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="id" value="<?=$this->item->id?>" />
    <?php echo JHtml::_('form.token'); ?>
    
    <fieldset class="adminform">
        <legend><?=JText::_( 'COM_CASAPLUS_STORE_DETAILS' ); ?></legend>
        <ul class="adminformlist">
<?    foreach ($this->form->getFieldset() as $field) { ?>
<?          if ($field->fieldname == 'indirizzo') echo '<li>'.$field->label.$field->input.'<span onclick="codeAddress();" style="position:relative;display:inline-block;height:15px;width:15px;relative;top:32px;left:-6px;background-size:15px;background-image:url(../media/com_casaplus/images/lente.jpg);border:solid 1px silver;"></span></li>'; 
            else echo '<li>'.$field->label.$field->input.'</li>'; ?>
<?    } ?>
        </ul>

        <div id="map-canvas" style="height:400px;width:700px;left:40px;controlUI.style.cursor = 'pointer';"/>

    </fieldset>
</form>