<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class CasaplusViewStep extends JView{
	
    function display($tpl = null){

        JRequest::setVar('hidemainmenu', true);
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);
        
        $item = $this->get( 'Item' );
        $form = $this->get( 'Form' );
        $isNew = ($item->id < 1);
        $this->addToolBar(null, $isNew);
        $this->setDocument();
        
        $this->item = $item;
        $this->form = $form;

        parent::display($tpl);
    }

    protected function addToolBar($total=null, $new){
    	if ($new) {
    		JToolBarHelper::title( JText::_( 'COM_CASAPLUS_STEP_NEW' ), 'users_add.png' );
    	} else {
    		JToolBarHelper::title( JText::_( 'COM_CASAPLUS_STEP_EDIT' ), 'users_edit.png' );
    	}
    	
        JToolBarHelper::save('step.save');
        JToolBarHelper::cancel('step.cancel', $new ? 'JTOOLBAR_CANCEL' : 'JTOOLBAR_CLOSE');
    }

    function setDocument(){
    	$document = JFactory::getDocument();
    	$document->addStyleDeclaration('.icon-48-users_add {background-image:
								url(../media/com_casaplus/images/icon-48-user-add.png);}');
    	$document->addStyleDeclaration('.icon-48-users_edit {background-image:
								url(../media/com_casaplus/images/icon-48-edit.png);}');
    }
}