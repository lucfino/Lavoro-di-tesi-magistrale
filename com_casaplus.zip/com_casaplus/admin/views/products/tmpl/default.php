<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');

$negozi = $this->get('ListStore');
$categorie = $this->get('ListCategory');

?>

<form action="index.php" method="post" name="adminForm" id="productsForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	<div id="editcell">
		<table class="adminlist">
			<thead>
				<tr>
					<th width="1%"><input type="checkbox" onclick="Joomla.checkAll(this)" title="<?=JText::_( 'Check All' )?>" value="" name="checkall-toggle"></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_PRODUCT_NAME', 'nome', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_PRODUCT_CATEGORY', 'categorie', $listDirn, $listOrder); ?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_PRODUCT_POSITION', 'posizione', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_PRODUCT_IMG_PATH', 'immagine', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_PRODUCT_QUANTITY', 'quantita', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_PRODUCT_PRICE', 'prezzo', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_PRODUCT_STORE', 'negozi', $listDirn, $listOrder); ?></th>	
				</tr>
			</thead>
			
			<tfoot>
                <tr>
                    <td colspan="8">
                        <?=$this->pagination->getListFooter()?>
                    </td>
                </tr>
            </tfoot>
			
			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){
					$checked = JHTML::_('grid.id', $i++, $row->id );
					$link = JRoute::_( 'index.php?option=' . $option . '&task=product.edit&id=' . $row->id );
?>
					<tr class="row<?=$k?>">
						<td><?=$checked?></td>
						<td><a href="<?=$link?>"><?=strtoupper($row->nome)?></a></td>
						<!-- vedere le virgole -->
						<td><a href="<?=$link?>">
							<ul>
							<? for ($i=0; $i<count($categorie); $i++) { ?>
            					<? if ($categorie[$i]->id == $row->id) { echo '<li>'.strtoupper($categorie[$i]->nome).'</li>';}?>
							<? } ?>
							</ul>
						</a></td>
						<td><a href="<?=$link?>"><?=strtoupper($row->posizione)?></a></td>
						<td><a href="<?=$link?>"><img class="default-img-product" src="../media/com_casaplus/images/<?=$row->img?>"></a></td>
						<td><a href="<?=$link?>"><?=$row->quantita?></a></td>
						<td><a href="<?=$link?>"><?=$row->prezzo?> €</a></td>
						<td><select style="width:180px">
							<? $vuoto = true; ?>
							<? for ($i=0; $i<count($negozi); $i++) { ?>
            					<? if ($negozi[$i]->id == $row->id) { echo '<option>'.strtoupper($negozi[$i]->nome).'</option>'; $vuoto = false;}?>
							<? } ?>
							<? if ($vuoto) echo '<option>Nessun negozio</option>'; ?>
						</select></td>
					</tr>
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>
</form>
