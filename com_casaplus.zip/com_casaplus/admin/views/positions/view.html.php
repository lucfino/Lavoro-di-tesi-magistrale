<?php

defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class CasaplusViewPositions extends JView{
    
    function display($tpl = null){
        
        JHtml::_('behavior.framework');
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);

        $this->addToolBar();
        $this->setDocument();
        CasaPlusHelper::addSubmenu('positions');
        
        $this->pagination = $this->get('Pagination');
        $this->items = $this->get('Items');
        $this->state = $this->get('State');
        
        parent::display($tpl);
    }
    
    protected function addToolBar($total=null){
    
        JToolBarHelper::title( JText::_( 'COM_CASAPLUS_POSITION_MANAGER' ), 'users' );
        JToolBarHelper::addNewX('position.add');
        JToolBarHelper::editListX('position.edit');
        JToolBarHelper::deleteList( JText::_( 'COM_CASAPLUS_POSITION_CONFIRM_DELETE' ),'positions.delete' );
        JToolBarHelper::divider();
        JToolBarHelper::back('Indietro', 'index.php?option=com_casaplus');
    }

    function setDocument(){
         
        $document = JFactory::getDocument();
        $document->addStyleDeclaration('.icon-48-users {background-image:
                                url(../media/com_casaplus/images/posizione.png);}');
    }
}