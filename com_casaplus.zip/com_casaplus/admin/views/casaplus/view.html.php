<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );

class CasaplusViewCasaplus extends JView
{

	function display($tpl = null){

		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);

		$this->addToolBar();
		$this->setDocument();

		$this->items = $this->get('Items');

		parent::display($tpl);
	}

	protected function addToolBar($total=null)
	{
		JToolBarHelper::title( JText::_( 'COM_CASAPLUS_MAINTENANCE_MANAGER' ), 'maintenance_manager' );
	}

	function setDocument()
	{
		$document = JFactory::getDocument();
		$document->addStyleDeclaration('.icon-48-maintenance_manager {background-image:
								url(../media/com_casaplus/images/icon-48-cpanel.png);}');
	}
}