<?php

defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<div class="casaplus-manager">
	<div class="casaplus-manager-left">
		
		<div class="casaplus-icon">
			<div class="casaplus-inner-icon">
				<a href="<?php echo JRoute::_("index.php?option=com_casaplus&task=products"); ?>">
					<img src="../media/com_casaplus/images/dispensa_sm.png" alt="" >
				</a>
			</div>
		</div>

		<div class="casaplus-icon">
			<div class="casaplus-inner-icon">
				<a href="<?php echo JRoute::_("index.php?option=com_casaplus&task=recipes"); ?>">
					<img src="../media/com_casaplus/images/ricette_sm.png" alt="" >
				</a>
			</div>
		</div>

	</div>
</div>