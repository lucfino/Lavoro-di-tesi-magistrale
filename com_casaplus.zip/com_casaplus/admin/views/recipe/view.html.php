<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class CasaplusViewRecipe extends JView{
    
    function display($tpl = null){

        JRequest::setVar('hidemainmenu', true);
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);
        
        $item = $this->get( 'Item' );
        $form = $this->get( 'Form' );
        $isNew = ($item->id < 1);
        $this->addToolBar(null, $isNew);
        $this->setDocument();

        $this->item = $item;
        $this->form = $form;

        parent::display($tpl);
    }

     function display_tool($tpl = null){

        JRequest::setVar('hidemainmenu', true);
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);
        
        $this->addToolBar_tools(null);
        $this->setDocument();

        $item = $this->get( 'Item' );
        $form = $this->get( 'Form' );
        $this->item = $item;
        $this->form = $form;

        parent::display('tools');
        
    }

    function display_ingredients($tpl = null){

        JRequest::setVar('hidemainmenu', true);
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);
        
        $this->addToolBar_ingredients(null);
        $this->setDocument();
        
        $item = $this->get( 'Item' );
        $form = $this->get( 'Form' );
        $this->item = $item;
        $this->form = $form;

        parent::display('ingredients');
    }
    
    protected function addToolBar($total=null, $new){

        if ($new) {
            JToolBarHelper::title( JText::_( 'COM_CASAPLUS_RECIPE_NEW' ), 'users_add.png' );
        } else {
            JToolBarHelper::title( JText::_( 'COM_CASAPLUS_RECIPE_EDIT' ), 'users_edit.png' );
        }
        
        JToolBarHelper::apply('recipe.apply');
        JToolBarHelper::save('recipe.save');
        JToolBarHelper::save2new('recipe.save2new');
        JToolBarHelper::cancel('recipe.cancel', $new ? 'JTOOLBAR_CANCEL' : 'JTOOLBAR_CLOSE');
    }

    protected function addToolBar_tools($total=null){
    
        JToolBarHelper::title( 'Modifica Utensili', 'users_add.png' );
        JToolBarHelper::save('recipe.savetools');
        JToolBarHelper::cancel('recipe.canceltools', 'JTOOLBAR_CLOSE');
    }

        protected function addToolBar_ingredients($total=null){
    
        JToolBarHelper::title( 'Modifica Ingredienti', 'users_add1.png' );
        JToolBarHelper::save('recipe.saveingredients');
        JToolBarHelper::cancel('recipe.cancelingredients', 'JTOOLBAR_CLOSE');
    }
    
    function setDocument(){
    
        $document = JFactory::getDocument();
        $document->addStyleDeclaration('.icon-48-users_add {background-image:
                                url(../media/com_casaplus/images/utensili.png);}');
        $document->addStyleDeclaration('.icon-48-users_edit {background-image:
                                url(../media/com_casaplus/images/icon-48-edit.png);}');
        $document->addStyleDeclaration('.icon-48-users_add1 {background-image:
                                url(../media/com_casaplus/images/ingredienti.png);}');
    }
}