<?php 

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$task = JRequest::getCmd('task');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');



?>

<form action="index.php" method="post" name="adminForm" id="recipe-admin-form" class="form-validate" enctype = "multipart/form-data">
    <input type="hidden" name="option" value="<?=$option?>" />
    <input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="id" value="<?=$this->item->id?>" />
    <?php echo JHtml::_('form.token'); ?>

    <fieldset class="adminform">
        <legend><?=JText::_( 'COM_CASAPLUS_RECIPE_DETAILS' ); ?></legend>

        <ul class="adminformlist" >
<?      foreach ($this->form->getFieldset() as $field) { 
            if ($field->fieldname != 'ingredienti' && $field->fieldname != 'utensili' &&  $field->fieldname !="utensilicheck" && $field->fieldname !="ingredienticheck"){
                echo '<li>'.$field->label.$field->input.'</li>'; 
            } else {
                $url = "window.location.assign('index.php?option=com_casaplus&task=ingredients&id=".$this->item->id."')";
                if ($field->fieldname == 'ingredienti') echo '<li>'.$field->label.$field->input.'<span onclick="'.$url.'" style="position:relative;display:inline-block;height:15px;width:15px;relative;top:217px;left:0px;background-size:15px;background-image:url(../media/com_casaplus/images/plus.jpg);border:solid 1px silver;"></span></li>'; 
                else {
                    $url = "window.location.assign('index.php?option=com_casaplus&task=tools&id=".$this->item->id."')";
                    if ($field->fieldname == 'utensili') echo '<li>'.$field->label.$field->input.'<span onclick="'.$url.'" style="position:relative;display:inline-block;height:15px;width:15px;relative;top:227px;left:0px;background-size:15px;background-image:url(../media/com_casaplus/images/plus.jpg);border:solid 1px silver;"></span></li>'; 
                }
            }
        }
?> 
        </ul>
        <img style="position:relative;top:-175px;left:35px;" class="default-img-product" src = "../media/com_casaplus/images/<?=$this->item->img?>" />

        </table>
    </fieldset>
</form>