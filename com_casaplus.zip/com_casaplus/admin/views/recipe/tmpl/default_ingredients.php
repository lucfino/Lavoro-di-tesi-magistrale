<?php 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$task = JRequest::getCmd('task');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

?>

<form action="index.php" method="post" name="adminForm" id="recipe-admin-form" class="form-validate" enctype = "multipart/form-data">
    <input type="hidden" name="option" value="<?=$option?>" />
    <input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="id" value="<?=$this->item->id?>" />
    <?php echo JHtml::_('form.token'); ?>
    
        <td style="width:440px;border-right:solid 1px #ccc;vertical-align:top;">
        <ul class="adminformlist" >

<?    		foreach ($this->form->getFieldset() as $field) { 
          		if ($field->fieldname == 'ingredienticheck' || $field->fieldname == 'id' ) echo '<li>'.$field->label.$field->input.'</li>'; 
    		} 
?>

        </ul>
        </td>

</form>