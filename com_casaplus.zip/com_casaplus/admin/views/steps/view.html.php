<?php

defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class CasaplusViewSteps extends JView{
    
    function display($tpl = null){
        
        JHtml::_('behavior.framework');
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);

        $this->addToolBar();
        $this->setDocument();
        CasaPlusHelper::addSubmenuRecipe('steps');

        $this->pagination = $this->get('Pagination');
        $this->items = $this->get('Items');
        $this->state = $this->get('State');
        
        parent::display();
    }

    function display_recipe($tpl = null){
        
        JHtml::_('behavior.framework');
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);

        $nome = JRequest::getVar('nome');
        $this->addToolBar_recipe($nome);
        $this->setDocument();
        
        $this->pagination = $this->get('Pagination');
        $this->items = $this->get('Items');
        $this->state = $this->get('State');
        
        parent::display('recipe');
    }
    
    protected function addToolBar($total=null){
        JToolBarHelper::title( JText::_( 'COM_CASAPLUS_STEP_MANAGER' ), 'users' );
        JToolBarHelper::back('Indietro', 'index.php?option=com_casaplus');
    }


    protected function addToolBar_recipe($nome){
        JToolBarHelper::title( JText::_( 'COM_CASAPLUS_STEP_MANAGER' ).' - '.ucfirst(strtolower($nome)) , 'users' );
        JToolBarHelper::addNewX('step.add');
        JToolBarHelper::editListX('step.edit');
        JToolBarHelper::deleteList( JText::_( 'COM_CASAPLUS_STEP_CONFIRM_DELETE' ),'steps.delete' );
        JToolBarHelper::divider();
        JToolBarHelper::back('Indietro', 'index.php?option=com_casaplus&task=steps');
    }

    function setDocument(){
        $document = JFactory::getDocument();
        $document->addStyleDeclaration('.icon-48-users {background-image:
                                url(../media/com_casaplus/images/step.png);}');
    }
}