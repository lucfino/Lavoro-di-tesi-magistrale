<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$id = JRequest::getVar('id'); 
$nome = JRequest::getVar('nome');

JRequest::setVar('id_ricetta', $id);
JRequest::setVar('nome_ricetta', $nome);

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
?>

<form action="index.php" method="post" name="adminForm" id="stepsForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="id_ricetta" value="<?=$id?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	<div id="editcell">
		<table class="adminlist">
			<thead>
				<tr>
					<th width="1%"><input type="checkbox" onclick="Joomla.checkAll(this)" title="<?=JText::_( 'Check All' )?>" value="" name="checkall-toggle"></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_STEP_POSITION', 'posizione', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_STEP_DESC', 'descrizione', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_STEP_IMG', 'img', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_STEP_TIMER', 'timer', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_STEP_TIME', 'tempo', $listDirn, $listOrder);?></th>
					

				</tr>
			</thead>
			

			
			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){
					$checked = JHTML::_('grid.id', $i++, $row->id );
					$link = JRoute::_( 'index.php?option=' . $option . '&task=step.edit&id=' . $row->id);
?>
					<tr class="row<?=$k?>">
						<td><?=$checked?></td>
						<td><a href="<?=$link?>"><?=$row->posizione?></a></td>
						<td><a href="<?=$link?>"><?=strtolower($row->descrizione);?></a></td>
						<td><a href="<?=$link?>"><img class="default-img-step" src="../media/com_casaplus/images/<?=$row->img?>"></a></td>
						<td><a href="<?=$link?>"><?=$row->timer?></a></td>
						<td><a href="<?=$link?>"><?=$row->tempo?></a></td>
						
						
					</tr>
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>
</form>