<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
?>

<form action="index.php" method="post" name="adminForm" id="stepsForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	<div id="editcell">
		<table class="adminlist">
			<thead>
				<tr>
					<th><?=JHtml::_('grid.sort', 'COM_CASAPLUS_STEP_RECIPE', 'id_ricetta', $listDirn, $listOrder);?></th>
				</tr>
			</thead>
			
			<tfoot>
                <tr>
                    <td colspan="1">
                        <?=$this->pagination->getListFooter()?>
                    </td>
                </tr>
            </tfoot>
			
			<tbody>
<?
				$k = 0;
				$i = 0;
				$tmp = 0;
				foreach ($this->items as &$row){
					$checked = JHTML::_('grid.id', $i++, $row->id );
					$link = JRoute::_( 'index.php?option=' . $option . '&task=step_detail&id=' . $row->id . '&nome='. $row->Nome );
?>
						<tr class="row<?=$k?>">
							<td><a href="<?=$link?>"><?=strtoupper($row->Nome);?></a></td>
						</tr>
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>
</form>