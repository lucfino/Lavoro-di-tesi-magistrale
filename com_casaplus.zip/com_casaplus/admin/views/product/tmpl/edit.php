<?php 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$task = JRequest::getCmd('task');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
?>

<form action="index.php" method="post" name="adminForm" id="product-admin-form" class="form-validate" enctype = "multipart/form-data">
    <input type="hidden" name="option" value="<?=$option?>" />
    <input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="id" value="<?=$this->item->id?>" />
    <?php echo JHtml::_('form.token'); ?>
    <!-- grafica nel css -->
    <fieldset class="adminform">
        <legend><?=JText::_( 'COM_CASAPLUS_PRODUCT_DETAILS' ); ?></legend>
        <table>
        <td style="width:440px;border-right:solid 1px #ccc;vertical-align:top;">
        <ul class="adminformlist">
<?    foreach ($this->form->getFieldset() as $field) { ?>
<?          if ($field->fieldname != 'cat_id' && $field->fieldname != 'negozi') echo '<li>'.$field->label.$field->input.'</li>'; ?>
<?    } ?>
        </ul>
        <img class="default-img-product" src = "../media/com_casaplus/images/<?=$this->item->img_path?>" />
        </td>
        <td style="width:440px;border-right:solid 1px #ccc;vertical-align:top;">
<?    foreach ($this->form->getFieldset() as $field) { ?>
<?          if ($field->fieldname == 'cat_id') echo '<li>'.$field->label.$field->input.'</li>'; ?>
<?    } ?> 
        </td>
        <td style="width:440px;vertical-align:top;">
<?    foreach ($this->form->getFieldset() as $field) { ?>
<?          if ($field->fieldname == 'negozi') echo '<li>'.$field->label.$field->input.'</li>'; ?>
<?    } ?> 
        </td>
        </table>
    </fieldset>
</form>