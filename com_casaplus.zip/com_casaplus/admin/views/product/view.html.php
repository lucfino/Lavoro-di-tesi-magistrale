<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class CasaplusViewProduct extends JView{
	
    function display($tpl = null){

        JRequest::setVar('hidemainmenu', true);
        JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);

        $item = $this->get( 'Item' );
        $form = $this->get( 'Form' );
        $isNew = ($item->id < 1);
        $this->addToolBar(null, $isNew);
        $this->setDocument();
        
        $this->item = $item;
        $this->form = $form;

        parent::display($tpl);
    }
    
    protected function addToolBar($total=null, $new){

    	if ($new) {
    		JToolBarHelper::title( JText::_( 'COM_CASAPLUS_PRODUCT_NEW' ), 'users_add.png' );
    	} else {
    		JToolBarHelper::title( JText::_( 'COM_CASAPLUS_PRODUCT_EDIT' ), 'users_edit.png' );
    	}
    	
    	JToolBarHelper::apply('product.apply');
        JToolBarHelper::save('product.save');
        JToolBarHelper::save2new('product.save2new');
        JToolBarHelper::cancel('product.cancel', $new ? 'JTOOLBAR_CANCEL' : 'JTOOLBAR_CLOSE');
    }
    
    function setDocument(){
    	$document = JFactory::getDocument();
    	$document->addStyleDeclaration('.icon-48-users_add {background-image:
								url(../media/com_casaplus/images/icon-48-user-add.png);}');
    	$document->addStyleDeclaration('.icon-48-users_edit {background-image:
								url(../media/com_casaplus/images/icon-48-edit.png);}');
    }
}