<?php

defined('_JEXEC') or die('Restricted access');
jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class CasaplusViewCategories extends JView{
    
	function display($tpl = null){
		
		JHtml::_('behavior.framework');
		JHtml::stylesheet('com_casaplus/admin.stylesheet.css', array(), true);

		$this->addToolBar();
		$this->setDocument();
        CasaPlusHelper::addSubmenu('categories');
		
		$this->pagination = $this->get('Pagination');
		$this->items = $this->get('Items');
		$this->state = $this->get('State');
		
        parent::display($tpl);
    }
    
    protected function addToolBar($total=null)
    {
    	JToolBarHelper::title( JText::_( 'COM_CASAPLUS_CATEGORY_MANAGER' ), 'users' );
    	JToolBarHelper::addNewX('category.add');
    	JToolBarHelper::editListX('category.edit');
    	JToolBarHelper::deleteList( JText::_( 'COM_CASAPLUS_CATEGORY_CONFIRM_DELETE' ),'categories.delete' );
    	JToolBarHelper::divider();
    	JToolBarHelper::back('Indietro', 'index.php?option=com_casaplus');
    }
    
    function setDocument()
    {
    	$document = JFactory::getDocument();
    	$document->addStyleDeclaration('.icon-48-users {background-image:
								url(../media/com_casaplus/images/categoria.png);}');
    }
}