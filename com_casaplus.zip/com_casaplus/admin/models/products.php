<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelProducts extends JModelList{
    
    public function __construct($config = array()){
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array('nome', 'categoria', 'posizione', 'quantita', 'prezzo');
        }
        parent::__construct($config);
    }
    
    function getListQuery(){             
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('p1.id, p1.nome as nome, p2.nome as posizione, p1.quantita as quantita, p1.img_path as img, p1.prezzo as prezzo');
        $query->from('#__casaplus_product AS p1, #__casaplus_position AS p2');
        $query->where('p1.pos_id = p2.id AND p1.id > 0');
        $query->order($this->getState('list.ordering', 'p1.id') .
                ' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    function getListStore(){
        $db = JFactory::getDBO();
        $query = "SELECT p.id, s.nome as nome FROM #__casaplus_product as p, #__casaplus_product_store as ps, #__casaplus_store as s WHERE p.id = ps.product_id AND s.id = ps.store_id";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function getListCategory(){
        $db = JFactory::getDBO();
        $query = "SELECT p.id, c.nome as nome FROM #__casaplus_product as p, #__casaplus_product_category as pc, #__casaplus_category as c WHERE p.id = pc.product_id AND c.id = pc.category_id";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function salvaNegozi($prodotto, $negozi){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_product_store'));             
        $query->where('product_id='.$prodotto);             
        $db->setQuery($query);
        $db->query(); 
        
        $count = count($negozi);
        for ($i=0; $i<$count; $i++){
            $insert = 'INSERT INTO `#__casaplus_product_store`(`product_id`, `store_id`) VALUES ('.$prodotto.','.$negozi[$i].')';
            $db->setQuery($insert);
            $db->query();
        }
    }

    function cancellaNegozi($prodotto){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_product_store'));             
        $query->where('product_id='.$prodotto);             
        $db->setQuery($query);
        $db->query(); 
    }

    function salvaCategorie($prodotto, $categorie){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_product_category'));             
        $query->where('product_id='.$prodotto);             
        $db->setQuery($query);
        $db->query(); 
        
        $count = count($categorie);
        for ($i=0; $i<$count; $i++){
            $insert = 'INSERT INTO `#__casaplus_product_category`(`product_id`, `category_id`) VALUES ('.$prodotto.','.$categorie[$i].')';
            $db->setQuery($insert);
            $db->query();
        }
    }

    function cancellaCategorie($prodotto){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_product_category'));             
        $query->where('product_id='.$prodotto);             
        $db->setQuery($query);
        $db->query(); 
    }
    
}