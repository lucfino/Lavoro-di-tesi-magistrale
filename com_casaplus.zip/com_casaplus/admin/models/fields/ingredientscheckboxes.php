<?php

defined('JPATH_BASE') or die;
jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldIngredientsCheckBoxes extends JFormField
{
   protected $type = 'checkboxes';

   protected function getInput()
   {

      $db = JFactory::getDBO();
      $query = "SELECT id, nome FROM #__casaplus_product ORDER BY nome";
      $db->setQuery($query);
      $categories = $db->loadObjectList();
      $query = "SELECT p.id as id, p.nome as nome, t.id_prod as pro, t.quantita as quantita FROM #__casaplus_product as p, #__casaplus_ingredients as t WHERE p.id = t.id_prod AND t.id_ricetta=".$_GET['id'];
      $db->setQuery($query); 
      $controll = $db->loadObjectList();
      $var_list ='<table>';

      $arr = array();
      $count = count($controll);
      foreach($controll as $c){
         $arr[$c->pro] = $c->quantita;
      }

      $i=0;
      $count = count($categories);
      //die(var_dump(intval($count/4)));
      $col = intval($count/4);
      foreach($categories as $category){
         if ($i==0){
            $var_list .='<td style="border-right: 1px solid black;padding-right:8px;">';
         } else if ($i==$col){
            $var_list .='</td><td style="border-right: 1px solid black;padding-right:8px;">';
         } else if ($i==$col*2){
            $var_list .='</td><td style="border-right: 1px solid black;padding-right:8px;">';
         } else if ($i==$col*3){
            $var_list .='</td><td>';
         } else if ($i==$count){
            $var_list .='</td>';
         }
         if (isset($arr[$category->id])){
            $var_list.= '<li><input name="'.$this->name.'[]" type="checkbox" value="'.$category->id.'" checked="checked"><label style="width:200px" for="jform_store_id'.$category->id.'">'.strtoupper($category->nome).'</label><input style="width:75px;float:right;" type="text" name="ingredients'.$category->id.'" value="'.strtolower($arr[$category->id]).'"></li>';
         }else{
            $var_list.= '<li><input name="'.$this->name.'[]" type="checkbox" value="'.$category->id.'"><label style="width:200px" for="jform_store_id'.$category->id.'">'.strtoupper($category->nome).'</label><input style="width:75px;float:right;" type="text" name="ingredients'.$category->id.'" value=""></li>';
         }
         $i++;
      }
      $var_list .= '</table>';
      return $var_list;
   }
}