<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.form.formfield');
 
class JFormFieldPositionlist extends JFormField {

        protected $type = 'positionlist';
        protected $options;
        protected $current;
        
        public function getInput() {
            
            $view=$this->getOptions();
            $id=JRequest::getVar('id');
            
            $return='<select id="'.$this->id.'" name="'.$this->name.'" style="width:205px">';
            if (!isset($id)){
                $return=$return.'<option value="'.$row->id.'" selected>Seleziona una posizione</option>';
            }
            foreach ($this->options as $row){
                if($row->id==$this->current['pos_id']){ 
                    $return=$return.'<option value="'.$row->id.'" selected>'.strtoupper($row->nome).'</option>';}
                else{
                    $return=$return.'<option value="'.$row->id.'">'.strtoupper($row->nome).'</option>';}
            }       
            $return=$return.'</select>';
            return $return;
        }
        
        public function getOptions(){
            
            $db = JFactory::getDBO();
            $query = $db->getQuery(true);
            $query->select( 'id, nome');
            $query->from('#__casaplus_position');
            $query->order('nome');
            $db->setQuery($query);
            $this->options=$db->loadObjectList();

            $view=JRequest::getVar('view','');
            $id=JRequest::getVar('id');
            
            if(isset($id)){
                $db = JFactory::getDBO();
                $query = $db->getQuery(true);
                $query->select('pos_id');
                $query->from('#__casaplus_product');
                $query->where('id='.$id);
                $db->setQuery($query);
                $this->current=$db->loadAssoc();
            }
            
            return $view;
        }
}

