<?php
defined('JPATH_BASE') or die;

jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldCategoryCheckBoxes extends JFormField
{
   protected $type = 'checkboxes';

   protected function getInput()
   {
      $db = JFactory::getDBO();
      $query = "SELECT id, nome FROM #__casaplus_category ORDER BY nome";
      $db->setQuery($query);
      $categories = $db->loadObjectList();
      $query = "SELECT c.id as id, c.nome as nome, cp.category_id as cat FROM #__casaplus_category as c, #__casaplus_product_category as cp WHERE c.id = cp.category_id AND cp.product_id=".$_GET['id'];
      $db->setQuery($query); 
      $controll = $db->loadObjectList();
      $var_list ='';

      $arr = array();
      $count = count($controll);
      foreach($controll as $c){
         $arr[$c->cat] = true;
      }

      foreach($categories as $category){
         if (isset($arr[$category->id])){
            $var_list.= '<li><input name="'.$this->name.'[]" type="checkbox" value="'.$category->id.'" checked="checked"><label for="jform_store_id'.$category->id.'">'.strtoupper($category->nome).'</label></li>';
         }else{
            $var_list.= '<li><input name="'.$this->name.'[]" type="checkbox" value="'.$category->id.'"><label for="jform_store_id'.$category->id.'">'.strtoupper($category->nome).'</label></li>';
         }
      }
      return '<fieldset id="jform_store_id" class="checkboxes"><ul>'.$var_list.'</ul></fieldset>';
   }
}

