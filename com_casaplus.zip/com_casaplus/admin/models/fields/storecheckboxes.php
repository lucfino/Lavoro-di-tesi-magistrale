<?php

defined('JPATH_BASE') or die;
jimport('joomla.html.html');
jimport('joomla.form.formfield');

class JFormFieldStoreCheckBoxes extends JFormField
{
   protected $type = 'checkboxes';

   protected function getInput()
   {
      $db = JFactory::getDBO();
      $query = "SELECT id, nome FROM #__casaplus_store ORDER BY nome";
      $db->setQuery($query);
      $categories = $db->loadObjectList();
      $query = "SELECT s.id as id, s.nome as nome, sp.store_id as store FROM #__casaplus_store as s, #__casaplus_product_store as sp WHERE s.id = sp.store_id AND sp.product_id=".$_GET['id'];
      $db->setQuery($query); 
      $controll = $db->loadObjectList();
      $var_list ='';

      $arr = array();
      $count = count($controll);
      foreach($controll as $c){
         $arr[$c->store] = true;
      }

      foreach($categories as $category){
         if (isset($arr[$category->id])){
            $var_list.= '<li><input name="'.$this->name.'[]" type="checkbox" value="'.$category->id.'" checked="checked"><label for="jform_store_id'.$category->id.'">'.strtoupper($category->nome).'</label></li>';
         }else{
            $var_list.= '<li><input name="'.$this->name.'[]" type="checkbox" value="'.$category->id.'"><label for="jform_store_id'.$category->id.'">'.strtoupper($category->nome).'</label></li>';
         }
      }
      return '<fieldset id="jform_store_id" class="checkboxes"><ul>'.$var_list.'</ul></fieldset>';
   }
}