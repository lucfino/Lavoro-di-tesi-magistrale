<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.form.formfield');
 
class JFormFieldToolslist extends JFormField {

        protected $type = 'toolslist';
        protected $options;
        protected $current;
        
        public function getInput() {
            
            $view=$this->getOptions();
            $id=JRequest::getVar('id');
            
            $return='<select id="'.$this->id.'" name="'.$this->name.'" style="width:205px">';

            if (count($this->options) == 0){
               $return=$return.'<option value="0" selected>Nessuno strumento</option>';
            }
            foreach ($this->options as $row){
                    $return=$return.'<option value="'.$row->id.'" selected>'.strtoupper($row->nome).' - '.strtolower($row->note).'</option>';
            }       
            $return=$return.'</select>';
            return $return;
        }
        
        public function getOptions(){
            
            $view=JRequest::getVar('view','');
            $id=JRequest::getVar('id');

            $db = JFactory::getDBO();
            $query = $db->getQuery(true);
            $query = "SELECT p.id as id, p.nome as nome, t.id_prod as pro, t.note1 as note FROM #__casaplus_product as p, #__casaplus_tools as t WHERE p.id = t.id_prod AND t.id_ricetta=".$_GET['id'];

            $db->setQuery($query);
            $this->options=$db->loadObjectList();

            return $view;
        }
}

