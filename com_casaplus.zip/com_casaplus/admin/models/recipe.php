<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modeladmin' );

class CasaplusModelRecipe extends JModelAdmin{    

    public function getForm($data = array(), $loadData = true){
        $form = $this->loadForm('com_casaplus.recipe', 'recipe',
                array('control' => 'jform', 'load_data' => $loadData));
        if (!$form){
            return false;} 
        else{
            return $form;}
    }
        
    public function loadFormData(){
        $data = $this->getItem();
        return $data;
    }

    public function getNameById($id){
        $db = JFactory::getDBO();
        $query = "SELECT r.nome as nome FROM #__casaplus_recipe as r WHERE r.id = ".$id;
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results[0]->nome;
    }
    
}