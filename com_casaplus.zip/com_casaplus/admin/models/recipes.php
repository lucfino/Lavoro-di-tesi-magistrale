<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelRecipes extends JModelList{
    
    public function __construct($config = array()){
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array('Nome', 'Descrizione', 'categoria', 'calorie', 'difficolta', 'persone');
        }
        parent::__construct($config);
    }
    
    function getListQuery(){               
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('r.id, r.Nome, r.Descrizione, r.img, c.nome as categoria, r.calorie, r.difficolta, r.persone, r.enabled');
        $query->from('#__casaplus_recipe as r, #__casaplus_category_recipe as c');
        $query->where('r.categoria = c.id');
        $query->order($this->getState('list.ordering', 'Nome') .
                ' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    function getListUtensili(){
        $db = JFactory::getDBO();
        $query = "SELECT r.id, p.nome as nome FROM #__casaplus_product as p, #__casaplus_tools as t, #__casaplus_recipe as r WHERE p.id = t.id_prod AND r.id = t.id_ricetta";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function getListIngredienti(){
        $db = JFactory::getDBO();
        $query = "SELECT r.id, p.nome as nome FROM #__casaplus_product as p, #__casaplus_ingredients as t, #__casaplus_recipe as r WHERE p.id = t.id_prod AND r.id = t.id_ricetta";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function salvaIngredienti($ricetta, $ingredienti, $quantita){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_ingredients'));             
        $query->where('id_ricetta='.$ricetta);             
        $db->setQuery($query);
        $db->query(); 
        
        $count = count($ingredienti);
        for ($i=0; $i<$count; $i++){
            if ($quantita[$i] != "")
                $insert = 'INSERT INTO `#__casaplus_ingredients`(`id_ricetta`, `id_prod`, `quantita`) VALUES ('.$ricetta.','.$ingredienti[$i].',"'.$quantita[$i].'")';
            else
                $insert = 'INSERT INTO `#__casaplus_ingredients`(`id_ricetta`, `id_prod`) VALUES ('.$ricetta.','.$ingredienti[$i].')';
            $db->setQuery($insert);
            $db->query();
        }
    }

    function cancellaIngredienti($ricetta){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_ingredients'));             
        $query->where('id_ricetta='.$ricetta);             
        $db->setQuery($query);
        $db->query(); 
    }

    function salvaUtensili($ricetta, $categorie, $note){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_tools'));             
        $query->where('id_ricetta='.$ricetta);             
        $db->setQuery($query);
        $db->query(); 
        
        $count = count($categorie);
        for ($i=0; $i<$count; $i++){
            if ($note[$i] != "")
                $insert = 'INSERT INTO `#__casaplus_tools`(`id_ricetta`, `id_prod`, `note1`) VALUES ('.$ricetta.','.$categorie[$i].',"'.$note[$i].'")';
            else
                $insert = 'INSERT INTO `#__casaplus_tools`(`id_ricetta`, `id_prod`) VALUES ('.$ricetta.','.$categorie[$i].')';
            $db->setQuery($insert);
            $db->query();
        }
    }

    function cancellaUtensili($ricetta){
        $db = & JFactory::getDBO();   
        $query = $db->getQuery(true);
        $query->delete($db->nameQuote('#__casaplus_tools'));             
        $query->where('id_ricetta='.$ricetta);             
        $db->setQuery($query);
        $db->query(); 
    }
    
    
}