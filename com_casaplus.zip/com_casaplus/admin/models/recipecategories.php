<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelRecipecategories extends JModelList{
    
    public function __construct($config = array()){
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array('nome');
        }
        parent::__construct($config);
    }
    
    function getListQuery(){             
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('id, nome, img, ordine');
        $query->from('#__casaplus_category_recipe');
        $query->order($this->getState('list.ordering', 'ordine') .
                ' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    
}