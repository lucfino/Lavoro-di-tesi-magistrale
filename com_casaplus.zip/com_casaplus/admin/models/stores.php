<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelStores extends JModelList{
	
	public function __construct($config = array()){
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array('nome');
		}
		parent::__construct($config);
	}
	
	function getListQuery(){	          
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('id, nome, lat, lon, indirizzo, telefono');
        $query->from('#__casaplus_store');
        $query->order($this->getState('list.ordering', 'id') .
        		' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    
}