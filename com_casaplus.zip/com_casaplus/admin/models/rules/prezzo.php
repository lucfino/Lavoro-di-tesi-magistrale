<?php

defined('JPATH_BASE') or die;

jimport('joomla.form.formrule');

class JFormRulePrezzo extends JFormRule {

    public function test(& $element, $value, $group = null, & $input = null, & $form = null){

        if (preg_match("/^500$|^\d{0,2}(\.\d{1,2})? *%?$/",$value) == 0)
            return false;
        else
            return true;
    }
}