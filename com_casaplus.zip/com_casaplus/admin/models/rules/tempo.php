<?php

defined('JPATH_BASE') or die;

jimport('joomla.form.formrule');

class JFormRuleTempo extends JFormRule {

    public function test(& $element, $value, $group = null, & $input = null, & $form = null){

        if (preg_match("/^[0-9]{1,7}$/",$value) == 0)
            return false;
        else
            return true;
    }
}