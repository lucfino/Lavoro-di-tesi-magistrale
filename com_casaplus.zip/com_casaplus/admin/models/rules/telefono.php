<?php

defined('JPATH_BASE') or die;

jimport('joomla.form.formrule');

class JFormRuleTelefono extends JFormRule {

    public function test(& $element, $value, $group = null, & $input = null, & $form = null){

        if (preg_match("/^(\+{0,1}[0-9]{2,3}|[0-9]{3,5})[-\/ ]?[0-9]{2,4}[-\/ ]?[0-9]{5,8}$/",$value) == 0)
            return false;
        else
            return true;
    }
}