<?php

defined('JPATH_BASE') or die;

jimport('joomla.form.formrule');

class JFormRuleLatitude extends JFormRule {

    public function test(& $element, $value, $group = null, & $input = null, & $form = null){

        if (preg_match("/^-?([1-8]?[1-9]|[1-9]0)\.{1}\d{1,6}/",$value) == 0)
            return false;
        else
            return true;
    }
}