<?php
defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class CasaplusModelSteps extends JModelList{
    
    public function __construct($config = array()){
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array('id_ricetta', 'descrizione', 'tempo', 'posizione' );
        }
        parent::__construct($config);
    }
    
    function getListQuery(){        
        $id = JRequest::getVar('id'); 
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('s.id, r.id as ricetta, r.nome as id_ricetta, s.descrizione, s.img, s.timer, s.tempo, s.posizione');
        $query->from('#__casaplus_step as s, #__casaplus_recipe as r');
        $query->where('r.id = s.id_ricetta AND r.id = '.$id);
        $query->order($this->getState('list.ordering', 's.id_ricetta, s.posizione') .
                ' ' . $this->getState('list.direction', 'ASC'));

        return $query;
    }

    protected function populateState($ordering = null, $direction = null)
    {
        $this->setState('list.limit', 0);
    } 
    
}