<?php

defined('_JEXEC') or die;
 
abstract class CasaPlusHelper
{

        public static function addSubmenu($submenu) 
        {
                JSubMenuHelper::addEntry(JText::_('COM_CASAPLUS_PRODUCT_MESSAGE'),
                                         'index.php?option=com_casaplus&task=products', $submenu == 'products');
                JSubMenuHelper::addEntry(JText::_('COM_CASAPLUS_CATEGORY_MESSAGE'),
                                         'index.php?option=com_casaplus&task=categories',
                                         $submenu == 'categories');
                JSubMenuHelper::addEntry(JText::_('COM_CASAPLUS_POSITION_MESSAGE'),
                                         'index.php?option=com_casaplus&task=positions',
                                         $submenu == 'positions');
                JSubMenuHelper::addEntry(JText::_('COM_CASAPLUS_STORE_MESSAGE'),
                                         'index.php?option=com_casaplus&task=stores',
                                         $submenu == 'stores');
                
                $document = JFactory::getDocument();
               
                if ($submenu == 'categories'){
                        $document->setTitle(JText::_('COM_CASAPLUS_CATEGORY_MANAGER'));
                } else if ($submenu == 'positions'){
                        $document->setTitle(JText::_('COM_CASAPLUS_POSITION_MANAGER'));
                } else if ($submenu == 'stores'){
                        $document->setTitle(JText::_('COM_CASAPLUS_STORE_MANAGER'));
                }
        }

        public static function addSubmenuRecipe($submenu) 
        {
                JSubMenuHelper::addEntry(JText::_('COM_CASAPLUS_RECIPE_MESSAGE'),
                                         'index.php?option=com_casaplus&task=recipes', $submenu == 'recipes');
                JSubMenuHelper::addEntry(JText::_('COM_CASAPLUS_CATEGORY_MESSAGE'),
                                         'index.php?option=com_casaplus&task=recipecategories',
                                         $submenu == 'recipecategories');
                JSubMenuHelper::addEntry(JText::_('COM_CASAPLUS_STEP_MESSAGE'),
                                         'index.php?option=com_casaplus&task=steps',
                                         $submenu == 'steps');
                
                $document = JFactory::getDocument();
               
                if ($submenu == 'recipecategories'){
                        $document->setTitle(JText::_('COM_CASAPLUS_CATEGORY_MANAGER'));
                } else if ($submenu == 'steps'){
                        $document->setTitle(JText::_('COM_CASAPLUS_STEP_MANAGER'));
                } 
        }

}