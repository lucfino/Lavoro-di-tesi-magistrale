<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class CasaplusControllerPosition extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'positions';
		parent::__construct($config);
	}

}