<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class CasaplusControllerCategory extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'categories';
		parent::__construct($config);
	}

	public function save()
	{

		// gestione dell'immagine
		JClientHelper::setCredentialsFromRequest('ftp');

		if ($_FILES['jform']['name']['img_path'] != ""){
			$now = strtotime("now");
			$rand = rand(0, 100);
			$type = str_replace("image/", "", $_FILES['jform']['type']['img_path']);
			$filename = "cat".$now.$rand.".".$type;
		} else{
			$filename = "";
		}
		$tmp_name  = $_FILES['jform']['tmp_name']['img_path'];
		
		if ($filename != ""){
			$_POST['jform']['img'] = $filename;
		}

		$filepath = JPATH_ROOT.DS.'media'.DS.'com_casaplus'.DS.'images'.DS.$filename;
      
		$allowed = array('image/jpeg', 'image/png', 'image/gif', 'image/JPG', 'image/jpg', 'image/pjpeg');
		
		if ($filename == ""){
			return parent::save();
		}            
		if (!in_array($_FILES['jform']['type']['img_path'], $allowed)) 
		{
		    echo "<script> alert('The file you are trying to upload is not supported.');
		      window.history.back();</script>\n";
		    exit;
		}
		else 
		{
		    JFile::upload($tmp_name, $filepath);
		}

		return parent::save();

	}
}