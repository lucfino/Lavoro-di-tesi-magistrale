<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerRecipes extends JControllerAdmin{

    public function getModel($name = 'Recipe', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }


}