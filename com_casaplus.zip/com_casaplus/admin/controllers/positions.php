<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerPositions extends JControllerAdmin{

    public function getModel($name = 'Position', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }

}