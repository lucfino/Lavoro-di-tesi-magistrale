<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerRecipecategories extends JControllerAdmin{

    public function getModel($name = 'Recipecategory', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }


}