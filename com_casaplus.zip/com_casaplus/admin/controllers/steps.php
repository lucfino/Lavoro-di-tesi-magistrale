<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class CasaplusControllerSteps extends JControllerAdmin{

    public function getModel($name = 'Step', $prefix = 'CasaplusModel', $config = array()){
        return parent::getModel($name, $prefix, $config);
    }

    public function delete(){

		$id = $_POST['id_ricetta']; 
		$model = $this->getModel('Recipe');
		$nome = $model->getNameById($id);
		
		parent::delete();
		$this->setRedirect('index.php?option=com_casaplus&task=step_detail&id='.$id.'&nome='.$nome);
		$this->redirect();
	}

}