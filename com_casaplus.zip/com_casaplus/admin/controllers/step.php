<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class CasaplusControllerStep extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'steps';
		parent::__construct($config);
	}

	public function save(){

		// gestione dell'immagine
		JClientHelper::setCredentialsFromRequest('ftp');
		
		$id = $_POST['jform']['id_ricetta'];
		$model = $this->getModel('Recipe');
		$nome = $model->getNameById($id);

		if ($_FILES['jform']['name']['img_path'] != ""){
			$now = strtotime("now");
			$rand = rand(0, 100);
			$type = str_replace("image/", "", $_FILES['jform']['type']['img_path']);
			$filename = "step".$now.$rand.".".$type;
		} else{
			$filename = "";
		}
		$tmp_name  = $_FILES['jform']['tmp_name']['img_path'];

		if (!isset($_POST['jform']['tempo'])){
			$_POST['jform']['tempo'] = 0;
		}
		
		if ($filename != ""){
			$_POST['jform']['img'] = $filename;
		}

		$filepath = JPATH_ROOT.DS.'media'.DS.'com_casaplus'.DS.'images'.DS.$filename;
      
		$allowed = array('image/jpeg', 'image/png', 'image/gif', 'image/JPG', 'image/jpg', 'image/pjpeg');
		
		if ($filename != "")
		{
			if (!in_array($_FILES['jform']['type']['img_path'], $allowed)) 
			{
			    echo "<script> alert('The file you are trying to upload is not supported.');
			    	window.history.back();</script>\n";
			    exit;
			}
			else 
			{
			    JFile::upload($tmp_name, $filepath);
			}
		}

		// invia notifica push
		if (isset($_POST['jform']['ultimo'])){
			$msg = "Ricettario: E' stata inserita una nuova ricetta";
			$script = str_replace ( "administrator/" , "" , JURI::base());
			$URL = $script."index.php?option=com_apns&task=send.do_sendtoall&textArea=".urlencode($msg);
			$db = JFactory::getDbo();
			$db->setQuery("SELECT enabled FROM #__extensions WHERE name = 'apns'");
			$is_enabled = $db->loadResult();	
			if ($is_enabled){
			   	$data = file_get_contents($URL);
			}
		}

		parent::save();
		$this->setRedirect('index.php?option=com_casaplus&task=step_detail&id='.$id.'&nome='.$nome);
		$this->redirect();
	}

	public function cancel(){
		$id = $_POST['jform']['id_ricetta']; 
		$model = $this->getModel('Recipe');
		$nome = $model->getNameById($id);
		
		parent::cancel();
		$this->setRedirect('index.php?option=com_casaplus&task=step_detail&id='.$id.'&nome='.$nome);
		$this->redirect();
	}


}