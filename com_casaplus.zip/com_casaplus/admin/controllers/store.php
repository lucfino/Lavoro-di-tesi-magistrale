<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class CasaplusControllerStore extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'stores';
		parent::__construct($config);
	}
}