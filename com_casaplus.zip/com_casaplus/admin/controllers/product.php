<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');
jimport( 'joomla.application.component.helper' );

class CasaplusControllerProduct extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'products';
		parent::__construct($config);
	}

	public function save(){

		$model = $this->getModel('Products');

		// gestione dei negozi
		if (isset($_POST['jform']['negozi'])){	
			$model->salvaNegozi($_POST['jform']['id'], $_POST['jform']['negozi']);
		} else {
			$model->cancellaNegozi($_POST['jform']['id']);
		}

		// gestione delle categorie
		if (isset($_POST['jform']['cat_id'])){	
			$model->salvaCategorie($_POST['jform']['id'], $_POST['jform']['cat_id']);
		} else {
			$model->cancellaCategorie($_POST['jform']['id']);
		}

		// gestione dell'immagine
		JClientHelper::setCredentialsFromRequest('ftp');

		if ($_FILES['jform']['name']['img'] != ""){
			$now = strtotime("now");
			$rand = rand(0, 100);
			$type = str_replace("image/", "", $_FILES['jform']['type']['img']);
			$filename = "pro".$now.$rand.".".$type;
		} else{
			$filename = "";
		}
		$tmp_name  = $_FILES['jform']['tmp_name']['img'];
		if ($filename != ""){
			$_POST['jform']['img_path'] = $filename;
		}

		$filepath = JPATH_ROOT.DS.'media'.DS.'com_casaplus'.DS.'images'.DS.$filename;
      
		$allowed = array('image/jpeg', 'image/png', 'image/gif', 'image/JPG', 'image/jpg', 'image/pjpeg');
		
		if ($filename != "")
		{         
			if (!in_array($_FILES['jform']['type']['img'], $allowed)) 
			{
			        JFactory::getApplication()->enqueueMessage("Formato immagine non corretto", "error");
			        exit;
			} else {
			         JFile::upload($tmp_name, $filepath);
			}
		}

		return parent::save();
		
	}
}