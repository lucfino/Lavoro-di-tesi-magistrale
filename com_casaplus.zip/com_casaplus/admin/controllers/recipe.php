<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class CasaplusControllerRecipe extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'recipes';
		parent::__construct($config);
	}

	public function save(){

		$model = $this->getModel('Recipes');

		// gestione dell'immagine
		JClientHelper::setCredentialsFromRequest('ftp');

		if ($_FILES['jform']['name']['img_path'] != ""){
			$now = strtotime("now");
			$rand = rand(0, 100);
			$type = str_replace("image/", "", $_FILES['jform']['type']['img_path']);
			$filename = "rec".$now.$rand.".".$type;
		} else{
			$filename = "";
		}
		$tmp_name  = $_FILES['jform']['tmp_name']['img_path'];
		
		if ($filename != ""){
			$_POST['jform']['img'] = $filename;
		}

		$filepath = JPATH_ROOT.DS.'media'.DS.'com_casaplus'.DS.'images'.DS.$filename;
      
		$allowed = array('image/jpeg', 'image/png', 'image/gif', 'image/JPG', 'image/jpg', 'image/pjpeg');
		
		if ($filename == ""){
			return parent::save();
		}            
		if (!in_array($_FILES['jform']['type']['img_path'], $allowed)) 
		{
		        echo "<script> alert('The file you are trying to upload is not supported.');
		      window.history.back();</script>\n";
		        exit;
		}
		else 
		{
		    JFile::upload($tmp_name, $filepath);
		}

		return parent::save();

	}

	public function savetools(){
		$id = JRequest::getVar('id');
		$model = $this->getModel('Recipes');

		// gestione delle utensili
		$note = array();
		$count = count($_POST['jform']['utensilicheck']);

        for ($i=0; $i<$count; $i++){
        	$note[$i] = $_POST['tools'.$_POST['jform']['utensilicheck'][$i]];
        }
		if (isset($_POST['jform']['utensilicheck'])){	
			$model->salvaUtensili($id, $_POST['jform']['utensilicheck'], $note);
		} else {
			$model->cancellaUtensili($id);
		}

		$this->setRedirect('index.php?option=com_casaplus&view=recipe&layout=edit&id='.$id);
		$this->redirect();
	}

	public function cancel(){
		$this->setRedirect('index.php?option=com_casaplus&view=recipes');
		$this->redirect();
	}

	public function canceltools(){
		$id = JRequest::getVar('id'); 
		parent::cancel();
		$this->setRedirect('index.php?option=com_casaplus&view=recipe&layout=edit&id='.$id);
		$this->redirect();
	}

	public function saveingredients(){
		$id = JRequest::getVar('id');
		$model = $this->getModel('Recipes');

		// gestione dei ingredienti
		$quantita = array();
		$count = count($_POST['jform']['ingredienticheck']);
        for ($i=0; $i<$count; $i++){
        	$quantita[$i] = $_POST['ingredients'.$_POST['jform']['ingredienticheck'][$i]];
        }
		if (isset($_POST['jform']['ingredienticheck'])){	
			$model->salvaIngredienti($id, $_POST['jform']['ingredienticheck'], $quantita);
		} else {
			$model->cancellaIngredienti($id);
		}
		
		$this->setRedirect('index.php?option=com_casaplus&view=recipe&layout=edit&id='.$id);
		$this->redirect();
	}

	public function cancelingredients(){
		$id = JRequest::getVar('id'); 
		parent::cancel();
		$this->setRedirect('index.php?option=com_casaplus&view=recipe&layout=edit&id='.$id);
		$this->redirect();
	}
}