CREATE TABLE IF NOT EXISTS `#__casaplus_store` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(80) NOT NULL,
  `lat` double default NULL,
  `lon` double default NULL,
  `indirizzo` varchar(100) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

CREATE TABLE IF NOT EXISTS `#__casaplus_position` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

CREATE TABLE IF NOT EXISTS `#__casaplus_category` (
  `id` int(11) NOT NULL auto_increment,
  `img` varchar(100) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

CREATE TABLE IF NOT EXISTS `#__casaplus_product` (
  `id` int(11) NOT NULL auto_increment,
  `cat_id` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `quantita` int(11) NOT NULL,
  `pos_id` int(11) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `prezzo` double NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=297 ;

CREATE TABLE IF NOT EXISTS `#__casaplus_product_store` (
  `product_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`product_id`, `store_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=297 ;

CREATE TABLE IF NOT EXISTS `#__casaplus_product_category` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`product_id`, `category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=297 ;
