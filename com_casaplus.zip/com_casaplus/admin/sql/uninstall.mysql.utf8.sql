DROP TABLE IF EXISTS `#__casaplus_position`;
DROP TABLE IF EXISTS `#__casaplus_category`;
DROP TABLE IF EXISTS `#__casaplus_product`;
DROP TABLE IF EXISTS `#__casaplus_store`;
DROP TABLE IF EXISTS `#__casaplus_product_store`;
DROP TABLE IF EXISTS `#__casaplus_product_category`;

DROP TABLE IF EXISTS `#__casaplus_recipe`;
DROP TABLE IF EXISTS `#__casaplus_category_recipe`;
DROP TABLE IF EXISTS `#__casaplus_step`;
DROP TABLE IF EXISTS `#__casaplus_tools`;
DROP TABLE IF EXISTS `#__casaplus_ingredients`;
DROP TABLE IF EXISTS `#__casaplus_cart`;