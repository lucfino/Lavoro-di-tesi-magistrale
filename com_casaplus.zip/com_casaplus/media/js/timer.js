function prova() {
  document.getElementById('jform_tempo').value = 0;
  if (document.getElementById('jform_timer').value == 1){
      document.getElementById('jform_tempo').disabled = false;
    }else{
      document.getElementById('jform_tempo').disabled = true;
    }
}

window.onload = function()
{
  document.getElementById('jform_id_ricetta').value = getCookie('id_ricetta');

  if (document.getElementById('jform_timer').value == 1){
      document.getElementById('jform_tempo').disabled = false;
    }else{
      document.getElementById('jform_tempo').disabled = true;
    }
    document.getElementById('jform_timer').addEventListener("change", prova, false); 
}; 

function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}