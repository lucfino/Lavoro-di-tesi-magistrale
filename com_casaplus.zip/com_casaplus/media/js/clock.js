window.onload = function(){
  CoolClock.findAndCreateClocks();
  document.getElementById('clock_backgrounds').addEventListener("change", change_background, false);
  document.getElementById('current_time_img').addEventListener("click", show_digital, false);
  document.getElementById('current_time').addEventListener("click", show_digital, false);
  var background = getCookie('background');
  if (background == "")
    background = "0";

  document.getElementById('wewood').style.background = "url('./media/com_casaplus/images/clockdial_"+background+".png') 50% 50% no-repeat";
  document.getElementById('clock_backgrounds').value = background;
  document.getElementById('wewood').style.backgroundSize = "cover";
};


function change_background() {
  i = document.getElementById('clock_backgrounds').value;
  document.getElementById('wewood').style.background = "url('./media/com_casaplus/images/clockdial_"+i+".png') 50% 50% no-repeat";
  document.getElementById('wewood').style.backgroundSize = "cover";
  document.cookie="background="+i;
}

function show_digital() {
  if (document.getElementById('current_time').style.visibility == "hidden"){
    document.getElementById('current_time').style.visibility = "visible";
  }else{
    document.getElementById('current_time').style.visibility = "hidden";
  }
}

function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}

window.setInterval(function(){
  var now     = new Date();
    var hour    = now.getHours();
    var minute  = now.getMinutes();
    var second  = now.getSeconds(); 
    if(hour.toString().length == 1) {
        var hour = '0'+hour;
    }
    if(minute.toString().length == 1) {
        var minute = '0'+minute;
    }
    if(second.toString().length == 1) {
        var second = '0'+second;
    }   
    var dateTime = hour+':'+minute+':'+second; 
  document.getElementById('current_time').innerHTML = dateTime;
}, 1000);


function parla()  
{  
  var date = new Date();
  var loc = location.pathname.split("/")[1]; 
  var testo = "Sono le ore "+date.getHours()+" e "+date.getMinutes();
  meSpeak.loadConfig("/"+loc+"/media/com_casaplus/mespeak/mespeak_config.json");
  meSpeak.loadVoice('/'+loc+'/media/com_casaplus/mespeak/voices/it.json');
  meSpeak.speak(testo);

}