var ore = 0, minuti = 0, secondi = 0, decimi = 0;
var vis = "";  
var stop = true;
var count = 0;
var loc = location.pathname.split("/")[1]; 
var audio = new Audio('/'+loc+'/media/com_casaplus/sound/gong.mp3');

function next(id, next, max, type, seconds) 
{ 
  if (type == 1){
    count = seconds;
  }else{
    count = 0;
  }
  azzera(id, type);
  document.getElementById('start'+id).style.display = "";
  document.getElementById('start'+id).style.visibility = "";
  document.getElementById('pause'+id).style.display = "none";
  document.getElementById('restart'+id).style.display = "none";
  document.getElementById('stop'+id).style.display = "none";

  document.getElementById(id).style.display='none';
  document.getElementById(next).style.display='';

  document.getElementById('foot'+id).style.display='none'; 
  document.getElementById('foot'+next).style.display='';

  if (next == max) {
    document.getElementById('nextF'+next).onclick='';
    document.getElementById('next'+next).innerHTML = '<img id = "imgNextF'+next+'" src="/'+loc+'/media/com_casaplus/images/finish.ico" width="50"><div>FINITO !</div>';
    document.getElementById('nextF'+next).addEventListener('click',finish,false); 
  }
} 

function prev(id, prev, min, type, seconds) 
{ 
  if (type == 1){
    count = seconds;
  }else{
    count = 0;
  }
  azzera(id, type);
  document.getElementById('start'+id).style.display = "";
  document.getElementById('start'+id).style.visibility = "";
  document.getElementById('pause'+id).style.display = "none";
  document.getElementById('restart'+id).style.display = "none";
  document.getElementById('stop'+id).style.display = "none";

  document.getElementById(id).style.display='none';
  document.getElementById(prev).style.display='';

  document.getElementById('foot'+id).style.display='none'; 
  document.getElementById('foot'+prev).style.display='';

  if (prev == min) {
    document.getElementById('prev'+prev).style.visibility='hidden';
  }
} 

function finish() 
{ 
  alert("La ricetta è terminata!!");
  document.location='index.php?option=com_casaplus&task=ricettario';
} 

function startTimer(type, id, seconds, nextStep, max){
  if (type == 1){
    count = seconds;
    decimi = 10;
    secondi = seconds % 60;
    minuti = Math.floor(seconds / 60);
    ore= Math.floor(minuti / 60);
    minuti %= 60;
    ore %= 60;
  } else {
    ore = minuti = secondi = decimi = 0;
  }
  avvia(id, type, nextStep,  max, seconds);
  document.getElementById('start'+id).style.visibility = "hidden";
  if (type == 0){
    document.getElementById('pause'+id).style.display = "";
    document.getElementById('stop'+id).style.display = "";
    document.getElementById('start'+id).style.display = "none";
  } 
}

function pauseTimer(id) {  
     stop = true;  
     document.getElementById('pause'+id).style.display = "none";
     document.getElementById('restart'+id).style.display = "";
} 

function restartTimer(id, type, nextStep,  max, seconds){
  avvia(id, type, nextStep,  max, seconds);
  document.getElementById('pause'+id).style.display = "";
    document.getElementById('restart'+id).style.display = "none";
}

function stopTimer(id, nextStep, max, type, seconds){ 
  azzera(id, type);
  document.getElementById('start'+id).style.display = "";
  document.getElementById('pause'+id).style.display = "none";
  document.getElementById('restart'+id).style.display = "none";
  document.getElementById('stop'+id).style.display = "none";

  if (nextStep == "") 
    document.location='index.php?option=com_casaplus&task=ricettario';
  else 
    next(id, nextStep, max, type, seconds);

}

function avvia(id, type, nextStep, max, seconds) 
 {  
  if(stop == true) 
  {  
    stop = false;  
    cronometro(id, type, nextStep, max, seconds);  
  }  
}

function azzera(id, type) 
{  
  if(stop == false) 
  {
    stop = true;  
  }  
  if (type == 0)
  {
    ore = minuti = secondi = decimi = 0;
  }
  else
  {
    secondi = count % 60;
    minuti = Math.floor(count / 60);
    ore= Math.floor(minuti / 60);
    minuti %= 60;
    ore %= 60;
  }
  vis = "";  
  mostra(id); 
} 

function cronometro(id, type, nextStep, max, seconds) 
{  
  if(stop == false) 
  { 
    if (type == 0) 
    {
      decimi++;  
      if(decimi > 9) 
      {  
        decimi = 0;  
        secondi++;  
      }  
      if(secondi > 59) {  
        secondi = 0;  
        minuti++;  
      }  
      if(minuti > 59) {  
        minuti = 0;  
        ore++;  
      }  
    }
    else if (type == 1)
    {
      decimi--;  
      if(decimi < 0) 
      {  
        decimi = 9;  
        secondi--; 
      } 
      if(secondi < 0) 
      {  
        secondi = 59;  
        minuti--;  
      }  
      if(minuti < 0) 
      {  
        minuti = 59;  
        ore--;  
      }  
      if (ore == 0 && minuti == 0 && secondi == 0 && decimi == 0)
      {
        audio.play();
        alert("Tempo scaduto!!");
        stopTimer(id, nextStep, max, type, seconds);
      }
    }
    mostra(id);  
    if (nextStep == "")
      nextStep = "0";
    setTimeout("cronometro("+id+", "+type+", "+nextStep+", "+max+", "+seconds+")", 100);  
  }  
}

function mostra(id) {  
  if (ore == "" || ore < 1) vis = "00"; else if(ore < 10) vis = "0"; else vis = ore;  
  vis = vis + ":"; 
  if(minuti < 10) vis = vis + "0";  
  vis = vis + minuti + ":";  
  if(secondi < 10) vis = vis + "0";  
  vis = vis + secondi;  
  document.getElementById("vis"+id).innerHTML = vis;  
}



function parla(id)  
{ 
  var testo=(document.getElementById("desc"+id).innerHTML);
  meSpeak.loadConfig("/"+loc+"/media/com_casaplus/mespeak/mespeak_config.json");
  meSpeak.loadVoice('/'+loc+'/media/com_casaplus/mespeak/voices/it.json');
  meSpeak.speak(testo);
}
