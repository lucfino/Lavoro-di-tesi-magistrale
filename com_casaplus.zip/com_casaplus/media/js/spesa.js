var count = 0;
var countNew = getCookie('countNew');

function prova(id) 
{	
	id = id.replace("thead", "tbody");
	arrow = id.replace("tbody", "arrow")
	if (document.getElementById(id).style.display == "none"){
		for (var i=0; i<getCookie('num_cat'); i++){
			document.getElementById('tbody'+i).style.display = "none";
			document.getElementById('arrow'+i).src = "./media/com_casaplus/images/down-arrow-icon.png";
		}
		document.getElementById(id).style.display = "";
		document.getElementById(arrow).src = "./media/com_casaplus/images/up-arrow-icon.png";
	}else{
		document.getElementById(id).style.display = "none";
		document.getElementById(arrow).src = "./media/com_casaplus/images/down-arrow-icon.png";
	}
} 


function changeIt(img, img_path, nome, id)
{
	if (img.style.backgroundColor == ""){
		$.get( "index.php", { option: "com_casaplus", task: "cart.addProduct", id: id, quantita: "0"});
		img.style.backgroundColor = "green";
		document.getElementById("theadcart").style.visibility = "visible";
		$('#tbodycart').append('<tr id="cart'+id+'" class="row'+count%2+'"><td><img class="default-img-lista" src="./media/com_casaplus/images/'+img_path+'"></td><td>'+nome+'</td><td><input onblur="quantityChange(this)" id="quantita'+id+'" type="text" name="quantita"></td><td id="elimina'+id+'" onclick="removeFromCart(this)"><img height="100" width="100" src="./media/com_casaplus/images/cestino.png"></td></tr>');
		count++;
		document.getElementById("crea-lista-button").style.visibility = "";
		document.getElementById("lista-carrello").style.visibility = "";
	}
}

function press(img)
{
	if (img.alt == 0)
		img.src = "./media/com_casaplus/images/addcart_press.png";
	else
		img.src = "./media/com_casaplus/images/removecart_press.png";
}

function removeFromCart(element)
{
	var id = element.id.replace("elimina", "");
	if (id > 0){
		$.get( "index.php", { option: "com_casaplus", task: "cart.removeProduct", id: id});
		document.getElementById(id).style.backgroundColor = "";
	}else{
		$.get( "index.php", { option: "com_casaplus", task: "cart.removeNewProduct", id: id});
		countNew++;
		setCookie('countNew',countNew,1200);
	}
	$('#cart'+id).remove();
	count--;
	if (count == 0){
		document.getElementById("theadcart").style.visibility = "hidden";
		document.getElementById("crea-lista-button").style.visibility = "hidden";
		document.getElementById("lista-carrello").style.visibility = "hidden";
	}
}

function quantityChange(element)
{
	var id = element.id.replace("quantita", "");
	$.get( "index.php", { option: "com_casaplus", task: "cart.updateProduct", id: id, quantita: element.value});
}

function nameChange(element)
{
	var id = element.id.replace("nome", "");
	$.get( "index.php", { option: "com_casaplus", task: "cart.updateNameProduct", id: id, name: element.value});
}

function addNew()
{
	if (!countNew)
		countNew = -1;
	$.get( "index.php", { option: "com_casaplus", task: "cart.addNewProduct", id: countNew, quantita: "0"});
	document.getElementById("theadcart").style.visibility = "visible";
	$('#tbodycart').append('<tr id="cart'+countNew+'" class="row'+count%2+'"><td><img class="default-img-lista"></td><td><input onblur="nameChange(this)" id="nome'+countNew+'" type="text" name="nome"></td><td><input onblur="quantityChange(this)" id="quantita'+countNew+'" type="text" name="quantita"></td><td id="elimina'+countNew+'" onclick="removeFromCart(this)"><img height="100" width="100" src="./media/com_casaplus/images/cestino.png"></td></tr>');
	count++;
	countNew--;
	setCookie('countNew',countNew,1200);
	document.getElementById("crea-lista-button").style.visibility = "";
	document.getElementById("lista-carrello").style.visibility = "";
}

window.onload = function()
{
	for (var i=0; i<getCookie('num_cat'); i++){
    	document.getElementById('thead'+i).addEventListener("click", function(){
    		prova(this.id);
    	}, false); 
    }

    count = getCookie('count');

    if (window.name == "reloader")
    {
        window.name = "no";
        document.location.reload();
    }

};


function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}

function setCookie(cname,cvalue,exdays)
{
var d = new Date();
d.setTime(d.getTime()+(exdays*24*60*60*1000));
var expires = "expires="+d.toGMTString();
document.cookie = cname + "=" + cvalue + "; " + expires;
}