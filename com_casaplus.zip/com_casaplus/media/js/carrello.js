var selezionati = new Array();

window.onbeforeunload = function() {
     window.name = "reloader"; 
}

function compatta ( array, index ) {
	var j;
	for ( j=index; j<(array.length - 1); j++ )
		array[j] = array[j+1];
	array.length--;
}

function printTable(numberOfRow){

	if (selezionati.length == 0){
  		alert("Nessun elemento selezionato");
  	}else {
		var divTmp = document.getElementById('printTable');
		divToPrint = divTmp.clone();
	  	newWin = window.open("");
	  	var el = newWin.document.createElement('link');
	    newWin.document.write('<html><head><title>Lista della spesa</title><link rel="stylesheet" type="text/css" href="./media/com_casaplus/css/site.stylesheet.css"></head><body>');
	  	var first = true;

	  	for (i=1; i<=numberOfRow; i++){
	  		
	  		if (selezionati.indexOf(i.toString()) != -1){
	  			if (first){
		  			divToPrint.rows[0].deleteCell(0);
		  			divToPrint.rows[i].deleteCell(0);
		  			first = false;
	  			} else
	  				divToPrint.rows[i].deleteCell(0);
	  		}else{
	  			divToPrint.rows[i].style.setProperty('display', 'none');
	  		}
	  	}

	  	newWin.document.write(divToPrint.outerHTML);
	  	newWin.document.write('</body></html>');
	  	newWin.print();
	  	newWin.close();
  	}

}

function seleziona(id)
{
	if (selezionati.indexOf(id) == -1)
		selezionati.push(id);
	else
		compatta(selezionati ,selezionati.indexOf(id));

	if(selezionati.length == 0){
		document.getElementById("checkAll").checked = false;
		// hidden button
		// disabled button
	}

}

function checkAll(check, max)
{
	var nodeList = document.getElementsByName('checkDev');
	if (check.checked){
		for (i=0; i<nodeList.length; i++){
			nodeList[i].checked = true;
			var tmp = i+1;
			var id = tmp.toString();
			if (selezionati.indexOf(id) == -1)
				selezionati.push(id);
		}
	}else {
		for (i=0; i<nodeList.length; i++){
			nodeList[i].checked = false;
		}
		selezionati = new Array();
		// hidden button
		// disabled button
	}

}
