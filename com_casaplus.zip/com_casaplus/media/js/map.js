var map;
var marker;
var geocoder;

function initialize() {

  geocoder = new google.maps.Geocoder();

    var mapOptions = {
      center: new google.maps.LatLng(42.356007,13.398803),
        zoom: 9,
        draggableCursor:'crosshair'
    };
    
    map = new google.maps.Map(document.getElementById("map-canvas"),
         mapOptions);

    marker = new google.maps.Marker({
      position: new google.maps.LatLng(document.getElementById("jform_lat").value,document.getElementById("jform_lon").value),
      map: map
    });

    google.maps.event.addListener(map, 'click', function(event) {
      placeMarker(event.latLng);
    });

}

function placeMarker(location) {
  marker.setPosition(location);
  document.getElementById("jform_lat").value = location.lat();
  document.getElementById("jform_lon").value = location.lng();
}

function codeAddress() {
    var address = document.getElementById("jform_indirizzo").value;
    geocoder.geocode( { 'address': address}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        map.setCenter(results[0].geometry.location);
        marker.setPosition(results[0].geometry.location);
        document.getElementById("jform_lat").value = results[0].geometry.location.lat();
        document.getElementById("jform_lon").value = results[0].geometry.location.lng();

      } else {
        alert("Geocode was not successful for the following reason: " + status);
      }
    });
  }

google.maps.event.addDomListener(window, 'load', initialize);