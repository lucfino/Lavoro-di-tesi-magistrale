//
//  AppDelegate.m
//  CasaPlus
//
//  Created by Luca Finocchio on 04/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "AppDelegate.h"
#import "AFNetworking.h"
#import "PrintTableViewController.h"
#import "QuantityTableViewController.h"
#import <AudioToolbox/AudioToolbox.h>

@implementation AppDelegate{
    NSUserDefaults *defaults;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    //Check first launch
    defaults = [NSUserDefaults standardUserDefaults];
    if (![defaults objectForKey:@"firstRun"])
    {
        [defaults setValue:[NSDate date] forKey:@"firstRun"];
        [defaults setBool:NO forKey:@"pref_visual_grouped"];
        [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
        [defaults setBool:YES forKey:@"pref_show_category"];
        [defaults setBool:YES forKey:@"pref_direct_selection"];
        [defaults setValue:@"0" forKey:@"clock_background"];
    }
    
    #define UUID_USER_DEFAULTS_KEY @"UUID"
    if ([defaults objectForKey:UUID_USER_DEFAULTS_KEY] == nil)
    {
        [defaults setObject:[[self class] GetUUID] forKey:UUID_USER_DEFAULTS_KEY];
        [defaults synchronize];
    }

    [defaults synchronize];
    
    //
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    // Seleziono il viewController iniziale
    [self selectInitialVC];
    
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application{
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Resetto il badge Number
    application.applicationIconBadgeNumber = 0;
    
    // Attivo il controllo della posizione
    if ([((UINavigationController*)self.window.rootViewController).viewControllers count] == 4)
    {
        if ([[((UINavigationController*)self.window.rootViewController).viewControllers objectAtIndex:3] isKindOfClass:[PrintTableViewController class]])
        {
            PrintTableViewController *pvc = (PrintTableViewController*)((UINavigationController*)self.window.rootViewController).visibleViewController;
            if ([CLLocationManager significantLocationChangeMonitoringAvailable])
            {
                [pvc.locationManager startUpdatingLocation];
            }
            else
            {
                NSLog(@"Significant location change monitoring is not available.");
            }
        }
    }
    
}

- (void)applicationWillEnterForeground:(UIApplication *)application{
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Setto il bagdeNumber a 0 sull'app e sul server
    application.applicationIconBadgeNumber = 0;
    
    if ([defaults objectForKey:@"token"] != nil)
    {
        // Imposto i parametri della richiesta
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        NSDictionary *params = @{@"option": @"com_apns", @"task": @"devlists.resetBadge", @"devToken": [defaults objectForKey:@"token"]};
        [manager POST:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
        {
            //NSLog(@"okreset");
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            //NSLog(@"noreset");
        }];
    }
    
    // Ricarico le categorie in modo cambiare lo stato degli header (aperti o chiusa) a senconda dell'impostazione selezionata
    [self.tableController getCategoryOutOfServer];
    
    // Attivo il controllo della posizione
    if ([((UINavigationController*)self.window.rootViewController).viewControllers count] == 4)
    {
        if ([[((UINavigationController*)self.window.rootViewController).viewControllers objectAtIndex:3] isKindOfClass:[PrintTableViewController class]])
        {
            PrintTableViewController *pvc = (PrintTableViewController*)((UINavigationController*)self.window.rootViewController).visibleViewController;
            if ([CLLocationManager significantLocationChangeMonitoringAvailable])
            {
                [pvc.locationManager startUpdatingLocation];
            }
            else
            {
                NSLog(@"Significant location change monitoring is not available.");
            }
        }
    }
    
    // Ricarico lo sfondo a seconda dell'impostazione selezionata
    NSString *background = [NSString stringWithFormat:@"clockdial_%@.png",[defaults objectForKey:@"clock_background"]];
    [self.clockController.clockView setClockBackgroundImage:[UIImage imageNamed:background]];
    [self.clockController.clockView reloadInputViews];
}

- (void)applicationWillTerminate:(UIApplication *)application{
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    
#if !TARGET_IPHONE_SIMULATOR
    
	// Get Bundle Info for Remote Registration (handy if you have more than one app)
	NSString *appName = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
	NSString *appVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
	
	// Check what Notifications the user has turned on.  We registered for all three, but they may have manually disabled some or all of them.
	NSUInteger rntypes = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
	
	// Set the defaults to disabled unless we find otherwise...
	NSString *pushBadge = (rntypes & UIRemoteNotificationTypeBadge) ? @"enabled" : @"disabled";
	NSString *pushAlert = (rntypes & UIRemoteNotificationTypeAlert) ? @"enabled" : @"disabled";
	NSString *pushSound = (rntypes & UIRemoteNotificationTypeSound) ? @"enabled" : @"disabled";
	
	// Get the users Device Model, Display Name, Unique ID, Token & Version Number
	UIDevice *dev = [UIDevice currentDevice];
    NSString *deviceUuid = [defaults objectForKey:UUID_USER_DEFAULTS_KEY] ;
	NSString *deviceName = dev.name;
	NSString *deviceModel = dev.model;
	NSString *deviceSystemVersion = dev.systemVersion;
	
	// Prepare the Device Token for Registration (remove spaces and < >)
	NSString *deviceToken1 = [[[[deviceToken description]
                                stringByReplacingOccurrencesOfString:@"<"withString:@""]
                               stringByReplacingOccurrencesOfString:@">" withString:@""]
                              stringByReplacingOccurrencesOfString: @" " withString: @""];
    NSString *user;
    if ([defaults objectForKey:@"username"])
        user = [defaults objectForKey:@"username"];
    else
        user = @"not_logged";
    
    // Imposto i parametri della richiesta
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_apns", @"task": @"devlists.addDevice", @"appName": appName, @"appVersion": appVersion, @"pushBadge": pushBadge, @"pushAlert": pushAlert, @"pushSound": pushSound, @"devUid": deviceUuid, @"devName": deviceName, @"devModel": deviceModel, @"devSO": deviceSystemVersion, @"devToken": deviceToken1, @"user":user};
    
    // Eseguo la richiesta
    [manager POST:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        //NSLog(@"okadd");
        if ([defaults objectForKey:@"token"] == nil) {
            [defaults setObject:deviceToken1 forKey:@"token"];
            [defaults synchronize];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        //NSLog(@"noadd:%@", error);
    }];
	
#endif
    
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
#if !TARGET_IPHONE_SIMULATOR
    
	NSLog(@"Failed to get token, error: %@", error);
    
#endif
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
#if !TARGET_IPHONE_SIMULATOR
    
    NSString *alertMsg;
    NSString *badge;
    NSString *sound;
    
    if( [[userInfo objectForKey:@"aps"] objectForKey:@"alert"] != NULL)
    {
        alertMsg = [[userInfo objectForKey:@"aps"] objectForKey:@"alert"];
    }
    else
    {    alertMsg = @"{no alert message in dictionary}";
    }
    
    if( [[userInfo objectForKey:@"aps"] objectForKey:@"badge"] != NULL)
    {
        badge = [[userInfo objectForKey:@"aps"] objectForKey:@"badge"];
    }
    else
    {    badge = @"{no badge number in dictionary}";
    }
    
    if( [[userInfo objectForKey:@"aps"] objectForKey:@"sound"] != NULL)
    {
        sound = [[userInfo objectForKey:@"aps"] objectForKey:@"sound"];
    }
    else
    {   sound = @"{no sound in dictionary}";
    }
    
    // Mostro un alert a seconda della richiesta
    if (application.applicationState==UIApplicationStateActive)
    {
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
        AudioServicesPlaySystemSound (1007);
        NSString* alert_msg = alertMsg;
        UIAlertView *alert;
        if ([alert_msg rangeOfString:@"spesa"].location != NSNotFound) {
            alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:self  cancelButtonTitle:@"Cancella"   otherButtonTitles:@"Aggiona", nil];
        } else {
            alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:nil  cancelButtonTitle:@"OK"   otherButtonTitles:nil];
        }
        [alert show];
    } else if ([alertMsg rangeOfString:@"spesa"].location != NSNotFound)
    {
        NSString* alert_msg = alertMsg;
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:self  cancelButtonTitle:@"Cancella"   otherButtonTitles:@"Aggiona", nil];
        [alert show];
    }

#endif
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        //NSLog(@"Bottone cancella");
    }
    if (buttonIndex == 1)
    {
        QuantityTableViewController * vc = [[QuantityTableViewController alloc] initWithCoder:nil];
        [vc updateCart:nil];
    }
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    if (application.applicationState==UIApplicationStateActive)
    {
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
        AudioServicesPlaySystemSound (1007);
        NSString* alert_msg = notification.alertBody;
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:nil  cancelButtonTitle:@"OK"   otherButtonTitles:nil];
        [alert show];
    }
}

+ (NSString *)GetUUID
{
    CFUUIDRef theUUID = CFUUIDCreate(kCFAllocatorDefault);
    NSString* string = (__bridge_transfer NSString*)CFUUIDCreateString(kCFAllocatorDefault, theUUID);
    CFRelease(theUUID);
    return string;
}

#pragma mark - Custom

- (void)selectInitialVC
{
    NSString *deviceType = [UIDevice currentDevice].model;
 
    UIStoryboard *storyboard;
    if ([deviceType isEqualToString:@"iPhone"] || [deviceType isEqualToString:@"iPhone Simulator"] ) {
        storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    } else {
        storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
    }
    
    if([defaults boolForKey:@"logged"])
    {
        // Imposto i parametri della richiesta POST
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"login.do_login", @"username":[defaults objectForKey:@"username"], @"passwd": [defaults objectForKey:@"password"]};
        
        // Eseguo la richiesta
        [manager POST:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
        {
            //NSLog(@"controllo OK");
            
            NSMutableDictionary *json = (NSMutableDictionary *) responseObject;
            if([[json valueForKey:@"logged"] boolValue])
            {
                self.window.rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"logged"];
            }
            else
            {
                NSString *alert_msg = @"L'utente attuale è stato rimosso";
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:nil  cancelButtonTitle:@"OK"   otherButtonTitles:nil];
                [alert show];
                self.window.rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"not_logged"];
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            //NSLog(@"controllo NO");
            
        }];
    
    }
    else
    {
       self.window.rootViewController = [storyboard instantiateViewControllerWithIdentifier:@"not_logged"];
    }
}



@end
