//
//  AppDelegate.h
//  CasaPlus
//
//  Created by Luca Finocchio on 04/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewController.h"
#import "ClockViewController.h"
#import "RecipeTableViewController.h"

@class ViewController;
@class ClockViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *tableController;
@property (strong, nonatomic) RecipeTableViewController *recipeTableController;
@property (strong, nonatomic) ClockViewController *clockController;

- (void)selectInitialVC;

@end
