//
//  QuantityTableViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 15/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "QuantityTableViewController.h"
#import "quantityTableView.h"
#import "UIImageView+AFNetworking.h"
#import "PrintTableViewController.h"
#import "UIKit+AFNetworking.h"
#import "AFNetworking.h"
#import "Product.h"
#import "CartItem.h"
#import "TableViewController.h"

@interface QuantityTableViewController ()
{
    NSUserDefaults *defaults;
    BOOL del;
    MBProgressHUD *HUD;
}

@property (nonatomic) NSInteger tmpid;
@property (strong, nonatomic) UILabel *label;
@property (strong, nonatomic) UITextField *selectedTextField;

@end

@implementation QuantityTableViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
    }
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [nc addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Setto i delagate della lista
    [self.tableView setDelegate:self];
    [self.tableView setDataSource:self];
    
    // Setto lo sfondo della lista
    UIColor *backgroundColor = [UIColor colorWithRed:0.0 green:0.56 blue:0.8 alpha:1.0];
    self.tableView.backgroundView = [[UIView alloc]initWithFrame:self.tableView.bounds];
    self.tableView.backgroundView.backgroundColor = backgroundColor;
    
    // Setto l'immagine del carrello nella toolbar
    UIImage *remoteCart = [UIImage imageNamed:@"carrello"];
    UIButton *cart = [UIButton buttonWithType:UIButtonTypeCustom];
    cart.bounds = CGRectMake( 0, 0, 27, 27 );
    [cart setImage:remoteCart forState:UIControlStateNormal];
    [cart addTarget:self action:@selector(updateCart:) forControlEvents:UIControlEventTouchUpInside];
    [self.remoteCart setCustomView:cart];
    
    // Setto una view alternativa se la lista è vuota
    CGRect titleLabelFrame;
    if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"]) {
        titleLabelFrame = CGRectMake(75, 250, 175, 50);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
    }else{
        titleLabelFrame = CGRectMake(234, 550, 300, 100);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:25];
    }
    self.label.textColor = [UIColor blackColor];
    self.label.text = @"Lista vuota";
    self.label.textAlignment = NSTextAlignmentCenter;
    [self.label setBackgroundColor:[UIColor whiteColor]];
    [self.label.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.label.layer setBorderWidth:2.0f];
    self.label.layer.cornerRadius = 5.0f;
    [self.view addSubview:self.label];
    if (self.cart.cartItems.count == 0){
        
        [self.tableView setHidden:YES];
        [self.label setHidden:NO];
        [self.print setEnabled:NO];
    } else {
        [self.tableView setHidden:NO];
        [self.label setHidden:YES];
        [self.print setEnabled:YES];
    }
    
}

-(void) viewWillDisappear:(BOOL)animated {
    
    // Salvo il carrello attuale
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:self.cart];
    [defaults setObject:encodedObject forKey:@"cart"];
    
    [super viewWillDisappear:animated];
}

#pragma mark - Table View Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.cart.cartItems count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Recupero la generica riga della tabella
    static NSString *cellIdentifier = @"cellQuantity";
    quantityTableView *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    // Recupero dalla lista il prodotto relativo alla riga selzionata
    CartItem *cartItem = [self.cart.cartItems objectAtIndex:indexPath.row];
    if (cell == nil) cell = [[quantityTableView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];

    // Setto le label e l'immagine della riga corrente
    cell.name.text = cartItem.product.name;
    NSMutableString *tmpcat = [NSMutableString string];
    for (NSString *cat in cartItem.product.category){
        [tmpcat appendString:[NSString stringWithFormat:@"%@, ",cat]];
    }
    [tmpcat deleteCharactersInRange:NSMakeRange([tmpcat length]-2, 1)];
    if ([defaults boolForKey:@"pref_show_category"])
        cell.category.text = [tmpcat lowercaseString];
    if (cartItem.quantityCart)
        cell.quantity.text = cartItem.quantityCart;
    else
        cell.quantity.text = @"0";
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",cartItem.product.img ];
    [cell.image setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    
    // Setto le azioni relative ai bottoni e gli assegno anche la riga corrente
    cell.deleteButton.tag = indexPath.row;
    [cell.deleteButton addTarget:self action:@selector(deleteToCart:) forControlEvents:UIControlEventTouchUpInside];
    cell.quantity.tag = indexPath.row;
    [cell.quantity setDelegate:self];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Manage Segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"productPrint"]) {
        PrintTableViewController *element = segue.destinationViewController;
        element.cart = self.cart;
        element.delegate = self;
    }
}

#pragma mark - Custom

- (void)aggiornaCart:(Cart *)ci
{
    self.cart = ci;
    if (self.cart.cartItems.count == 0){
        
        [self.tableView setHidden:YES];
        [self.label setHidden:NO];
        [self.print setEnabled:NO];
    } else {
        [self.tableView setHidden:NO];
        [self.label setHidden:YES];
        [self.print setEnabled:YES];
    }
    [self.tableView reloadData];
}

- (void) deleteToCart:(id)sender
{
    del = YES;
    UIButton* btn = (UIButton *) sender;
    [self.cart.cartItems removeObjectAtIndex:btn.tag];
    
    // Setto una view alternativa se la lista è vuota
    if (self.cart.cartItems.count == 0){
        
        [self.tableView setHidden:YES];
        [self.label setHidden:NO];
        [self.print setEnabled:NO];
    } else {
        [self.tableView setHidden:NO];
        [self.label setHidden:YES];
        [self.print setEnabled:YES];
    }
    
    [self.tableView reloadData];
}

- (void)updateCart:(id)sender
{
    if (sender) {
        HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
        [self.navigationController.view addSubview:HUD];
        HUD.delegate = self;
        HUD.labelText = @"Carrello Remoto";
        HUD.detailsLabelText = @"Caricamento in corso ...";
        HUD.square = YES;
        [HUD show:YES];
    } else {
        if (![defaults objectForKey:@"cart"]){
            self.cart = [[Cart alloc] init];
            self.cart.cartItems = [[NSMutableArray alloc] init];
        }else{
            NSData *encodedObject = [defaults objectForKey:@"cart"];
            self.cart = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
        }
    }

    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"cart.get_cart", @"username": [NSString stringWithFormat:@"%@",[defaults objectForKey:@"username"]]};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        // Recupero i prodotti dal josn e li inserisco in un array
        NSMutableArray *productsTMP =[[NSMutableArray alloc] init];
        NSMutableDictionary *jsonDict = (NSMutableDictionary *) responseObject;
        NSArray *products = [jsonDict objectForKey:@"cart"];
        
        [products enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            
            
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product.id ==[c] %@", [obj objectForKey:@"id_prod"]];
            
            if ([[self.cart.cartItems filteredArrayUsingPredicate:predicate] count] == 0){
            
                if ([[obj objectForKey:@"id_prod"] integerValue] != self.tmpid){
                    //NSLog(@"id: %@", [obj objectForKey:@"id_prod"]);
                    CartItem *ci = [[CartItem alloc] init];
                    Product *product = [[Product alloc] init];
                    product.id = [obj objectForKey:@"id_prod"];
                    product.name = [[obj objectForKey:@"nome"] capitalizedString];
                    product.category = [[NSMutableArray alloc] init];
                    [product.category addObject: [[obj objectForKey:@"categoria"] uppercaseString]];
                    product.price = [[obj objectForKey:@"prezzo"] floatValue];
                    product.img = [obj objectForKey:@"img_path"];
                    self.tmpid = [[obj objectForKey:@"id_prod"] integerValue];
                    ci.product = product;
                    ci.quantityCart = [obj objectForKey:@"quantita"];
                    [productsTMP addObject:ci];
                } else {
                    [[[[productsTMP lastObject] product] category]addObject: [[obj objectForKey:@"categoria"] uppercaseString]];
                }
            } else {
                [[[self.cart.cartItems filteredArrayUsingPredicate:predicate] objectAtIndex:0] setQuantityCart: [obj objectForKey:@"quantita"]];
            }
            
        }];
        [self.cart.cartItems addObjectsFromArray:[productsTMP copy]];
        
        if (sender) {
            if(self.cart.cartItems.count != 0){
                [self.tableView setHidden:NO];
                [self.label setHidden:YES];
                [self.print setEnabled:YES];
            } else {
                [self.tableView setHidden:YES];
                [self.label setHidden:NO];
                [self.print setEnabled:NO];
            }
            
            [HUD hide:YES];
            [HUD removeFromSuperview];
            
            [self.tableView reloadData];
        } else {
            NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:self.cart];
            [defaults setObject:encodedObject forKey:@"cart"];
            
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            ViewController *tvc = [storyboard instantiateViewControllerWithIdentifier:@"tableViewController"];
            [((UINavigationController*)[[UIApplication sharedApplication] delegate].window.rootViewController) pushViewController:tvc animated:NO];
            [tvc performSegueWithIdentifier:@"productQuantity" sender:nil];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        // Mostro un alert con il messaggio di errore
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
                                                          message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        
        if (sender) {
            // Setto una view alternativa se la lista è vuota
            [self.tableView setHidden:YES];
            [self.label setHidden:NO];
            [self.print setEnabled:NO];
        }
        
    }];

}

#pragma mark - UITextFieldDelegate

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.selectedTextField = textField;
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if (del) del = NO; else [[self.cart.cartItems objectAtIndex:textField.tag] setQuantityCart:textField.text];
}

-(void) keyboardWillShow:(NSNotification *) note
{
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere:)];
    [self.view addGestureRecognizer:tapRecognizer];
}

-(void) keyboardWillHide:(NSNotification *) note
{
    //UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere:)];
    //[self.view removeGestureRecognizer:tapRecognizer];
    [self.view removeGestureRecognizer:[[self.view gestureRecognizers] objectAtIndex:0]];
}

-(void)didTapAnywhere: (UITapGestureRecognizer*) recognizer
{
    [self.selectedTextField resignFirstResponder];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}



@end
