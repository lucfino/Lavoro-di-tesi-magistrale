//
//  RecipeStepViewController.h
//  CasaPlus
//
//  Created by Daniele Leombruni on 26/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Recipe.h"
#import "MBProgressHUD.h"
#import "StepView.h"

@interface RecipeStepViewController : UIViewController<MBProgressHUDDelegate> {
    NSTimer *timer;
}

@property (weak, nonatomic) IBOutlet UILabel *nome;
@property (strong, nonatomic) IBOutlet UIView *stepView;

@property (strong, nonatomic) Recipe *recipe;

@end
