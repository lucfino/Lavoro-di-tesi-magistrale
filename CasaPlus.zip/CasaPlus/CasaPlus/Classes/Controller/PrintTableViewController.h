//
//  PrintTableViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 17/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#import <CoreGraphics/CoreGraphics.h>
#import <CoreLocation/CoreLocation.h>
#import "Cart.h"

@protocol sendDataProtocol <NSObject>

- (void)aggiornaCart:(Cart *)ci;

@end

@interface PrintTableViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UIPrintInteractionControllerDelegate, CLLocationManagerDelegate>

@property (strong, nonatomic) Cart *cart;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *cancella;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *print;
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (strong, nonatomic) NSMutableArray *stores;

@property(nonatomic,assign)id delegate;

@end
