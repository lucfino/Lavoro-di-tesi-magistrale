//
//  PrintTableViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 17/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "PrintTableViewController.h"
#import "Product.h"
#import "CartItem.h"
#import "UIImageView+AFNetworking.h"
#import "AFNetworking.h"
#import "printTableView.h"
#import "PrintElementController.h"
#import "Store.h"

@interface PrintTableViewController ()
{
    NSUserDefaults *defaults;
}

@property (strong, nonatomic) UILabel *label;

@end

@implementation PrintTableViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
        
        self.stores = [[NSMutableArray alloc] init];
        
        // Create location manager with filters set for battery efficiency.
        self.locationManager = [[CLLocationManager alloc] init];
        self.locationManager.delegate = self;
        self.locationManager.distanceFilter = kCLLocationAccuracyHundredMeters;
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Setto i delagate della lista
    [self.tableView setDelegate:self];
    [self.tableView setDataSource:self];
    
    // Setto lo sfondo della lista
    UIColor *backgroundColor = [UIColor colorWithRed:0.0 green:0.56 blue:0.8 alpha:1.0];
    self.tableView.backgroundView = [[UIView alloc]initWithFrame:self.tableView.bounds];
    self.tableView.backgroundView.backgroundColor = backgroundColor;
    
    // Setto una view alternativa se la lista è vuota
    CGRect titleLabelFrame;
    if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"]) {
        titleLabelFrame = CGRectMake(75, 250, 175, 50);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
    }else{
        titleLabelFrame = CGRectMake(234, 550, 300, 100);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:25];
    }
    self.label.textColor = [UIColor blackColor];
    self.label.text = @"Lista vuota";
    self.label.textAlignment = NSTextAlignmentCenter;
    [self.label setBackgroundColor:[UIColor whiteColor]];
    [self.label.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.label.layer setBorderWidth:2.0f];
    self.label.layer.cornerRadius = 5.0f;
    [self.view addSubview:self.label];
    if (self.cart.cartItems.count == 0){
        
        [self.tableView setHidden:YES];
        [self.label setHidden:NO];
        [self.print setEnabled:NO];
    } else {
        [self.tableView setHidden:NO];
        [self.label setHidden:YES];
        [self.print setEnabled:YES];
    }
    
    // Creo un array contenente i negozi che vendono i prodotti nel carrello
    [self getStoreOutOfServer];
    
    // Aggiungo l'azione al bottone per cancellare il carrello
    [self.cancella setAction:@selector(deleteCart:)];
    [self.print setAction:@selector(print:)];

    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
    [self.locationManager stopUpdatingLocation];
    self.locationManager.delegate = nil;
	self.locationManager = nil;
    
}

-(void) viewWillDisappear:(BOOL)animated {
    
    // Salvo il carrello attuale
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:self.cart];
    [defaults setObject:encodedObject forKey:@"cart"];
    [self.delegate aggiornaCart:self.cart];
    
    [super viewWillDisappear:animated];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.cart.cartItems count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Recupero la generica riga della tabella
    static NSString *cellIdentifier = @"cellPrint";
    printTableView *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    // Recupero dalla lista il prodotto relativo alla riga selzionata
    CartItem *cartItem = [self.cart.cartItems objectAtIndex:indexPath.row];
    if (cell == nil) cell = [[printTableView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    
    // Setto le label e l'immagine della riga corrente
    cell.name.text = cartItem.product.name;
    if (cartItem.quantityCart)
        cell.quantity.text = [NSString stringWithFormat:@"Quantità: %@", cartItem.quantityCart];
    else
        cell.quantity.text = @"Quantità: 0";
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",cartItem.product.img ];
    [cell.image setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    
    // Cambio lo stato della checkbox (modificando l'immagine)
    if (cartItem.selected) {
        [cell.checkbox setBackgroundImage:[UIImage imageNamed:@"button_checked" ] forState:UIControlStateNormal];
    }else{
        [cell.checkbox setBackgroundImage:[UIImage imageNamed:@"button_unchecked" ] forState:UIControlStateNormal];
    }
    
    // Setto l'azione relativa al bottone e gli assegno la riga corrente
    cell.checkbox.tag = indexPath.row;
    [cell.checkbox addTarget:self action:@selector(checked:) forControlEvents:(UIControlEventTouchUpInside)];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Custom

- (void)checked:(id)sender
{
    UIButton* btn = (UIButton *) sender;
    if (![[self.cart.cartItems objectAtIndex:btn.tag] selected]) {
        [btn setBackgroundImage:[UIImage imageNamed:@"button_checked" ] forState:UIControlStateNormal];
        [[self.cart.cartItems objectAtIndex:btn.tag] setSelected:YES];
    }else{
        [btn setBackgroundImage:[UIImage imageNamed:@"button_unchecked" ] forState:UIControlStateNormal];
        [[self.cart.cartItems objectAtIndex:btn.tag] setSelected:NO];
    }
}

- (void)aggiornaCheck:(CartItem *)ci{
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product.id ==[c] %@", ci.product.id];
    [[[self.cart.cartItems filteredArrayUsingPredicate:predicate] objectAtIndex:0] setSelected:ci.selected];
    [self.tableView reloadData];
}

-(CGContextRef) copyCreatePDFContext:(CGRect)inMediaBox path:(CFStringRef) path
{
    CGContextRef myOutContext = NULL;
    CFURLRef url;
    url = CFURLCreateWithFileSystemPath (NULL,path,kCFURLPOSIXPathStyle,false);
    if (url != NULL) {
        myOutContext = CGPDFContextCreateWithURL (url,&inMediaBox,NULL);
        CFRelease(url);
    }
    return myOutContext;
}

- (void)print:(id)sender
{
    //Path
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"lista.pdf"];
    
    //Context
    CGRect sizeOfA4 = CGRectMake(0, 0, 595, 842);
    CGContextRef pdfContext = [self copyCreatePDFContext:sizeOfA4 path:(__bridge CFStringRef)writableDBPath];
    CGPDFContextBeginPage(pdfContext, NULL);
    UIGraphicsPushContext(pdfContext);
    CGRect bounds = CGContextGetClipBoundingBox(pdfContext);
    CGContextScaleCTM(pdfContext, 1.0, -1.0);
    CGContextTranslateCTM(pdfContext, 0.0, -bounds.size.height);
    
    //Attributes
    NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByClipping;
    paragraphStyle.alignment = NSTextAlignmentCenter;
    NSDictionary *attributes = @{
                                 NSFontAttributeName: [UIFont boldSystemFontOfSize:15.0f],
                                 NSParagraphStyleAttributeName: paragraphStyle
                                };
    
    // Titolo
    NSString *logo = @"Lista della spesa";
    [logo drawInRect:CGRectMake(175, 10, 200, 20) withAttributes:attributes];
    
    // Lista - Header
    NSString *categoryTitle = @"Immagine";
    [categoryTitle drawInRect:CGRectMake(10, 50, 75, 20) withAttributes:attributes];
    
    NSString *productTitle = @"Prodotto";
    [productTitle drawInRect:CGRectMake(75, 50, 320, 20) withAttributes:attributes];
    
    NSString *quantityTitle = @"Quantità";
    [quantityTitle  drawInRect:CGRectMake(395, 50, 200, 20) withAttributes:attributes];
    int count = 1;
    attributes = @{ NSFontAttributeName: [UIFont boldSystemFontOfSize:12.0f],
                    NSParagraphStyleAttributeName: paragraphStyle
                    };
    
    // Lista - Body
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"selected == YES"];
    if ([[self.cart.cartItems filteredArrayUsingPredicate:predicate] count] != 0) {
        for (CartItem* obj in self.cart.cartItems)
        {
            if (obj.selected)
            {
                NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",obj.product.img ];
                UIImageView *tmp = [[UIImageView alloc] init];
                [tmp setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product"]];
                CGRect drawRect = CGRectMake(20, 5+75*count, 50, 50);
                [tmp.image drawInRect:drawRect];
                
                NSString *productName = obj.product.name;
                [productName drawInRect:CGRectMake(75, 25+75*count, 320, 20) withAttributes:attributes];
                
                NSString *quantity = obj.quantityCart;
                if (!quantity)
                    quantity = @"0";
                [quantity  drawInRect:CGRectMake(395, 25+75*count, 200, 20) withAttributes:attributes];
                
                count++;
            }
        }
    
        //Clean
        UIGraphicsPopContext();
        CGPDFContextEndPage(pdfContext);
        CGPDFContextClose(pdfContext);
        
        //print
        NSData *printData = [NSData dataWithContentsOfFile:writableDBPath];
        [self printdoc:printData];
        if (pdfContext)
            CFRelease(pdfContext);
        
    }
    else
    {
        NSString* alert_msg = @"Nessun elemento selezionato";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:nil  cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }

}

#pragma mark -
#pragma mark UIPrintInteractionControllerDelegate

- (void)printdoc:(NSData *)myData
{
	UIPrintInteractionController *pic = [UIPrintInteractionController sharedPrintController];
	if(pic && [UIPrintInteractionController canPrintData: myData] ) {
		pic.delegate = self;
		UIPrintInfo *printInfo = [UIPrintInfo printInfo];
		printInfo.outputType = UIPrintInfoOutputGeneral;
		printInfo.jobName = @"Lista della Spesa";
		printInfo.duplex = UIPrintInfoDuplexLongEdge;
		pic.printInfo = printInfo;
		pic.showsPageRange = YES;
		pic.printingItem = myData;
        
		void (^completionHandler)(UIPrintInteractionController *, BOOL, NSError *) = ^(UIPrintInteractionController *pic, BOOL completed, NSError *error) {
			if (!completed && error) {
				UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Attenzione"
                                                                    message:@"Si è verificato un errore durante la stampa.\nControlla le impostazioni di AirPrint e riprova."
                                                                   delegate:nil
                                                          cancelButtonTitle:@"OK"
                                                          otherButtonTitles:nil];
				[alertView show];
			} 
		};
		[pic presentAnimated:YES completionHandler:completionHandler];
	}	
}

- (void)deleteCart:(id)sender
{
    [self.tableView setHidden:YES];
    [self.label setHidden:NO];
    [self.print setEnabled:NO];
    [self.cart.cartItems removeAllObjects];
    [self.stores removeAllObjects];
    [self.tableView reloadData];
}


#pragma mark - Manage for segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"printDetail"]) {
        PrintElementController *element = segue.destinationViewController;
        element.cartItem = [self.cart.cartItems objectAtIndex: self.tableView.indexPathForSelectedRow.row];
        element.delegate = self;
    }
}

#pragma mark - Custum

-(void)getStoreOutOfServer
{
    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"store.get_store"};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        // Recupero i prodotti dal josn e li inserisco in un array
        NSMutableDictionary *jsonDict = (NSMutableDictionary *) responseObject;
        NSArray *stores = [jsonDict objectForKey:@"stores"];
        
        [stores enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            
            Store *s = [[Store alloc] init];
            s.id = [[obj objectForKey:@"id"] integerValue];
            s.nome = [obj objectForKey:@"nome"];
            s.lat = [[obj objectForKey:@"lat"] doubleValue];
            s.lon = [[obj objectForKey:@"lon"] doubleValue];
            s.indirizzo = [obj objectForKey:@"indirizzo"];
            s.telefono = [obj objectForKey:@"telefono"];
            s.timestamp = [obj objectForKey:@"timestamp"];
            
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product.id ==[c] %@", [obj objectForKey:@"product_id"]];
            if ([[self.cart.cartItems filteredArrayUsingPredicate:predicate] count] != 0){
                Product *p = [[[self.cart.cartItems filteredArrayUsingPredicate:predicate] objectAtIndex:0] product];
                if (!p.stores)
                    p.stores = [[NSMutableArray alloc] init];
                NSPredicate *pre = [NSPredicate predicateWithFormat:@"id == %d",s.id];
                if ([[p.stores filteredArrayUsingPredicate:pre] count] == 0) {
                    [p.stores addObject:s];
                }
            }
        }];
        
        for (int i=0; i<[self.cart.cartItems count]; i++) {
            Product *p = [[self.cart.cartItems objectAtIndex:i] product];
            for (int j=0; j<[p.stores count]; j++) {
                Store *s = [p.stores objectAtIndex:j];
                NSPredicate *pre = [NSPredicate predicateWithFormat:@"id == %d", s.id];
                if ([[self.stores filteredArrayUsingPredicate:pre] count] == 0) {
                    [self.stores addObject:s];
                }
            }
        }
        
        // Start updating location changes.
        [self.locationManager startUpdatingLocation];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        // Mostro un alert con il messaggio di errore
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
                                                          message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        
    }];

}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSMutableArray *tmp = [[NSMutableArray alloc] init];
    for (Store* store in self.stores)
    {
        CLLocation *location = [[CLLocation alloc] initWithLatitude:store.lat longitude:store.lon];
        CLLocationDistance distance = [newLocation distanceFromLocation:location];
        if (distance < 300)
        {
            [self updateWithEvent:[NSString stringWithFormat:@"Sei vicino a %@", store.nome]];
            [tmp addObject:store];
        }
    }
    [self.stores removeObjectsInArray:tmp];
}

- (void)updateWithEvent:(NSString *)event
{
	// Update the icon badge number.
	[UIApplication sharedApplication].applicationIconBadgeNumber++;
    
    //Istanzio la variabile che mi servirà per impostare la local notification
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    
    //Imposto il fireDate che è la data ed ora di visualizzazione del messaggio
    notification.fireDate = [NSDate date];
    
    /*Imposto il timezone per esser certo che la data e l'ora impostate siano sempre corrette,
     assegnando infatti l'oggetto timeZone, il fireDate viene regolato automaticamente
     quando ci sono cambiamenti di fuso orario, di default il timeZone è "nil".*/
    notification.timeZone = [NSTimeZone defaultTimeZone];
    
    //Messaggio che verrà visualizzato dall'iOS se la nostra applicazione è spenta
    notification.alertBody = [NSString stringWithFormat:@"%@", event];
    
    //Nome del pulsante per avviare la nostra applicazione
    notification.alertAction = @"Dettagli";
    
    //Qui possiamo impostare un suono, per semplicità impostiamo il suono di default
    notification.soundName = UILocalNotificationDefaultSoundName;
    
    //aggiungiamo un dictionary con informazioni a piacere, in questo caso ho inserito il nome dell'evento
    //per utilizzarlo successivamente richiamandolo in base alla costante
    NSDictionary *infoDict = [NSDictionary dictionaryWithObjectsAndKeys:event,@"event", nil];
    notification.userInfo = infoDict;
    
    //Imposto la local notification
    [[UIApplication sharedApplication] scheduleLocalNotification:notification];
}

@end
