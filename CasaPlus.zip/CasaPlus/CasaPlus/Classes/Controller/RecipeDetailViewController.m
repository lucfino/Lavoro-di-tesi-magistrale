//
//  RecipeDetailViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RecipeDetailViewController.h"
#import "UIImageView+AFNetworking.h"
#import "RecipeToolsViewController.h"

@interface RecipeDetailViewController (){
    NSUserDefaults *defaults;
}

@end

@implementation RecipeDetailViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
	self.label.text = self.recipe.nome;
    [self.label.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.label.layer setBorderWidth:2.0f];
    self.label.layer.cornerRadius = 5.0f;
    
    // immagine media a difficile
    if ([self.recipe.difficolta isEqualToString:@"Facile"]) {
        [self.difficolta setImage:[UIImage imageNamed:@"facile"]];
    } else if ([self.recipe.difficolta isEqualToString:@"Media"]){
        [self.difficolta setImage:[UIImage imageNamed:@"media"]];
    } else {
        [self.difficolta setImage:[UIImage imageNamed:@"difficile"]];
    }
    
    if ([self.recipe.calorie isEqualToString:@"Magro"]) {
        [self.calorie setImage:[UIImage imageNamed:@"magro"]];
    } else {
        [self.calorie setImage:[UIImage imageNamed:@"grasso"]];
    }
    
    self.persone.text = self.recipe.persone;
    
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",self.recipe.img ];
    [self.immagine setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    
    self.descrizione.text = self.recipe.descrizione;
    [self.descrizione.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.descrizione.layer setBorderWidth:2.0f];
    self.descrizione.layer.cornerRadius = 5.0f;
}

#pragma mark - Menage Segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([[segue identifier] isEqualToString:@"recipeTools"]) {
        RecipeToolsViewController *element = segue.destinationViewController;
        element.recipe = self.recipe;
    }
}


@end
