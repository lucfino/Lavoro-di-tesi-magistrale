//
//  ElementController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 08/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "ElementController.h"
#import "UIKit+AFNetworking.h"
#import <AVFoundation/AVFoundation.h>

@interface ElementController ()
{
    NSUserDefaults *defaults;
}

@end

@implementation ElementController

@synthesize delegate;

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
    {
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Setto le label e l'immagine del prodotto 
    self.productName.text = [[self.product name] uppercaseString];
    [self.productName.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.productName.layer setBorderWidth:2.0f];
    self.productName.layer.cornerRadius = 5.0f;
    NSMutableString *tmpcat = [NSMutableString string];
    for (NSString *cat in self.product.category){
        [tmpcat appendString:[NSString stringWithFormat:@"%@, ",cat]];
    }
    [tmpcat deleteCharactersInRange:NSMakeRange([tmpcat length]-2, 1)];
    self.productCategory.text = [tmpcat lowercaseString];
    [self.productCategory.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.productCategory.layer setBorderWidth:2.0f];
    self.productCategory.layer.cornerRadius = 5.0f;
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/", self.product.img ];
    [self.productImage setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product"]];
    
    // Cambio l'immagine del bottone a secondo se è inserito nella lista o meno
    if (self.selected){
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"]) {
            [self.productAdd setImage:[UIImage imageNamed:@"removecart"] forState:UIControlStateNormal];
            [self.productAdd setImage:[UIImage imageNamed:@"removecart_press"] forState:UIControlStateHighlighted];
        } else {
            [self.productAdd setBackgroundImage:[UIImage imageNamed:@"removecart"] forState:UIControlStateNormal];
            [self.productAdd setBackgroundImage:[UIImage imageNamed:@"removecart_press"] forState:UIControlStateHighlighted];
        }
    }else{
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"]) {
            [self.productAdd setImage:[UIImage imageNamed:@"addcart"] forState:UIControlStateNormal];
            [self.productAdd setImage:[UIImage imageNamed:@"addcart_press"] forState:UIControlStateHighlighted];
        } else {
            [self.productAdd setBackgroundImage:[UIImage imageNamed:@"addcart"] forState:UIControlStateNormal];
            [self.productAdd setBackgroundImage:[UIImage imageNamed:@"addcart_press"] forState:UIControlStateHighlighted];
        }
    }
    
    [self.productAdd setHidden:!self.cartVisible];
    
    // Aggiungo le azioni ai bottoni
    [self.productAudio addTarget:self action:@selector(playAudio:) forControlEvents:UIControlEventTouchUpInside];
    [self.productAdd addTarget:self action:@selector(add:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)playAudio:(id)sender
{
    // Imposto i parametri del sintetizzatore vocale
    AVSpeechSynthesizer *synth = [[AVSpeechSynthesizer alloc] init];
    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.product.name];
    [utterance setRate:0.16];
    [utterance setVoice:[AVSpeechSynthesisVoice voiceWithLanguage:@"it-IT"]];
    [synth speakUtterance:utterance];
}

- (void)add:(id)sender
{
    [delegate addSelectedProduct:self.product];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
