//
//  RecipeTableViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RecipeTableViewHeader.h"
#import "MBProgressHUD.h"

@interface RecipeTableViewController : UIViewController<SectionRecipeHeaderViewDelegate, UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tableView;

- (void)getRecipesOutOfServer;

@end
