//
//  LoginViewController.m
//  OmniaCode
//
//  Created by Francesco Tarquini
//  Copyright (c) 2013 BiTE s.r.l. All rights reserved.
//

#import "LoginViewController.h"
#import "AFNetworking.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "AppDelegate.h"

@interface LoginViewController (){
    NSUserDefaults *defaults;
    MBProgressHUD *HUD;
}

@property (weak, nonatomic) IBOutlet UITextField *usernameTXT;
@property (weak, nonatomic) IBOutlet UITextField *passwordTXT;
@property (strong, nonatomic) IBOutlet UIButton *accedi;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

- (IBAction)loginBT:(UIButton *)sender;

@end


@implementation LoginViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
    {
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
    }
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    [nc addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [nc addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
 
    return self;
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.scrollView setContentOffset:CGPointMake(0, 70)];
}

-(void) do_loginwith:(NSString *)username passwd:(NSString *)password
{
    HUD = [[MBProgressHUD alloc] initWithView:self.tabBarController.view];
	[self.tabBarController.view addSubview:HUD];
	HUD.delegate = self;
	HUD.labelText = @"Login";
	HUD.detailsLabelText = @"Verifica Utente";
    HUD.square = YES;
    [HUD show:YES];
    
    #if TARGET_IPHONE_SIMULATOR || TARGET_IPAD_SIMULATOR
        [defaults setObject:@"not_recived" forKey:@"token"];
    #endif
    
    if ([defaults objectForKey:@"token"] != NULL)
    {
        // Imposto i parametri della richiesta POST
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"login.do_login", @"username":username, @"passwd": password};
        
        // Eseguo la richiesta
        [manager POST:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
        {
            [HUD hide:YES];
            [HUD removeFromSuperview];
            
            NSMutableDictionary *json = (NSMutableDictionary *) responseObject;
            
            if([[json valueForKey:@"logged"] boolValue])
            {
                [defaults setBool:[[json valueForKey:@"logged"] boolValue] forKey:@"logged"];
                [defaults setObject:[json objectForKey:@"name"]  forKey:@"name"];
                [defaults setObject:[json objectForKey:@"username"]  forKey:@"username"];
                [defaults setObject:password  forKey:@"password"];
                [defaults setObject:[json objectForKey:@"email"]  forKey:@"email"];
                [defaults setObject:[json objectForKey:@"id"]  forKey:@"id"];
                [defaults synchronize];
                
                [self setDeviceUser];
                
                AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
                [appDelegate selectInitialVC];
            }
            else
            {
                [HUD hide:YES];
                [HUD removeFromSuperview];
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù"
                                                                message:@"Nome Utente o Password errati!"
                                                               delegate:nil
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles: nil];
                [alert show];
            }
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            
            [HUD hide:NO];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù"
                                                            message:@"Errore nella connessione"
                                                           delegate:nil
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles: nil];
            [alert show];
            
        }];

    }
    
}

-(void)setDeviceUser
{
    // Imposto i parametri della richiesta POST
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_apns", @"task": @"devlists.setUser", @"user":[defaults objectForKey:@"username"], @"devToken":[defaults objectForKey:@"token"]};
    
    // Eseguo la richiesta
    [manager POST:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}

-(void) keyboardWillShow:(NSNotification *) note
{
    NSDictionary* info = [note userInfo];
    
    CGSize keyboardSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    CGPoint buttonOrigin = self.accedi.frame.origin;
    
    CGFloat buttonHeight = self.accedi.frame.size.height;
    
    CGRect visibleRect = self.view.frame;
    
    visibleRect.size.height -= keyboardSize.height;
    
    if (!CGRectContainsPoint(visibleRect, buttonOrigin)){
        
        CGPoint scrollPoint = CGPointMake(0.0, buttonOrigin.y - visibleRect.size.height + buttonHeight + 70);
        
        [self.scrollView setContentOffset:scrollPoint animated:YES];
        
    }

    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere:)];
    [self.view addGestureRecognizer:tapRecognizer];
}

-(void) keyboardWillHide:(NSNotification *) note
{
    [self.scrollView setContentOffset:CGPointZero animated:YES];

    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapAnywhere:)];
    [self.view removeGestureRecognizer:tapRecognizer];
}

-(void)didTapAnywhere: (UITapGestureRecognizer*) recognizer
{
    [self.usernameTXT resignFirstResponder];
    [self.passwordTXT resignFirstResponder];
}

- (IBAction)loginBT:(UIButton *)sender
{
    [self do_loginwith:self.usernameTXT.text passwd:self.passwordTXT.text];
    [self.usernameTXT resignFirstResponder];
    [self.passwordTXT resignFirstResponder];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

@end
