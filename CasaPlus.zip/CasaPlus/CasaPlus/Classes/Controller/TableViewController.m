//
//  ViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 04/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "TableViewController.h"
#import "Product.h"
#import "productTableView.h"
#import "Category.h"
#import "productTableViewHeader.h"
#import "UIImageView+AFNetworking.h"
#import "AFNetworking.h"
#import "AppDelegate.h"
#import "ElementController.h"
#import "Cart.h"
#import "CartItem.h"
#import "QuantityTableViewController.h"


@interface ViewController ()
{
    NSUserDefaults *defaults;
    BOOL isFiltered;
    MBProgressHUD *HUD;
    
}

@property (strong, nonatomic) NSMutableArray *filteredProduct;
@property (strong, nonatomic) Product *currentProduct;
@property (nonatomic,assign) NSInteger openSectionIndex;
@property (nonatomic,strong) NSMutableArray* categories;
@property (nonatomic,strong) NSMutableArray* sectionInfoArray;
@property (nonatomic, strong) Cart *cart;
@property (nonatomic,assign) NSInteger tmpid;

@property (strong, nonatomic) IBOutlet UIBarButtonItem *deleteCart;
@property (strong, nonatomic) IBOutlet UISearchBar *searchbar;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *refresh;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *avanti;

@end

@implementation ViewController

- (id)initWithCoder:(NSCoder *)decoder
{
    if (self = [super initWithCoder:decoder])
    {
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
        
        // Se esiste un carrello lo carico una altrimenti lo istanzio
        if (![defaults objectForKey:@"cart"])
            self.cart = [[Cart alloc] init];
        else{
            NSData *encodedObject = [defaults objectForKey:@"cart"];
            self.cart = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
        }
        
        //  Istanzio la lista dei prodotti e li recupero insieme alle categorie dal json sul server
        self.products = [[NSMutableArray alloc] init];
        
        return self;
    }
    
    return nil;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self getProductOutOfServer];
    
    // Cambio il colore e il testo del cancel button della searchbar
    for (UIView *view in self.searchbar.subviews)
    {
        for (id subview in view.subviews)
        {
            if ( [subview isKindOfClass:[UIButton class]] )
            {
                UIButton* cancelBtn = (UIButton*)subview;
                [cancelBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                [cancelBtn setTitle:@"Cancella" forState:UIControlStateNormal];
                break;
            }
        }
    }
    
    // Setto l'indice della sezione aperta
    self.openSectionIndex = NSNotFound;
    
    // Aggiungo l'azione al bottone per cancellare il carrello
    [self.deleteCart setAction:@selector(deleteCart:)];
    
    // Setto lo sfondo della lista
    UIColor *backgroundColor = [UIColor colorWithRed:0.0 green:0.56 blue:0.8 alpha:1.0];
    self.tableView.backgroundView = [[UIView alloc]initWithFrame:self.tableView.bounds];
    self.tableView.backgroundView.backgroundColor = backgroundColor;
    
    // Setto i delagate della lista e della searchbar
    [self.tableView setDelegate:self];
    [self.tableView setDataSource:self];
    [self.searchbar setDelegate:self];
    
    // Richiamo l'app delegate
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.tableController = self;

}

- (void)viewDidAppear:(BOOL)animated
{
    [self.tableView reloadData];
    [super viewDidAppear:animated];
}

-(void) viewWillDisappear:(BOOL)animated
{
    // Salvo il carrello attuale
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:self.cart];
    [defaults setObject:encodedObject forKey:@"cart"];
    
    [super viewWillDisappear:animated];
}

#pragma mark - Table View Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (!isFiltered) return [self.sectionInfoArray count];
    else return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:section];
    NSArray *products = [[sectionInfo objectForKey:@"itemcat"] products];
    int rows = 0;
    if(isFiltered)
        rows = (int)self.filteredProduct.count;
    else if ([[sectionInfo objectForKey:@"opened"] boolValue]){
        NSPredicate *pre = [NSPredicate predicateWithFormat:@"id < %@", @"0"];
        NSArray *noncat = [self.products filteredArrayUsingPredicate:pre];
        if (![[[sectionInfo objectForKey:@"itemcat"] name] isEqualToString:@"NON CATEGORIZZATO"])
            rows = (int)products.count;
        else
            rows = (int)[noncat count];
    }
    return rows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Recupero la generica riga della tabella
    static NSString *cellIdentifier = @"cellProduct";
    productTableView *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    // Recupero dalla lista il prodotto relativo alla riga selzionata
    Product *product;
    if(isFiltered) product = [self.filteredProduct objectAtIndex:indexPath.row];
    else{
        NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:indexPath.section];
        NSString *alphabet = [[sectionInfo objectForKey:@"itemcat"] name];
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"category contains[cd] %@", alphabet];
        NSArray *products = [self.products filteredArrayUsingPredicate:predicate];
        //if ([products count] > 0)
            product = [products objectAtIndex:indexPath.row];
    }
    
    if (cell == nil) cell = [[productTableView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    
    //if (product) {
        // Filtro i prodotti nel carrello in base all'id del prodotto corrente
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product.id ==[c] %@", product.id];
    
        // Cambio lo sfondo a seconda se esiste o no una corrispondenza
        if ([[self.cart.cartItems filteredArrayUsingPredicate:predicate] count] != 0){
            [cell setBackgroundColor:[UIColor greenColor]];
        }else{
            [cell setBackgroundColor:[UIColor whiteColor]];
        }
    
        // Tolgo o aggiungo la freccia sulla riga a secondo se è selezionabile direttamente o no
        if ([defaults boolForKey:@"pref_direct_selection"])
            [cell setAccessoryType:UITableViewCellAccessoryNone];
        else
            [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    
        // Setto le label e l'immagine della riga corrente
        cell.productName.text = product.name;
        NSMutableString *tmpcat = [NSMutableString string];
        for (NSString *cat in product.category){
            [tmpcat appendString:[NSString stringWithFormat:@"%@, ",cat]];
        }
        [tmpcat deleteCharactersInRange:NSMakeRange([tmpcat length]-2, 1)];
        if ([defaults boolForKey:@"pref_show_category"])
            cell.productCategory.text = [tmpcat lowercaseString];
        cell.productPrice.text = [NSString stringWithFormat:@"%.2f €", product.price];
        NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",product.img ];
        [cell.productImage setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    //}
    return cell;
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (isFiltered){
        return 0;
    }
    else if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )
        return 44.0;
    else
        return 88.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Setto il prodotto corrente
    if(isFiltered)
    {
        [self.searchbar resignFirstResponder];
        self.currentProduct = [self.filteredProduct objectAtIndex:indexPath.row];
    }
    else
    {
        NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:indexPath.section];
        NSString *alphabet = [[sectionInfo objectForKey:@"itemcat"] name];
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"category contains[cd] %@", alphabet];
        NSArray *products = [self.products filteredArrayUsingPredicate:predicate];
        self.currentProduct = [products objectAtIndex:indexPath.row];
    }
    
    // Se la selezione è diretta  aggiungo o tolgo il prodotto corrente dal carrello
    if ([defaults boolForKey:@"pref_direct_selection"]){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product.id ==[c] %@", self.currentProduct.id];
        
        if ([[self.cart.cartItems filteredArrayUsingPredicate:predicate] count] != 0){
            [self.cart.cartItems removeObject:[[self.cart.cartItems filteredArrayUsingPredicate:predicate] objectAtIndex:0]];
        }else{
            CartItem *ci = [[CartItem alloc] init];
            ci.product = self.currentProduct;
            [self.cart.cartItems addObject:ci];
        }
    }
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.tableView reloadData];
}


#pragma mark Section header delegate

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:section];
    
    // Setto le label e l'immagine dell'header considerato
    if (![sectionInfo objectForKey:@"headerView"]) {
        CustomTableViewHeader *header = [[CustomTableViewHeader alloc] initWithFrame:CGRectMake(0.0, 0.0, self.tableView.bounds.size.width, 45) section:section delegate:self];
        [header setDelegate:self];
        header.categoryLabel.text = [[[self.sectionInfoArray objectAtIndex:section] objectForKey:@"itemcat"] name];
        NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/", [[sectionInfo objectForKey:@"itemcat"] img] ];
        [header.categoryImg setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_category" ]];
        [sectionInfo setObject:header forKey:@"headerView"];
    }
    return [sectionInfo objectForKey:@"headerView"];
}

-(void)sectionHeaderView:(CustomTableViewHeader*)sectionHeaderView sectionOpened:(NSInteger)sectionOpened {
    
    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:sectionOpened];
	[sectionInfo setObject:[NSNumber numberWithBool:YES] forKey:@"opened"];
    NSArray *products = [[sectionInfo objectForKey:@"itemcat"] products];
    
    // Creo un array che contiene gli indexPath delle righe da inserire
    int countOfRowsToInsert = 0;
    if(isFiltered)
        countOfRowsToInsert = (int)self.filteredProduct.count;
    else if ([[sectionInfo objectForKey:@"opened"] boolValue])
        countOfRowsToInsert = (int)products.count;
    NSMutableArray *indexPathsToInsert = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < countOfRowsToInsert; i++) {
        [indexPathsToInsert addObject:[NSIndexPath indexPathForRow:i inSection:sectionOpened]];
    }
    
    // Creo un array che contiene gli indexPath delle righe da eliminare
    NSMutableArray *indexPathsToDelete = [[NSMutableArray alloc] init];
    NSInteger previousOpenSectionIndex = self.openSectionIndex;
    if (previousOpenSectionIndex != NSNotFound) {
        
		NSMutableDictionary *previousOpenSection = [self.sectionInfoArray objectAtIndex:previousOpenSectionIndex];
        [previousOpenSection setObject:[NSNumber numberWithBool:NO] forKey:@"opened"];
        [[previousOpenSection objectForKey:@"headerView"] toggleOpenWithUserAction:NO];
        
        NSString *alphabet = [[previousOpenSection objectForKey:@"itemcat"] name];
        NSPredicate *predicate;
        predicate = [NSPredicate predicateWithFormat:@"category contains[cd] %@", alphabet];
        NSArray *products = [self.products filteredArrayUsingPredicate:predicate];
        
        int countOfRowsToDelete = 0;
        if(isFiltered)
            countOfRowsToDelete = (int)self.filteredProduct.count;
        else if ([[sectionInfo objectForKey:@"opened"] boolValue])
            countOfRowsToDelete = (int)products.count;
        
        for (NSInteger i = 0; i < countOfRowsToDelete; i++) {
            [indexPathsToDelete addObject:[NSIndexPath indexPathForRow:i inSection:previousOpenSectionIndex]];
        }
    }
    
    
    // Setto le animazioni
    UITableViewRowAnimation insertAnimation;
    UITableViewRowAnimation deleteAnimation;
    if (previousOpenSectionIndex == NSNotFound || sectionOpened < previousOpenSectionIndex) {
        insertAnimation = UITableViewRowAnimationTop;
        deleteAnimation = UITableViewRowAnimationBottom;
    }
    else {
        insertAnimation = UITableViewRowAnimationBottom;
        deleteAnimation = UITableViewRowAnimationTop;
    }
    
    // Applico le animazioni
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:indexPathsToInsert withRowAnimation:insertAnimation];
    [self.tableView deleteRowsAtIndexPaths:indexPathsToDelete withRowAnimation:deleteAnimation];
    [self.tableView endUpdates];
    self.openSectionIndex = sectionOpened;
}

-(void)sectionHeaderView:(CustomTableViewHeader*)sectionHeaderView sectionClosed:(NSInteger)sectionClosed {
    
    //Creo un array che contiene gli indexPath delle righe nella sezione da eliminare
	NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:sectionClosed];
    [sectionInfo setObject:[NSNumber numberWithBool:NO] forKey:@"opened"];
    NSInteger countOfRowsToDeleteC = [self.tableView numberOfRowsInSection:sectionClosed];
    
    if (countOfRowsToDeleteC > 0) {
        NSMutableArray *indexPathsToDelete = [[NSMutableArray alloc] init];
        for (NSInteger i = 0; i < countOfRowsToDeleteC; i++) {
            [indexPathsToDelete addObject:[NSIndexPath indexPathForRow:i inSection:sectionClosed]];
        }
        [self.tableView deleteRowsAtIndexPaths:indexPathsToDelete withRowAnimation:UITableViewRowAnimationTop];
    }
    self.openSectionIndex = NSNotFound;
}

#pragma mark - Menage Segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    // Se clicco sulla riga seleziono l'elemento corrente e lo passo al controller successivo (ElementController)
    if ([[segue identifier] isEqualToString:@"productDetail"]) {
        ElementController *element = segue.destinationViewController;
        element.delegate = self;
        Product *p = [[Product alloc] init];
        if (isFiltered){
            p = [self.filteredProduct objectAtIndex: self.tableView.indexPathForSelectedRow.row];
        } else {
            NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:self.tableView.indexPathForSelectedRow.section];
            NSString *alphabet = [[sectionInfo objectForKey:@"itemcat"] name];
            NSPredicate *predicate;
            predicate = [NSPredicate predicateWithFormat:@"category contains[cd] %@", alphabet];
            NSArray *products = [self.products filteredArrayUsingPredicate:predicate];
            p = [products objectAtIndex: self.tableView.indexPathForSelectedRow.row];
        }
        element.product = p;
        element.cartVisible = YES;
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product.id ==[c] %@", p.id];
        if ([[self.cart.cartItems filteredArrayUsingPredicate:predicate] count] != 0){
            element.selected = YES;
        }
        // altrimenti passo il carrello al controller successivo (QuantityTableViewController)
    }else if ([[segue identifier] isEqualToString:@"productQuantity"]){
        QuantityTableViewController *element = segue.destinationViewController;
        element.cart = self.cart;
    }
}

-(BOOL) shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender
{
    // Abilito o disabilito l'apertura dei dettagli al click della riga
    if ([identifier isEqualToString:@"productDetail"] && [defaults boolForKey:@"pref_direct_selection"])
        return NO;
    else
        return YES;
}

#pragma mark - UISearchBarDelegate

-(void)searchBar:(UISearchBar*)searchbar textDidChange:(NSString*)text
{
    if (self.products.count != 0){
        if(text.length == 0)
        {
            isFiltered = NO;
            [self.searchbar resignFirstResponder];
        }
        else {
            
            isFiltered = YES;
            self.filteredProduct = [[NSMutableArray alloc] init];
            
            for (Product * p in self.products) {
                
                NSRange pname = [p.name rangeOfString:text options:NSCaseInsensitiveSearch];
                if(pname.location != NSNotFound )
                {
                    [self.filteredProduct addObject:p];
                }
            }
        }
        [self.tableView reloadData];
    }
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchbar
{
    self.searchbar.text = @"";
    [self.searchbar resignFirstResponder];
    [self performSelector:@selector(searchBar:textDidChange:) withObject:searchbar withObject:nil ];
}

#pragma mark - Manage refresh

- (IBAction)refresh:(id)sender
{
    self.openSectionIndex = NSNotFound;
    [self getProductOutOfServer];
}

#pragma mark - Custom

- (void)getProductOutOfServer
{
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	HUD.delegate = self;
	HUD.labelText = @"Prodotti";
	HUD.detailsLabelText = @"Caricamento in corso ...";
    HUD.square = YES;
    [HUD show:YES];
    
    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"products.get_product"};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        // Recupero i prodotti dal josn e li inserisco in un array
        NSMutableArray *productsTMP =[[NSMutableArray alloc] init];
        NSMutableDictionary *jsonDict = (NSMutableDictionary *) responseObject;
        NSArray *products = [jsonDict objectForKey:@"products"];
        
        [products enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            
            if ([[obj objectForKey:@"id"] integerValue] != self.tmpid){
                Product *product = [[Product alloc] init];
                product.id = [obj objectForKey:@"id"];
                product.name = [[obj objectForKey:@"nome"] capitalizedString];
                product.category = [[NSMutableArray alloc] init];
                [product.category addObject: [[obj objectForKey:@"categoria"] uppercaseString]];
                product.price = [[obj objectForKey:@"prezzo"] floatValue];
                product.img = [obj objectForKey:@"img"];
                self.tmpid = [[obj objectForKey:@"id"] integerValue];
                [productsTMP addObject:product];
            } else {
                [[[productsTMP lastObject] category] addObject: [[obj objectForKey:@"categoria"] uppercaseString]];
            }
            
        }];
        self.products = [productsTMP copy];
        
        NSPredicate *pre = [NSPredicate predicateWithFormat:@"id < %@", @"0"];
        NSArray *noncat = [self.products filteredArrayUsingPredicate:pre];
        for (int i=0; i<[self.cart.cartItems count]; i++) {
            Product *protmp = [[self.cart.cartItems objectAtIndex:i] product];
            NSPredicate *preTmp = [NSPredicate predicateWithFormat:@"id ==[c] %@", protmp.id];
            NSArray *a = [noncat filteredArrayUsingPredicate:preTmp];
            if ([protmp.id integerValue] < 0 && [a count] == 0) {
                [self.cart.cartItems removeObjectAtIndex:i];
            }
        }
        
        [self getCategoryOutOfServer];
        [self.tableView reloadData];
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        // Mostro un alert con il messaggio di errore
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
                                                          message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
    }];
}

- (void)getCategoryOutOfServer
{
    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"categories.get_category"};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [HUD hide:YES];
        [HUD removeFromSuperview];
        
        // Recupero le categorie dal josn e le inserisco in un array
        NSMutableArray *categoriesTMP =[[NSMutableArray alloc] init];
        NSMutableDictionary *jsonDict = (NSMutableDictionary *) responseObject;
        NSArray *products = [jsonDict objectForKey:@"categories"];
        
        [products enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            
            ProductCategory *category = [[ProductCategory alloc] init];
            category.name = [[obj objectForKey:@"nome"] uppercaseString];
            category.id = [obj objectForKey:@"id"];
            category.timestamp = [obj objectForKey:@"timestamp"];
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"category contains[cd] %@", [[obj objectForKey:@"nome"] uppercaseString]];
            category.products = [[self.products filteredArrayUsingPredicate:predicate] copy];
            category.img = [obj objectForKey:@"img"];
            
            [categoriesTMP addObject:category];
        }];
        self.categories = [categoriesTMP copy];
        
        //  Per ogni categoria creo un oggetto SectionInfo
        NSMutableArray *infoArray = [[NSMutableArray alloc] init];
        for (ProductCategory *itemcat in self.categories) {
            NSMutableDictionary *sectionInfo = [[NSMutableDictionary alloc] init];
            [sectionInfo setObject:itemcat forKey:@"itemcat"];
            if ([defaults boolForKey:@"pref_visual_grouped"] == YES)
                [sectionInfo setObject:[NSNumber numberWithBool:NO] forKey:@"opened"];
            else
                [sectionInfo setObject:[NSNumber numberWithBool:YES] forKey:@"opened"];
            [infoArray addObject:sectionInfo];
        }
        
        self.sectionInfoArray = infoArray;
        [self.tableView reloadData];
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [HUD hide:NO];
        
         // Mostro un alert con il messaggio di errore
         UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
         message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
         delegate:nil
         cancelButtonTitle:@"OK"
         otherButtonTitles:nil];
         [message show];
    }];
}

- (void)addSelectedProduct:(Product *)product
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"product.id ==[c] %@", product.id];
    if ([[self.cart.cartItems filteredArrayUsingPredicate:predicate] count] != 0){
        [self.cart.cartItems removeObject:[[self.cart.cartItems filteredArrayUsingPredicate:predicate] objectAtIndex:0]];
    }else{
        CartItem *ci = [[CartItem alloc] init];
        ci.product = product;
        [self.cart.cartItems addObject:ci];
    }
    [self.tableView reloadData];
}

- (void)deleteCart:(id)sender
{
    [self.cart.cartItems removeAllObjects];
    [self.tableView reloadData];
}


@end
