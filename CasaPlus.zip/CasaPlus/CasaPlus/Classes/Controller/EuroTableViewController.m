//
//  EuroTableViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 23/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "EuroTableViewController.h"
#import "Product.h"
#import "euroTableView.h"
#import "UIImageView+AFNetworking.h"
#import "AFNetworking.h"
#import "ElementController.h"

@interface EuroTableViewController (){
    NSUserDefaults *defaults;
    MBProgressHUD *HUD;
}

@property (nonatomic,assign) NSInteger tmpid;
@property (nonatomic) float m;
@property (nonatomic) float m1;
@property (nonatomic,strong) UILabel *label;

@end

@implementation EuroTableViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Setto i delagate della lista e della searchbar
    [self.tableView setDelegate:self];
    [self.tableView setDataSource:self];
    
    
    // Setto lo sfondo della lista
    UIColor *backgroundColor = [UIColor colorWithRed:0.0 green:0.56 blue:0.8 alpha:1.0];
    self.tableView.backgroundView = [[UIView alloc]initWithFrame:self.tableView.bounds];
    self.tableView.backgroundView.backgroundColor = backgroundColor;
    
    // Setto una view alternativa quando ho un errore di connessione
    CGRect titleLabelFrame;
    if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"]){
        titleLabelFrame = CGRectMake(75, 300, 200, 75);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
    }else{
        titleLabelFrame = CGRectMake(234, 550, 300, 100);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:25];
    }
    self.label.textColor = [UIColor blackColor];
    self.label.text = @"Lista vuota";
    [self.label setNumberOfLines:2];
    self.label.textAlignment = NSTextAlignmentCenter;
    [self.label setBackgroundColor:[UIColor whiteColor]];
    [self.label.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.label.layer setBorderWidth:2.0f];
    self.label.layer.cornerRadius = 5.0f;
    [self.view addSubview:self.label];

    
    // Setto l'immagine e la label
    [self.moneyImage setImage:[UIImage imageNamed:[NSString stringWithFormat:@"money_%ld", (long)self.value]]];
    if(self.value == 51)
        self.value = 100;
    self.m = self.value/100.0;
    self.moneyLabel.text = [NSString stringWithFormat:@"%.2f €", self.m];
    [self.moneyLabel.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.moneyLabel.layer setBorderWidth:2.0f];
    self.moneyLabel.layer.cornerRadius = 5.0f;
    
    switch (self.value) {
        case 1:
            self.m1 = 0.00f;
            break;
        case 2:
            self.m1 = 0.01f;
            break;
        case 5:
            self.m1 = 0.02f;
            break;
        case 10:
            self.m1 = 0.05f;
            break;
        case 20:
            self.m1 = 0.10f;
            break;
        case 50:
            self.m1 = 0.20f;
            break;
        case 51:
            self.m1 = 0.50;
            break;
        case 100:
            self.m1 = 0.50f;
            break;
        case 200:
            self.m1 = 1.00f;
            break;
        case 500:
            self.m1 = 2.00f;
            break;
        case 1000:
            self.m1 = 5.00f;
            break;
        case 2000:
            self.m1 = 10.00f;
            break;
        case 5000:
            self.m1 = 20.00f;
            break;
        case 10000:
            self.m1 = 50.00f;
            break;
        case 20000:
            self.m1 = 100.00f;
            break;
        case 50000:
            self.m1 = 200.00f;
            break;
        default:
            break;
    }
    
    self.products = [[NSMutableArray alloc] init];
    [self getProductOutOfServer];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.products count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Recupero la generica riga della tabella
    static NSString *cellIdentifier = @"euroCell";
    euroTableView *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    // Recupero dalla lista il prodotto relativo alla riga selzionata
    Product *product = [self.products objectAtIndex:indexPath.row];
    if (cell == nil) cell = [[euroTableView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    
    // Setto le label e l'immagine della riga corrente
    cell.name.text = product.name;
    NSMutableString *tmpcat = [NSMutableString string];
    for (NSString *cat in product.category){
        [tmpcat appendString:[NSString stringWithFormat:@"%@, ",cat]];
    }
    [tmpcat deleteCharactersInRange:NSMakeRange([tmpcat length]-2, 1)];
    cell.category.text = tmpcat;
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",product.img ];
    [cell.image setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    cell.price.text = [NSString stringWithFormat:@"%.2f €", product.price];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Menage Segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    // Se clicco sulla riga seleziono l'elemento corrente e lo passo al controller successivo (ElementController)
    if ([[segue identifier] isEqualToString:@"euroDetail"]) {
        ElementController *element = segue.destinationViewController;
        Product *p = p = [self.products objectAtIndex: self.tableView.indexPathForSelectedRow.row];
        element.product = p;
        element.cartVisible = NO;
    }
}

#pragma mark - Custom

- (void)getProductOutOfServer
{
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	HUD.delegate = self;
	HUD.labelText = @"Prodotti";
	HUD.detailsLabelText = @"Caricamento in corso ...";
    HUD.square = YES;
    [HUD show:YES];
    
    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"products.get_product"};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [HUD hide:YES];
        [HUD removeFromSuperview];
        
        // Recupero i prodotti dal josn e li inserisco in un array
        NSMutableArray *productsTMP =[[NSMutableArray alloc] init];
        NSDictionary *jsonDict = (NSDictionary *) responseObject;
        NSArray *products = [jsonDict objectForKey:@"products"];
        
        [products enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            
            if ([[obj objectForKey:@"id"] integerValue] != self.tmpid){
                Product *product = [[Product alloc] init];
                product.id = [obj objectForKey:@"id"];
                product.name = [[obj objectForKey:@"nome"] capitalizedString];
                product.category = [[NSMutableArray alloc] init];
                [product.category addObject: [[obj objectForKey:@"categoria"] uppercaseString]];
                product.price = [[obj objectForKey:@"prezzo"] floatValue];
                product.img = [obj objectForKey:@"img"];
                self.tmpid = [[obj objectForKey:@"id"] integerValue];
                [productsTMP addObject:product];
            } else {
                [[[productsTMP lastObject] category] addObject: [[obj objectForKey:@"categoria"] uppercaseString]];
            }
            
        }];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(price <=[c] %f) AND (price >[c] %f)", self.m, self.m1];
        NSSortDescriptor *sortDescriptor;
        sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"price"
                                                     ascending:NO];
        NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
        self.products = [[[productsTMP filteredArrayUsingPredicate:predicate] sortedArrayUsingDescriptors:sortDescriptors] copy];
        
        
        if (self.products.count == 0){
            [self.tableView setHidden:YES];
            [self.label setHidden:NO];
            if (self.value == 1){
                self.label.text = @"Non puoi comprare nulla con 0.01 €";
            }else if (self.value == 2){
                self.label.text = @"Non puoi comprare nulla con 0.02 €";
            }else if (self.value == 5){
                self.label.text = @"Non puoi comprare nulla con 0.05 €";
            }
        } else {
            [self.tableView setHidden:NO];
            [self.label setHidden:YES];
        }
        
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [HUD hide:YES];
        
        // Mostro un alert con il messaggio di errore
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
                                                          message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        
        // Setto una view alternativa se la lista è vuota
        [self.tableView setHidden:YES];
        [self.label setHidden:NO];
    }];
}


@end
