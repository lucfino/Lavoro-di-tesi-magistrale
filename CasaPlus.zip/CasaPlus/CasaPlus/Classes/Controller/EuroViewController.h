//
//  EuroViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 23/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EuroViewController : UIViewController <UIScrollViewDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIPageControl *pageControl;

@end