//
//  RecipeToolsViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RecipeToolsViewController.h"
#import "UIImageView+AFNetworking.h"
#import "RecipeIngredientsViewController.h"
#import "productTableView.h"
#import "AFNetworking.h"
#import "Tools.h"
#import "Product.h"

@interface RecipeToolsViewController (){
    NSUserDefaults *defaults;
    MBProgressHUD *HUD;
}

@property (nonatomic) NSInteger tmpid;
@property (strong, nonatomic) UILabel *label;

@end

@implementation RecipeToolsViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.tableView setDelegate:self];
    [self.tableView setDataSource:self];
    
    self.nome.text = self.recipe.nome;
    [self.nome.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.nome.layer setBorderWidth:2.0f];
    self.nome.layer.cornerRadius = 5.0f;
    
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",self.recipe.img ];
    [self.immagine setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    
    [self getToolsOutOfServer];
    
    // Setto una view alternativa se la lista è vuota
    CGRect titleLabelFrame;
    if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"]) {
        titleLabelFrame = CGRectMake(75, 375, 175, 50);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:13];
    }else{
        titleLabelFrame = CGRectMake(184, 650, 400, 100);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
    }
    self.label.textColor = [UIColor blackColor];
    self.label.text = @"Lista vuota";
    self.label.textAlignment = NSTextAlignmentCenter;
    [self.label setBackgroundColor:[UIColor whiteColor]];
    [self.label.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.label.layer setBorderWidth:2.0f];
    self.label.layer.cornerRadius = 5.0f;
    [self.label setHidden:YES];
    [self.view addSubview:self.label];
	
}

#pragma mark - Table View Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.recipe.strumenti count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Recupero la generica riga della tabella
    static NSString *cellIdentifier = @"toolsCell";
    productTableView *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    // Recupero dalla lista il prodotto relativo alla riga selzionata
    Tools *t = [self.recipe.strumenti objectAtIndex:indexPath.row];
    
    // Setto le label e l'immagine della riga corrente
    cell.productName.text = t.name;
    cell.productCategory.text = t.note;
    cell.productPrice.text = @"";
    
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",t.img ];
    [cell.productImage setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Custom

- (void)getToolsOutOfServer
{
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	HUD.delegate = self;
	HUD.labelText = @"Utensili";
	HUD.detailsLabelText = @"Caricamento in corso ...";
    HUD.square = YES;
    [HUD show:YES];
    
    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"recipe.get_tools", @"id":[NSString stringWithFormat:@"%ld", (long)self.recipe.id]};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [HUD hide:YES];
        [HUD removeFromSuperview];
        
        // Recupero i prodotti dal josn e li inserisco in un array
        NSMutableDictionary *jsonDict = (NSMutableDictionary *) responseObject;
        NSArray *tools = [jsonDict objectForKey:@"tools"];
        
        [tools enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            if ([[obj objectForKey:@"id"] integerValue] != self.tmpid){
                self.tmpid = [[obj objectForKey:@"id"] integerValue];
                Tools *p = [[Tools alloc] init];
                p.id = [obj objectForKey:@"id"];
                p.name = [obj objectForKey:@"nome"];
                p.img = [obj objectForKey:@"img_path"];
                p.category = [[NSMutableArray alloc] init];
                [p.category addObject: [[obj objectForKey:@"nomeCat"] uppercaseString]];
                p.note = [obj objectForKey:@"note1"];
                NSPredicate *predicate = [NSPredicate predicateWithFormat:@"id ==[c] %@", p.id];
                if ([[self.recipe.strumenti filteredArrayUsingPredicate:predicate] count] == 0)
                    [self.recipe.strumenti addObject:p];
            } else {
                [[[self.recipe.strumenti lastObject] category]addObject: [[obj objectForKey:@"nomeCat"] uppercaseString]];
            }
            
        }];
        
        if ([self.recipe.strumenti count] != 0) {
            [self.tableView setHidden:NO];
            [self.label setHidden:YES];
        } else {
            [self.label setHidden:NO];
            [self.tableView setHidden:YES];
        }
        
        [self.tableView reloadData];
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [HUD hide:YES];
        [HUD removeFromSuperview];
        
        self.label.text = @"Impossibile recuperare gli utensili";
        [self.label setHidden:NO];
        [self.tableView setHidden:YES];
        
        // Mostro un alert con il messaggio di errore
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
                                                          message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
    }];
}



#pragma mark - Menage Segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([[segue identifier] isEqualToString:@"recipeIngredients"]) {
        RecipeIngredientsViewController *element = segue.destinationViewController;
        element.recipe = self.recipe;
    }
}

@end
