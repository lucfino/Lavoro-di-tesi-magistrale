//
//  PrintElementController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 17/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "CartItem.h"

@protocol sendCartItemDataProtocol <NSObject>

- (void)aggiornaCheck:(CartItem *)ci;

@end

@interface PrintElementController : UIViewController

@property (strong, nonatomic) CartItem *cartItem;

@property (strong, nonatomic) IBOutlet UILabel *name;
@property (strong, nonatomic) IBOutlet UILabel *category;
@property (strong, nonatomic) IBOutlet UIButton *speak;
@property (strong, nonatomic) IBOutlet UIImageView *image;
@property (strong, nonatomic) IBOutlet UIButton *checkbox;
@property (strong, nonatomic) IBOutlet UILabel *quantity;

@property(nonatomic,assign)id delegate;

@end
