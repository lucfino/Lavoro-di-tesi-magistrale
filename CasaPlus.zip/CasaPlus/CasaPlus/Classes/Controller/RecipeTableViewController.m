//
//  RecipeTableViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RecipeTableViewController.h"
#import "AFNetworking.h"
#import "UIImageView+AFNetworking.h"
#import "RecipeDetailViewController.h"
#import "Recipe.h"
#import "CategoryRecipe.h"
#import "RecipeTableView.h"
#import "AppDelegate.h"

@interface RecipeTableViewController (){
    NSUserDefaults *defaults;
    MBProgressHUD *HUD;
}

@property (strong, nonatomic) NSMutableArray *recipes;
@property (nonatomic, strong) NSMutableArray* sectionInfoArray;
@property (strong, nonatomic) Recipe *currentRecipe;
@property (nonatomic,assign) NSInteger openSectionIndex;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *refresh;

@end

@implementation RecipeTableViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
    }
    
    //  Istanzio la lista dei prodotti e li recupero insieme alle categorie dal json sul server
    self.recipes = [[NSMutableArray alloc] init];
    self.sectionInfoArray = [[NSMutableArray alloc] init];
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self getRecipesOutOfServer];
    
    // Setto l'indice della sezione aperta
    self.openSectionIndex = NSNotFound;
    
    // Setto lo sfondo della lista
    UIColor *backgroundColor = [UIColor colorWithRed:0.0 green:0.56 blue:0.8 alpha:1.0];
    self.tableView.backgroundView = [[UIView alloc]initWithFrame:self.tableView.bounds];
    self.tableView.backgroundView.backgroundColor = backgroundColor;
    
    // Setto i delagate della lista e della searchbar
    [self.tableView setDelegate:self];
    [self.tableView setDataSource:self];
    
    // Richiamo l'app delegate
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.recipeTableController = self;
}

#pragma mark - Table View Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.sectionInfoArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:section];
    CategoryRecipe *cat = [sectionInfo objectForKey:@"categoria"];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"categoria.nome==[cd] %@", [cat.nome capitalizedString]];
    NSArray *recipes = [self.recipes filteredArrayUsingPredicate:predicate];
    
    int rows = 0;
    if ([[sectionInfo objectForKey:@"opened"] boolValue])
        rows = (int)recipes.count;
   
    return rows;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Recupero la generica riga della tabella
    static NSString *cellIdentifier = @"recipeCell";
    RecipeTableView *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    // Recupero dalla lista il prodotto relativo alla riga selzionata
    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:indexPath.section];
    CategoryRecipe *cat = [sectionInfo objectForKey:@"categoria"];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"categoria.nome==[cd] %@", [cat.nome capitalizedString]];
    NSArray *recipes = [self.recipes filteredArrayUsingPredicate:predicate];
    Recipe *recipe = [recipes objectAtIndex:indexPath.row];
    
    if (cell == nil) cell = [[RecipeTableView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    
    // Setto le label
    cell.label.text = recipe.nome;
    cell.categoria.text = recipe.categoria.nome;
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",recipe.img ];
    [cell.immagine setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
    
    return cell;
}

- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )
        return 80.0;
    else
        return 140.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:indexPath.section];
    CategoryRecipe *cat = [sectionInfo objectForKey:@"categoria"];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"categoria.nome==[cd] %@", [cat.nome capitalizedString]];
    NSArray *recipes = [self.recipes filteredArrayUsingPredicate:predicate];
    self.currentRecipe = [recipes objectAtIndex:indexPath.row];
    
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.tableView reloadData];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:section];
    
    // Setto le label e l'immagine dell'header considerato
    if (![sectionInfo objectForKey:@"headerView"]) {
        RecipeTableViewHeader *header = [[RecipeTableViewHeader alloc] initWithFrame:CGRectMake(0.0, 0.0, self.tableView.bounds.size.width, 45) section:section delegate:self];
        [header setDelegate:self];
        header.categoryLabel.text = [[[self.sectionInfoArray objectAtIndex:section] objectForKey:@"categoria"] nome];
        
        NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/", [[sectionInfo objectForKey:@"categoria"] img] ];
        [header.categoryImg setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_category" ]];
        
        [sectionInfo setObject:header forKey:@"headerView"];
    }
    return [sectionInfo objectForKey:@"headerView"];
}

-(void)sectionHeaderView:(RecipeTableViewHeader*)sectionHeaderView sectionOpened:(NSInteger)sectionOpened {
    
    NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:sectionOpened];
	[sectionInfo setObject:[NSNumber numberWithBool:YES] forKey:@"opened"];
    CategoryRecipe *cat = [sectionInfo objectForKey:@"categoria"];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"categoria.nome==[cd] %@", [cat.nome capitalizedString]];
    NSArray *recipes = [self.recipes filteredArrayUsingPredicate:predicate];
    
    // Creo un array che contiene gli indexPath delle righe da inserire
    int countOfRowsToInsert = 0;
    if ([[sectionInfo objectForKey:@"opened"] boolValue])
        countOfRowsToInsert = (int)recipes.count;
    NSMutableArray *indexPathsToInsert = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < countOfRowsToInsert; i++) {
        [indexPathsToInsert addObject:[NSIndexPath indexPathForRow:i inSection:sectionOpened]];
    }
    
    // Creo un array che contiene gli indexPath delle righe da eliminare
    NSMutableArray *indexPathsToDelete = [[NSMutableArray alloc] init];
    NSInteger previousOpenSectionIndex = self.openSectionIndex;
    if (previousOpenSectionIndex != NSNotFound) {
        
		NSMutableDictionary *previousOpenSection = [self.sectionInfoArray objectAtIndex:previousOpenSectionIndex];
        [previousOpenSection setObject:[NSNumber numberWithBool:NO] forKey:@"opened"];
        [[previousOpenSection objectForKey:@"headerView"] toggleOpenWithUserAction:NO];
        
        CategoryRecipe *cat = [previousOpenSection objectForKey:@"categoria"];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"categoria.nome==[cd] %@", [cat.nome capitalizedString]];
        NSArray *recipes = [self.recipes filteredArrayUsingPredicate:predicate];
        
        int countOfRowsToDelete = 0;
        if ([[sectionInfo objectForKey:@"opened"] boolValue])
            countOfRowsToDelete = (int)recipes.count;
        
        for (NSInteger i = 0; i < countOfRowsToDelete; i++) {
            [indexPathsToDelete addObject:[NSIndexPath indexPathForRow:i inSection:previousOpenSectionIndex]];
        }
    }
    
    // Setto le animazioni
    UITableViewRowAnimation insertAnimation;
    UITableViewRowAnimation deleteAnimation;
    if (previousOpenSectionIndex == NSNotFound || sectionOpened < previousOpenSectionIndex) {
        insertAnimation = UITableViewRowAnimationTop;
        deleteAnimation = UITableViewRowAnimationBottom;
    }
    else {
        insertAnimation = UITableViewRowAnimationBottom;
        deleteAnimation = UITableViewRowAnimationTop;
    }
    
    // Applico le animazioni
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:indexPathsToInsert withRowAnimation:insertAnimation];
    [self.tableView deleteRowsAtIndexPaths:indexPathsToDelete withRowAnimation:deleteAnimation];
    [self.tableView endUpdates];
    self.openSectionIndex = sectionOpened;
}

-(void)sectionHeaderView:(RecipeTableViewHeader*)sectionHeaderView sectionClosed:(NSInteger)sectionClosed {
    
    //Creo un array che contiene gli indexPath delle righe nella sezione da eliminare
	NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:sectionClosed];
    [sectionInfo setObject:[NSNumber numberWithBool:NO] forKey:@"opened"];
    NSInteger countOfRowsToDeleteC = [self.tableView numberOfRowsInSection:sectionClosed];
    
    if (countOfRowsToDeleteC > 0) {
        NSMutableArray *indexPathsToDelete = [[NSMutableArray alloc] init];
        for (NSInteger i = 0; i < countOfRowsToDeleteC; i++) {
            [indexPathsToDelete addObject:[NSIndexPath indexPathForRow:i inSection:sectionClosed]];
        }
        [self.tableView deleteRowsAtIndexPaths:indexPathsToDelete withRowAnimation:UITableViewRowAnimationTop];
    }
    self.openSectionIndex = NSNotFound;
}

#pragma mark - Manage refresh

- (IBAction)refresh:(id)sender
{
    self.openSectionIndex = NSNotFound;
    [self getRecipesOutOfServer];
}

#pragma mark - Menage Segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([[segue identifier] isEqualToString:@"recipeDetail"]) {
        RecipeDetailViewController *element = segue.destinationViewController;
        NSMutableDictionary *sectionInfo = [self.sectionInfoArray objectAtIndex:self.tableView.indexPathForSelectedRow.section];
        CategoryRecipe *cat = [sectionInfo objectForKey:@"categoria"];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"categoria.nome==[cd] %@", [cat.nome capitalizedString]];
        NSArray *recipes = [self.recipes filteredArrayUsingPredicate:predicate];
        Recipe *recipe = [recipes objectAtIndex: self.tableView.indexPathForSelectedRow.row];
        element.recipe = recipe;
    }
}

#pragma mark - Custom

- (void)getRecipesOutOfServer
{
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	HUD.delegate = self;
	HUD.labelText = @"Ricette";
	HUD.detailsLabelText = @"Caricamento in corso ...";
    HUD.square = YES;
    [HUD show:YES];
    
    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"recipe.get_recipe"};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [HUD hide:YES];
        [HUD removeFromSuperview];
        
        // Recupero i prodotti dal josn e li inserisco in un array
        NSMutableArray *recipeTMP =[[NSMutableArray alloc] init];
        NSMutableDictionary *jsonDict = (NSMutableDictionary *) responseObject;
        NSArray *recipes = [jsonDict objectForKey:@"recipe"];
        
        [recipes enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            
            Recipe *recipe = [[Recipe alloc] init];
            recipe.id = [[obj objectForKey:@"recipe_id"] integerValue];
            recipe.nome = [[obj objectForKey:@"Nome"] capitalizedString];
            recipe.img = [obj objectForKey:@"recipe_img"];
            recipe.calorie = [obj objectForKey:@"calorie"];
            recipe.difficolta = [obj objectForKey:@"difficolta"];
            recipe.persone = [obj objectForKey:@"persone"];
            recipe.descrizione = [obj objectForKey:@"descrizione"];
            recipe.enabled = [[obj objectForKey:@"enabled"] boolValue];
            CategoryRecipe *catRecipe = [[CategoryRecipe alloc] init];
            catRecipe.nome = [[obj objectForKey:@"nome"] uppercaseString];
            catRecipe.ordine = [[obj objectForKey:@"ordine"] integerValue];
            catRecipe.img = [obj objectForKey:@"img"];
            recipe.categoria = catRecipe;
            recipe.ingredienti = [[NSMutableArray alloc] init];
            recipe.strumenti = [[NSMutableArray alloc] init];
            recipe.steps = [[NSMutableArray alloc] init];
            [recipeTMP addObject:recipe];
            
            NSPredicate *predicate = [NSPredicate predicateWithFormat:@"categoria.nome==[cd] %@", [[obj objectForKey:@"nome"] uppercaseString]];
            if ([[self.sectionInfoArray filteredArrayUsingPredicate:predicate] count] == 0) {
                NSMutableDictionary *infoSection = [[NSMutableDictionary alloc] init];
                [infoSection setObject:catRecipe forKey:@"categoria"];
                [infoSection setObject:[NSNumber numberWithBool:NO] forKey:@"opened"];
                [self.sectionInfoArray addObject:infoSection];
            }
            
        }];
        self.recipes = [recipeTMP copy];
        
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"categoria.ordine" ascending:YES];
        NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
        self.sectionInfoArray = [[self.sectionInfoArray sortedArrayUsingDescriptors:sortDescriptors] copy];
        
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        // Mostro un alert con il messaggio di errore
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
                                                          message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
    }];
}


@end
