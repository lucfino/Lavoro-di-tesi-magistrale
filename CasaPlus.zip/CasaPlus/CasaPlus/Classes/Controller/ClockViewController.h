//
//  ClockViewController.h
//  clock
//
//  Created by Luca Finocchio on 04/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClockView.h"

@interface ClockViewController : UIViewController {
    
    NSTimer *timer;
    
}

@property (strong, nonatomic) IBOutlet ClockView *clockView;
@property (strong, nonatomic) IBOutlet UILabel *clockDigital;
@property (strong, nonatomic) IBOutlet UIButton *speak;

@end