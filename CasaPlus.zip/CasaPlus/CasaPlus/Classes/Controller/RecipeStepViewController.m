//
//  RecipeStepViewController.m
//  CasaPlus
//
//  Created by Daniele Leombruni on 26/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RecipeStepViewController.h"
#import "AFNetworking.h"
#import "UIImageView+AFNetworking.h"
#import "RecipeTableViewController.h"
#import "Step.h"
#import <AudioToolbox/AudioToolbox.h>

@interface RecipeStepViewController (){
    NSUserDefaults *defaults;
    MBProgressHUD *HUD;
}

@property (nonatomic) NSInteger currentStepNumber;
@property (nonatomic) StepView *currentStep;
@property (strong, nonatomic) UILabel *label;

@end

@implementation RecipeStepViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
    }
    
    self.currentStepNumber = 0;
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self getStepsOutOfServer];
    
    self.nome.text = self.recipe.nome;
    [self.nome.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.nome.layer setBorderWidth:2.0f];
    self.nome.layer.cornerRadius = 5.0f;
    
    // Setto una view alternativa se la lista è vuota
    CGRect titleLabelFrame;
    if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"]) {
        titleLabelFrame = CGRectMake(75, 250, 175, 50);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:13];
    }else{
        titleLabelFrame = CGRectMake(184, 500, 400, 100);
        self.label = [[UILabel alloc] initWithFrame:titleLabelFrame];
        self.label.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
    }
    self.label.textColor = [UIColor blackColor];
    self.label.text = @"Nessun passo da saguire";
    self.label.textAlignment = NSTextAlignmentCenter;
    [self.label setBackgroundColor:[UIColor whiteColor]];
    [self.label.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.label.layer setBorderWidth:2.0f];
    self.label.layer.cornerRadius = 5.0f;
    [self.label setHidden:YES];
    [self.view addSubview:self.label];
}

#pragma mark - Custom

- (void)getStepsOutOfServer
{
    
    HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
	[self.navigationController.view addSubview:HUD];
	HUD.delegate = self;
	HUD.labelText = @"Utensili";
	HUD.detailsLabelText = @"Caricamento in corso ...";
    HUD.square = YES;
    [HUD show:YES];
    
    // Imposto i parametri della richiesta GET
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    NSDictionary *params = @{@"option": @"com_casaplus", @"task": @"recipe.get_steps", @"id":[NSString stringWithFormat:@"%ld", (long)self.recipe.id]};
    
    // Eseguo la richiesta
    [manager GET:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [HUD hide:YES];
        [HUD removeFromSuperview];
        
        // Recupero i prodotti dal josn e li inserisco in un array
        NSMutableDictionary *jsonDict = (NSMutableDictionary *) responseObject;
        NSArray *tools = [jsonDict objectForKey:@"steps"];
        
        [tools enumerateObjectsUsingBlock:^(id obj,NSUInteger idx, BOOL *stop){
            Step *p = [[Step alloc] init];
            p.id = [[obj objectForKey:@"id"] integerValue];
            p.descrizione = [obj objectForKey:@"descrizione"];
            p.img = [obj objectForKey:@"img"];
            p.timer = [obj objectForKey:@"timer"];
            p.tempo = [obj objectForKey:@"tempo"];
            p.posizione = [obj objectForKey:@"posizione"];
            [self.recipe.steps addObject:p];
        }];

        NSNumberFormatter *numFormatter = [[NSNumberFormatter alloc] init];
        [numFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
        self.recipe.steps = [[self.recipe.steps sortedArrayUsingComparator:^(id a, id b) {
            return [[numFormatter numberFromString:[a posizione]] compare:[numFormatter numberFromString:[b posizione]]];
        }] copy];
        
        if ([self.recipe.steps count] != 0) {
            Step *s = [self.recipe.steps objectAtIndex:self.currentStepNumber];
            if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
                self.currentStep = [[StepView alloc] initWithFrame:CGRectMake(0, 0, 320, 420) image:s.img step:s.posizione descrizione:s.descrizione timer:[s.timer boolValue] countdown:s.tempo];
            else
                self.currentStep = [[StepView alloc] initWithFrame:CGRectMake(0, 0, 770, 790) image:s.img step:s.posizione descrizione:s.descrizione timer:[s.timer boolValue] countdown:s.tempo];
            [self.currentStep.avanti addTarget:self action:@selector(nextStep:) forControlEvents:UIControlEventTouchUpInside];
            [self.currentStep.start addTarget:self action:@selector(startTimer:) forControlEvents:UIControlEventTouchUpInside];
            [self.currentStep.stop addTarget:self action:@selector(pauseTimer:) forControlEvents:UIControlEventTouchUpInside];
            [self.stepView addSubview:self.currentStep];
        } else {
            [self.label setHidden:NO];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [HUD hide:NO];
        
        self.label.text = @"Impossibile recuperare i passi";
        [self.label setHidden:NO];
        
        // Mostro un alert con il messaggio di errore
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"%@: %ld",@"Errore nella connessione al server",(long)operation.error.code]
                                                          message: @"Controlla che la tua connessione internet sia attiva o che l'indirizzo del server sia corretto"
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
    }];
}

-(void)nextStep:(id)sender
{
    if (self.currentStepNumber != [self.recipe.steps count]-1) {
        self.currentStepNumber ++;
        [[[self.stepView subviews] objectAtIndex:0] removeFromSuperview];
        Step *s = [self.recipe.steps objectAtIndex:self.currentStepNumber];
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.currentStep = [[StepView alloc] initWithFrame:CGRectMake(0, 0, 320, 420) image:s.img step:s.posizione descrizione:s.descrizione timer:[s.timer boolValue] countdown:s.tempo];
        else
            self.currentStep = [[StepView alloc] initWithFrame:CGRectMake(0, 0, 770, 790) image:s.img step:s.posizione descrizione:s.descrizione timer:[s.timer boolValue] countdown:s.tempo];
        [self.currentStep.avanti addTarget:self action:@selector(nextStep:) forControlEvents:UIControlEventTouchUpInside];
        [self.currentStep.start addTarget:self action:@selector(startTimer:) forControlEvents:UIControlEventTouchUpInside];
        [self.currentStep.stop addTarget:self action:@selector(pauseTimer:) forControlEvents:UIControlEventTouchUpInside];
        [self.stepView addSubview:self.currentStep];
    } else {
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
        AudioServicesPlaySystemSound (1007);
        NSString* alert_msg = @"La ricetta è terminata";
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:nil  cancelButtonTitle:@"OK"   otherButtonTitles:nil];
        [alert show];
        if ([[[self.navigationController viewControllers] objectAtIndex:1] isKindOfClass:[RecipeTableViewController class]]) {
            [self.navigationController popToViewController:[[self.navigationController viewControllers] objectAtIndex:1] animated:YES];
        }
    }
}


-(void)startTimer:(id)sender
{
    if (!self.currentStep.isTimer) {
        timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
        self.currentStep.stop.hidden = NO;
        self.currentStep.start.hidden = YES;
    } else {
        timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
        self.currentStep.start.hidden = YES;
    }
    
}

-(void)pauseTimer:(id)sender
{
    [timer invalidate];
    self.currentStep.stop.hidden = YES;
    self.currentStep.start.hidden = NO;
}

-(void)updateTimer
{
    if (!self.currentStep.isTimer) {
        self.currentStep.secondi ++;
        if (self.currentStep.secondi > 60) {
            self.currentStep.secondi = 0;
            self.currentStep.minuti++;
        }
        if (self.currentStep.minuti > 60) {
            self.currentStep.minuti = 0;
            self.currentStep.ore++;
        }
    }else{
        self.currentStep.secondi --;
        if (self.currentStep.secondi < 0) {
            self.currentStep.secondi = 59;
            self.currentStep.minuti--;
        }
        if (self.currentStep.minuti < 0) {
            self.currentStep.minuti = 59;
            self.currentStep.ore--;
        }
        if (self.currentStep.ore == 0 && self.currentStep.minuti == 0 && self.currentStep.secondi == 0) {
            [timer invalidate];
            AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
            AudioServicesPlaySystemSound (1007);
            NSString* alert_msg = @"Tempo scaduto";
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:nil  cancelButtonTitle:@"OK"   otherButtonTitles:nil];
            [alert show];
            [self nextStep:nil];
        }
    }
    self.currentStep.timerLabel.text = [NSString stringWithFormat:@"%02ld:%02ld:%02ld",(long)self.currentStep.ore,(long)self.currentStep.minuti,(long)self.currentStep.secondi];
}

@end
