//
//  LoginController.h
//  OmniaCode
//
//  Created by Francesco Tarquini
//  Copyright (c) 2013 BiTE s.r.l. All rights reserved.
//

#import "MBProgressHUD.h"

@interface LoginViewController : UIViewController  <MBProgressHUDDelegate, UITextFieldDelegate>

@end