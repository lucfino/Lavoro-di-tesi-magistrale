//
//  RecipeIngredientsViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Recipe.h"
#import "MBProgressHUD.h"

@interface RecipeIngredientsViewController : UIViewController<MBProgressHUDDelegate, UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) IBOutlet UILabel *nome;
@property (strong, nonatomic) IBOutlet UIImageView *immagine;
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *aggiungi;

@property (strong, nonatomic) Recipe *recipe;

@end
