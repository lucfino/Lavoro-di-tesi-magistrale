//
//  ViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 04/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "productTableViewHeader.h"
#import "MBProgressHUD.h"

@interface ViewController : UIViewController <SectionHeaderViewDelegate, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, MBProgressHUDDelegate>

@property (strong, nonatomic) NSMutableArray *products;
@property (strong, nonatomic) IBOutlet UITableView *tableView;

- (void)getProductOutOfServer;

- (void)getCategoryOutOfServer;

@end
