//
//  RegisterViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 22/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIWebView *web;

@end
