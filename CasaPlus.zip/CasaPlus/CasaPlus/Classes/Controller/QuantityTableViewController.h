//
//  QuantityTableViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 15/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "Cart.h"
#import "MBProgressHUD.h"

@interface QuantityTableViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, MBProgressHUDDelegate>

@property (strong, nonatomic) Cart *cart;

@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *remoteCart;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *print;

- (void)updateCart:(id)sender;

@end
