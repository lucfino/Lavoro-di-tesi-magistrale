//
//  ElementController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 08/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Product.h"

@protocol sendDataProtocol <NSObject>

- (void)addSelectedProduct:(Product *)product;

@end

@interface ElementController : UIViewController

@property (strong, nonatomic) Product *product;
@property (nonatomic) BOOL selected;
@property (nonatomic) BOOL cartVisible;

@property (strong, nonatomic) IBOutlet UILabel *productName;
@property (strong, nonatomic) IBOutlet UILabel *productCategory;
@property (strong, nonatomic) IBOutlet UIImageView *productImage;
@property (strong, nonatomic) IBOutlet UIButton *productAudio;
@property (strong, nonatomic) IBOutlet UIButton *productAdd;

@property(nonatomic,assign)id delegate;

@end
