//
//  HomeViewController.m
//  CasaPlus
//
//  Created by Daniele Leombruni on 07/03/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "HomeViewController.h"
#import "AppDelegate.h"
#import "AFNetworking.h"

@implementation HomeViewController
{
    NSUserDefaults *defaults;
    AppDelegate *appDelegate;
    MBProgressHUD *HUD;
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
        
    }
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    return self;
}

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([defaults objectForKey:@"username"]) {
        self.logout.title = [defaults objectForKey:@"username"];
    }

}

-(IBAction)logout:(id)sender
{
    NSString* alert_msg = @"Vuoi eseguire il logout ?";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"CasaPiù" message:alert_msg  delegate:self  cancelButtonTitle:@"NO"   otherButtonTitles:@"SI", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0)
    {
        //NSLog(@"Bottone cancella");
    }
    if (buttonIndex == 1)
    {
        HUD = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
        [self.navigationController.view addSubview:HUD];
        HUD.delegate = self;
        HUD.labelText = @"Login";
        HUD.detailsLabelText = @"Verifica Utente";
        HUD.square = YES;
        [HUD show:YES];
        
        [defaults setObject:@"not_logged" forKey:@"logged"];
        [defaults setObject:@"not_logged" forKey:@"username"];
        
        // Imposto i parametri della richiesta POST
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
        NSDictionary *params = @{@"option": @"com_apns", @"task": @"devlists.setUser", @"user":[defaults objectForKey:@"username"], @"devToken":[defaults objectForKey:@"token"]};
        
        // Eseguo la richiesta
        [manager POST:[NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"],@"index.php"] parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
            //NSLog(@"ok");
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            //NSLog(@"no");
        }];
        
        [HUD hide:YES];
        [HUD removeFromSuperview];
        
        [appDelegate selectInitialVC];
    }
}


@end
