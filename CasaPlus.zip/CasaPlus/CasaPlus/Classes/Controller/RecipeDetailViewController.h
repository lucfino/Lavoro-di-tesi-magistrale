//
//  RecipeDetailViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Recipe.h"

@interface RecipeDetailViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *label;
@property (strong, nonatomic) IBOutlet UIImageView *difficolta;
@property (strong, nonatomic) IBOutlet UIImageView *calorie;
@property (strong, nonatomic) IBOutlet UILabel *persone;
@property (strong, nonatomic) IBOutlet UIImageView *immagine;
@property (strong, nonatomic) IBOutlet UILabel *descrizione;

@property (strong, nonatomic) Recipe *recipe;

@end
