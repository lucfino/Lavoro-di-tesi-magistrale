//
//  RegisterViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 22/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()
{
    NSUserDefaults *defaults;
}

@end

@implementation RegisterViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Check first launch
    defaults = [NSUserDefaults standardUserDefaults];
    if (![defaults objectForKey:@"firstRun"])
    {
        [defaults setObject:[NSDate date] forKey:@"firstRun"];
        [defaults setBool:NO forKey:@"pref_visual_grouped"];
        [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
        [defaults setBool:YES forKey:@"pref_show_category"];
        [defaults setBool:YES forKey:@"pref_direct_selection"];
        [defaults setValue:@"0" forKey:@"clock_background"];
    }
    
    NSString *urlAddress = @"index.php/component/users/?view=registration";
    NSString *new = [NSString stringWithFormat:@"%@%@", [defaults objectForKey:@"url"], urlAddress];
    
    NSURL *url = [NSURL URLWithString:new];
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    [self.web loadRequest:requestObj];
}

@end
