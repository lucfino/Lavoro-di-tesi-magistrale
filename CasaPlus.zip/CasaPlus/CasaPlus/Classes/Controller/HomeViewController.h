//
//  HomeViewController.h
//  CasaPlus
//
//  Created by Daniele Leombruni on 07/03/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface HomeViewController : UIViewController<MBProgressHUDDelegate>

@property (weak, nonatomic) IBOutlet UIBarButtonItem *logout;

@end
