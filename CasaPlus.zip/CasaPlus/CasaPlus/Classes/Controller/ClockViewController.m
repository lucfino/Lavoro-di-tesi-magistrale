//
//  ClockViewController.m
//  clock
//
//  Created by Enriquez Guillermo on 7/2/11.
//  Copyright 2011 Nacho4d. All rights reserved.
//  See the file License.txt for copying permission.
//

#import "ClockViewController.h"
#import "AppDelegate.h"
#import <AVFoundation/AVFoundation.h>


@implementation ClockViewController{
    NSUserDefaults *defaults;
}

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

	// Setto lo sfondo dell'orologio e delle lancette
    NSString *background = [NSString stringWithFormat:@"clockdial_%@.png",[defaults objectForKey:@"clock_background"]];
    [self.clockView setClockBackgroundImage:[UIImage imageNamed:background]];
	[self.clockView setHourHandImage:[UIImage imageNamed:@"clockhour.png"].CGImage];
	[self.clockView setMinHandImage:[UIImage imageNamed:@"clockminute.png"].CGImage];
	[self.clockView setSecHandImage:[UIImage imageNamed:@"clock-sec-background.png"].CGImage];
    [self.clockDigital.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.clockDigital.layer setBorderWidth:2.0f];
    self.clockDigital.layer.cornerRadius = 5.0f;
    
    // Setto le azioni relative ai bottoni
    [self.speak addTarget:self action:@selector(playAudio:) forControlEvents:UIControlEventTouchUpInside];
    
    // Richiamo l'app delegate
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    appDelegate.clockController = self;

}

- (void)viewWillAppear:(BOOL)animated
{
	// Faccio partire l'orologio all'ora corrente
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateDigitalClock:) userInfo:nil repeats:YES];
	[self.clockView start];
}

- (void)viewWillDisappear:(BOOL)animated
{
	// Fermo l'orologio
    [timer invalidate];
	[self.clockView stop];
}


- (void)playAudio:(id)sender
{
    // Imposto i parametri del sintetizzatore vocale
    AVSpeechSynthesizer *synth = [[AVSpeechSynthesizer alloc] init];
    NSDateComponents *dateComponents = [[NSCalendar currentCalendar] components:(NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit) fromDate:[NSDate date]];
	NSInteger minutes = [dateComponents minute];
	NSInteger hours = [dateComponents hour];
    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:[NSString stringWithFormat:@"Sono le ore %ld e %ld", (long)hours, (long)minutes]];
    [utterance setRate:0.16];
    [utterance setVoice:[AVSpeechSynthesisVoice voiceWithLanguage:@"it-IT"]];
    [synth speakUtterance:utterance];
}

- (void) updateDigitalClock:(NSTimer *)theTimer
{
	NSDateComponents *dateComponents = [[NSCalendar currentCalendar] components:(NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit) fromDate:[NSDate date]];
	NSInteger seconds = [dateComponents second];
	NSInteger minutes = [dateComponents minute];
	NSInteger hours = [dateComponents hour];

    // Setto la label
    self.clockDigital.text = [NSString stringWithFormat:@"%02ld:%02ld:%02ld",(long)hours,(long)minutes,(long)seconds];
}


@end
