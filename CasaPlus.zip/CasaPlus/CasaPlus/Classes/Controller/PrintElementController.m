//
//  PrintElementController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 17/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "PrintElementController.h"
#import "UIImageView+AFNetworking.h"
#import <AVFoundation/AVFoundation.h>

@interface PrintElementController ()
{
    NSUserDefaults *defaults;
}

@end

@implementation PrintElementController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Setto le label e l'immagine del prodotto
	self.name.text = [[self.cartItem.product name] uppercaseString];
    [self.name.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.name.layer setBorderWidth:2.0f];
    self.name.layer.cornerRadius = 5.0f;
    NSMutableString *tmpcat = [NSMutableString string];
    for (NSString *cat in self.cartItem.product.category){
        [tmpcat appendString:[NSString stringWithFormat:@"%@, ",cat]];
    }
    [tmpcat deleteCharactersInRange:NSMakeRange([tmpcat length]-2, 1)];
    self.category.text = [tmpcat lowercaseString];
    [self.category.layer setBorderColor:[UIColor blackColor].CGColor];
    [self.category.layer setBorderWidth:2.0f];
    self.category.layer.cornerRadius = 5.0f;
    NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/", self.cartItem.product.img ];
    [self.image setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product"]];
    self.quantity.layer.borderColor = [[UIColor blackColor] CGColor];
    self.quantity.layer.borderWidth = 4.0f;
    self.quantity.layer.cornerRadius = 7.0f;
    if (self.cartItem.quantityCart)
        self.quantity.text = self.cartItem.quantityCart;
    else
        self.quantity.text = @"0";

    // Cambio lo stato della checkbox (modificando l'immagine)
    if (self.cartItem.selected){
        [self.checkbox setBackgroundImage:[UIImage imageNamed:@"button_checked" ] forState:UIControlStateNormal];
    }else{
        [self.checkbox setBackgroundImage:[UIImage imageNamed:@"button_unchecked" ] forState:UIControlStateNormal];
    }
    
    // Setto le azioni relative ai bottoni
    [self.checkbox addTarget:self action:@selector(checked:) forControlEvents:UIControlEventTouchUpInside];
    [self.speak addTarget:self action:@selector(playAudio:) forControlEvents:UIControlEventTouchUpInside];

}

- (void)viewWillDisappear:(BOOL)animated
{
    [self.delegate aggiornaCheck:self.cartItem];
    [super viewWillDisappear:animated];
}

#pragma mark - Custom

- (void)playAudio:(id)sender{
    AVSpeechSynthesizer *synth = [[AVSpeechSynthesizer alloc] init];
    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.cartItem.product.name];
    [utterance setRate:0.16];
    [utterance setVoice:[AVSpeechSynthesisVoice voiceWithLanguage:@"it-IT"]];
    [synth speakUtterance:utterance];
}

- (void) checked:(id)sender
{
    UIButton* btn = (UIButton *) sender;
    if (!self.cartItem.selected) {
        [btn setBackgroundImage:[UIImage imageNamed:@"button_checked" ] forState:UIControlStateNormal];
        self.cartItem.selected = YES;
    }else{
        [btn setBackgroundImage:[UIImage imageNamed:@"button_unchecked" ] forState:UIControlStateNormal];
        self.cartItem.selected = NO;
    }
}


@end
