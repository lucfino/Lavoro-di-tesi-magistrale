//
//  EuroViewController.m
//  CasaPlus
//
//  Created by Luca Finocchio on 23/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "EuroViewController.h"
#import "EuroView.h"
#import "EuroTableViewController.h"

@interface EuroViewController ()
{
    NSUserDefaults *defaults;
}

@property (nonatomic) float euro_value;

@end


@implementation EuroViewController

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        
        //Check first launch
        defaults = [NSUserDefaults standardUserDefaults];
        if (![defaults objectForKey:@"firstRun"])
        {
            [defaults setObject:[NSDate date] forKey:@"firstRun"];
            [defaults setBool:NO forKey:@"pref_visual_grouped"];
            [defaults setObject:@"http://localhost:8888/joomla/" forKey:@"url"];
            [defaults setBool:YES forKey:@"pref_show_category"];
            [defaults setBool:YES forKey:@"pref_direct_selection"];
            [defaults setValue:@"0" forKey:@"clock_background"];
        }
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    NSUInteger numberPages = 7;
    
    self.scrollView.pagingEnabled = YES;
    self.scrollView.contentSize = CGSizeMake(CGRectGetWidth(self.scrollView.frame) * numberPages, CGRectGetHeight(self.scrollView.frame));
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.scrollsToTop = NO;
    self.scrollView.delegate = self;
    
    self.pageControl.numberOfPages = numberPages;
    self.pageControl.currentPage = 0;
    
    [self loadScrollViewWithPage:0];
    [self loadScrollViewWithPage:1];
    [self loadScrollViewWithPage:2];
    [self loadScrollViewWithPage:3];
    [self loadScrollViewWithPage:4];
    [self loadScrollViewWithPage:5];
    [self loadScrollViewWithPage:6];
}


- (EuroView *)createViewAtIndex:(int)index
{    
    EuroView* euroView = [[EuroView alloc] initWithFrame:self.scrollView.frame page:index];
    
    [euroView.img1 addTarget:self action:@selector(toTable:) forControlEvents:UIControlEventTouchUpInside];
    [euroView.img2 addTarget:self action:@selector(toTable:) forControlEvents:UIControlEventTouchUpInside];
    [euroView.img3 addTarget:self action:@selector(toTable:) forControlEvents:UIControlEventTouchUpInside];
    
    return euroView;
}


- (void) toTable:(UIButton *)sender
{
    self.euro_value = sender.tag;
    [self performSegueWithIdentifier:@"euroTable" sender:self];
}

#pragma mark - Manage for segue

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"euroTable"])
    {
        EuroTableViewController *element = segue.destinationViewController;
        element.value =  self.euro_value;
    }
}

- (void)loadScrollViewWithPage:(NSUInteger)page
{
    EuroView *ev = [self createViewAtIndex:(int)page];
    
    if (ev.superview == nil)
    {
        CGRect frame = self.scrollView.frame;
        frame.origin.x = CGRectGetWidth(frame) * page;
        frame.origin.y = 0;
        ev.frame = frame;
        
        [self.scrollView addSubview:ev];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    CGFloat pageWidth = CGRectGetWidth(self.scrollView.frame);
    NSUInteger page = floor((self.scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.pageControl.currentPage = page;
    
    [self loadScrollViewWithPage:page - 1];
    [self loadScrollViewWithPage:page];
    [self loadScrollViewWithPage:page + 1];
}

- (void)gotoPage:(BOOL)animated
{
    NSInteger page = self.pageControl.currentPage;
    
    [self loadScrollViewWithPage:page - 1];
    [self loadScrollViewWithPage:page];
    [self loadScrollViewWithPage:page + 1];
    
    CGRect bounds = self.scrollView.bounds;
    bounds.origin.x = CGRectGetWidth(bounds) * page;
    bounds.origin.y = 0;
    [self.scrollView scrollRectToVisible:bounds animated:animated];
}

- (IBAction)changePage:(id)sender
{
    [self gotoPage:YES];
}

@end
