//
//  EuroTableViewController.h
//  CasaPlus
//
//  Created by Luca Finocchio on 23/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"

@interface EuroTableViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, MBProgressHUDDelegate>

@property (nonatomic) NSInteger value;
@property (strong, nonatomic) NSMutableArray *products;

@property (strong, nonatomic) IBOutlet UIImageView *moneyImage;
@property (strong, nonatomic) IBOutlet UILabel *moneyLabel;
@property (strong, nonatomic) IBOutlet UITableView *tableView;

- (void)getProductOutOfServer;

@end
