//
//  Product.m
//  CasaPlus
//
//  Created by Luca Finocchio on 10/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "Product.h"

@implementation Product

- (void)encodeWithCoder:(NSCoder *)encoder {
    //Encode properties
    [encoder encodeObject:self.id forKey:@"id"];
    [encoder encodeObject:self.name forKey:@"name"];
    [encoder encodeObject:self.category forKey:@"category"];
    [encoder encodeObject:self.position forKey:@"position"];
    [encoder encodeObject:self.quantity forKey:@"quantity"];
    [encoder encodeFloat:self.price forKey:@"price"];
    [encoder encodeObject:self.timestamp forKey:@"timestamp"];
    [encoder encodeObject:self.img forKey:@"img"];
    [encoder encodeObject:self.stores forKey:@"stores"];
}

- (id)initWithCoder:(NSCoder *)decoder {
    if((self = [super init])) {
        //decode properties
        self.id = [decoder decodeObjectForKey:@"id"];
        self.name = [decoder decodeObjectForKey:@"name"];
        self.category = [decoder decodeObjectForKey:@"category"];
        self.position = [decoder decodeObjectForKey:@"position"];
        self.quantity = [decoder decodeObjectForKey:@"quantity"];
        self.price = [decoder decodeFloatForKey:@"price"];
        self.timestamp = [decoder decodeObjectForKey:@"timestamp"];
        self.img = [decoder decodeObjectForKey:@"img"];
        self.stores = [decoder decodeObjectForKey:@"stores"];
    }
    return self;
}

@end
