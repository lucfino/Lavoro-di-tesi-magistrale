//
//  Recipe.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CategoryRecipe.h"

@interface Recipe : NSObject

@property (nonatomic) NSInteger id;
@property (nonatomic, strong) NSString *nome;
@property (nonatomic, strong) NSString *descrizione;
@property (nonatomic, strong) NSString *img;
@property (nonatomic, strong) CategoryRecipe *categoria;
@property (nonatomic, strong) NSMutableArray *ingredienti;
@property (nonatomic, strong) NSMutableArray *strumenti;
@property (nonatomic, strong) NSMutableArray *steps;
@property (nonatomic, strong) NSString *calorie;
@property (nonatomic, strong) NSString *difficolta;
@property (nonatomic, strong) NSString *persone;
@property (nonatomic) BOOL enabled;

@end
