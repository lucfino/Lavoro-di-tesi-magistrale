//
//  Category.m
//  CasaPlus
//
//  Created by Luca Finocchio on 16/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "Category.h"

@implementation ProductCategory

@end
