//
//  Category.h
//  CasaPlus
//
//  Created by Luca Finocchio on 16/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProductCategory : NSObject

@property (nonatomic, retain) NSNumber * id;
@property (nonatomic, retain) NSString * img;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSMutableArray * products;
@property (nonatomic, retain) NSString * timestamp;

@end
