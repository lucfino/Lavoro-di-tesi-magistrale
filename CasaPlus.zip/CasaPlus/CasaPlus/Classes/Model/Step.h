//
//  Step.h
//  CasaPlus
//
//  Created by Daniele Leombruni on 26/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Step : NSObject

@property (nonatomic) NSInteger id;
@property (nonatomic, strong) NSString *timer;
@property (nonatomic, strong) NSString *tempo;
@property (nonatomic, strong) NSString *posizione;
@property (nonatomic, strong) NSString *descrizione;
@property (nonatomic, strong) NSString *img;

@end
