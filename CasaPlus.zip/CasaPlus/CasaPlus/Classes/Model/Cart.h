//
//  Cart.h
//  CasaPlus
//
//  Created by Luca Finocchio on 31/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Cart : NSObject

@property (nonatomic, strong) NSMutableArray *cartItems;

@end
