//
//  CategoryRecipe.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CategoryRecipe : NSObject

@property (nonatomic) NSInteger id;
@property (nonatomic, strong) NSString *nome;
@property (nonatomic, strong) NSString *img;
@property (nonatomic) NSInteger ordine;

@end
