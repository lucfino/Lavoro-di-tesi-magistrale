//
//  CartItem.m
//  CasaPlus
//
//  Created by Luca Finocchio on 31/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "CartItem.h"

@implementation CartItem

- (void)encodeWithCoder:(NSCoder *)encoder {
    //Encode properties
    [encoder encodeObject:self.product forKey:@"product"];
    [encoder encodeObject:self.quantityCart forKey:@"quantityCart"];
    [encoder encodeBool:self.selected forKey:@"selected"];
}

- (id)initWithCoder:(NSCoder *)decoder {
    if((self = [super init])) {
        //decode properties
        self.product = [decoder decodeObjectForKey:@"product"];
        self.quantityCart = [decoder decodeObjectForKey:@"quantityCart"];
        self.selected = [decoder decodeBoolForKey:@"selected"];
    }
    return self;
}

@end
