//
//  Cart.m
//  CasaPlus
//
//  Created by Luca Finocchio on 31/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "Cart.h"

@implementation Cart

- (id)init {
    self = [super init];
    if (self) {
        self.cartItems = [[NSMutableArray alloc] init];
        //NSLog(@"cartItems:%@", self.cartItems);
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder {
    //Encode properties
    [encoder encodeObject:self.cartItems forKey:@"cart"];
}

- (id)initWithCoder:(NSCoder *)decoder {
    if((self = [super init])) {
        //decode properties
        self.cartItems= [decoder decodeObjectForKey:@"cart"];
    }
    return self;
}

@end
