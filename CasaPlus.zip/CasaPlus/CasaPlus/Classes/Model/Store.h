//
//  Store.h
//  CasaPlus
//
//  Created by Luca Finocchio on 13/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Store : NSObject

@property (nonatomic) NSInteger id;
@property (nonatomic, strong) NSString *nome;
@property (nonatomic) double lat;
@property (nonatomic) double lon;
@property (nonatomic, strong) NSString *indirizzo;
@property (nonatomic, strong) NSString *telefono;
@property (nonatomic, strong) NSString *timestamp;

@end
