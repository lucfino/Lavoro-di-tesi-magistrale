//
//  Store.m
//  CasaPlus
//
//  Created by Luca Finocchio on 13/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "Store.h"

@implementation Store

- (void)encodeWithCoder:(NSCoder *)encoder {
    //Encode properties
    [encoder encodeInteger:self.id forKey:@"id"];
    [encoder encodeObject:self.nome forKey:@"nome"];
    [encoder encodeDouble:self.lat forKey:@"lat"];
    [encoder encodeDouble:self.lon forKey:@"lon"];
    [encoder encodeObject:self.indirizzo forKey:@"indirizzo"];
    [encoder encodeObject:self.telefono forKey:@"telefono"];
    [encoder encodeObject:self.timestamp forKey:@"timestamp"];
}

- (id)initWithCoder:(NSCoder *)decoder {
    if((self = [super init])) {
        //decode properties
        self.id = [decoder decodeIntegerForKey:@"id"];
        self.nome = [decoder decodeObjectForKey:@"nome"];
        self.lat = [decoder decodeDoubleForKey:@"lat"];
        self.lon = [decoder decodeDoubleForKey:@"lon"];
        self.indirizzo = [decoder decodeObjectForKey:@"indirizzo"];
        self.telefono = [decoder decodeObjectForKey:@"telefono"];
        self.timestamp = [decoder decodeObjectForKey:@"timestamp"];
    }
    return self;
}

@end
