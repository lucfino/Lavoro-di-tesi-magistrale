//
//  CartItem.h
//  CasaPlus
//
//  Created by Luca Finocchio on 31/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Product.h"

@interface CartItem : NSObject

@property (nonatomic, strong) Product *product;
@property (nonatomic, strong) NSString *quantityCart;
@property (nonatomic) BOOL selected;

@end
