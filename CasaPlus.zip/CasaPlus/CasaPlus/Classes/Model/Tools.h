//
//  Tools.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "Product.h"

@interface Tools : Product

@property (strong, nonatomic) NSString *note;

@end
