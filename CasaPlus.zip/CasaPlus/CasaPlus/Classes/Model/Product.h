//
//  Product.h
//  CasaPlus
//
//  Created by Luca Finocchio on 10/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Product : NSObject

@property (nonatomic) NSNumber *id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSMutableArray *category;
@property (nonatomic, strong) NSString *position;
@property (nonatomic, strong) NSString *quantity;
@property (nonatomic) float price;
@property (nonatomic, strong) NSString *timestamp;
@property (nonatomic, strong) NSString *img;
@property (nonatomic, strong) NSMutableArray *stores;

@end
