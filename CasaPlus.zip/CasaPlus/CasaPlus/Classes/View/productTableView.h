//
//  productTableView.h
//  CasaPlus
//
//  Created by Luca Finocchio on 10/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

@interface productTableView : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *productImage;

@property (strong, nonatomic) IBOutlet UILabel *productName;

@property (strong, nonatomic) IBOutlet UILabel *productCategory;

@property (strong, nonatomic) IBOutlet UILabel *productPrice;

@end
