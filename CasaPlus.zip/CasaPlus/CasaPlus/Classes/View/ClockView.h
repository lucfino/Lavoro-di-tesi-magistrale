//
//  ClockView.h
//  clock
//
//  Created by Ignacio Enriquez Gutierrez on 1/31/11.
//  Copyright 2011 Nacho4D. All rights reserved.
//  See the file License.txt for copying permission.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ClockView : UIView {
    
	CALayer *hourHand;
	CALayer *minHand;
	CALayer *secHand;
    CALayer *centro;
	NSTimer *timer;

}

@property (strong, nonatomic) IBOutlet UIImageView *containerLayer;


- (void)start;
- (void)stop;

- (void)setHourHandImage:(CGImageRef)image;
- (void)setMinHandImage:(CGImageRef)image;
- (void)setSecHandImage:(CGImageRef)image;
- (void)setClockBackgroundImage:(UIImage *)image;

@end
