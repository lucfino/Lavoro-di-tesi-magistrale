//
//  StepView.m
//  CasaPlus
//
//  Created by Daniele Leombruni on 26/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "StepView.h"
#import "UIImageView+AFNetworking.h"

@implementation StepView

- (id)initWithFrame:(CGRect)frame image:(NSString *)img step:(NSString *)step descrizione:(NSString *)desc timer:(bool)isTimer countdown:(NSString *)countdown
{
    self = [super initWithFrame:frame];
    if (self) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        self.isTimer = isTimer;
        
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.immagine = [[UIImageView alloc] initWithFrame:CGRectMake(20, 20, 120, 120)];
        else
            self.immagine = [[UIImageView alloc] initWithFrame:CGRectMake(50, 20, 240, 240)];
        NSString *img_url = [NSString stringWithFormat:@"%@%@%@", [defaults objectForKey:@"url"], @"media/com_casaplus/images/",img];
        [self.immagine setImageWithURL:[NSURL URLWithString:img_url] placeholderImage:[UIImage imageNamed:@"default_product" ]];
        
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.step = [[UILabel alloc] initWithFrame:CGRectMake(158, 20, 142, 21)];
        else {
            self.step = [[UILabel alloc] initWithFrame:CGRectMake(430, 20, 284, 42)];
            [self.step setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        self.step.text = [NSString stringWithFormat:@"Step %@", step];
        self.step.textAlignment = NSTextAlignmentCenter;
        
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.timerLabel = [[UILabel alloc] initWithFrame:CGRectMake(158, 53, 142, 35)];
        else{
            self.timerLabel = [[UILabel alloc] initWithFrame:CGRectMake(430, 80, 284, 70)];
            [self.timerLabel setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        self.timerLabel.text = @"00:00:00";
        self.timerLabel.textAlignment = NSTextAlignmentCenter;
        self.timerLabel.backgroundColor = [UIColor whiteColor];
        [self.timerLabel.layer setBorderColor:[UIColor blackColor].CGColor];
        [self.timerLabel.layer setBorderWidth:2.0f];
        self.timerLabel.layer.cornerRadius = 5.0f;
        self.ore = [countdown integerValue] / 3600;
        NSString *hours = [NSString stringWithFormat:@"%ld", (long)self.ore];
        if ([hours integerValue] < 10) {
            hours = [NSString stringWithFormat:@"0%@", hours];
        }
        self.minuti = [countdown integerValue] / 60;
        NSString *minutes = [NSString stringWithFormat:@"%ld", (long)self.minuti];
        if ([minutes integerValue] < 10) {
            minutes = [NSString stringWithFormat:@"0%@", minutes];
        }
        self.secondi = [countdown integerValue] % 60;
        NSString *seconds = [NSString stringWithFormat:@"%ld", (long)self.secondi];
        if ([seconds integerValue] < 10) {
            seconds = [NSString stringWithFormat:@"0%@", seconds];
        }
        if (isTimer) {
            self.timerLabel.text = [NSString stringWithFormat:@"%@:%@:%@", hours, minutes, seconds];
        }
        
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.start = [[UIButton alloc] initWithFrame:CGRectMake(158, 102, 65, 38)];
        else{
            self.start = [[UIButton alloc] initWithFrame:CGRectMake(450, 162, 130, 76)];
            [self.start.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        [self.start setTitle:@"Start" forState:UIControlStateNormal];
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.stop = [[UIButton alloc] initWithFrame:CGRectMake(158, 102, 65, 38)];
        else{
            self.stop = [[UIButton alloc] initWithFrame:CGRectMake(450, 162, 130, 76)];
            [self.stop.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        [self.stop setTitle:@"Pausa" forState:UIControlStateNormal];
        self.stop.hidden = YES;
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.avanti = [[UIButton alloc] initWithFrame:CGRectMake(231, 102, 65, 38)];
        else{
            self.avanti = [[UIButton alloc] initWithFrame:CGRectMake(581, 162, 130, 76)];
            [self.avanti.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        [self.avanti setTitle:@"Avanti" forState:UIControlStateNormal];
        
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
            self.descrizione = [[UILabel alloc] initWithFrame:CGRectMake(20, 154, 280, 250)];
        else{
            self.descrizione = [[UILabel alloc] initWithFrame:CGRectMake(50, 300, 660, 450)];
            [self.descrizione setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        self.descrizione.backgroundColor = [UIColor whiteColor];
        [self.descrizione.layer setBorderColor:[UIColor blackColor].CGColor];
        [self.descrizione.layer setBorderWidth:2.0f];
        self.descrizione.textAlignment = NSTextAlignmentCenter;
        self.descrizione.layer.cornerRadius = 5.0f;
        self.descrizione.numberOfLines = 10;
        self.descrizione.text = desc;
        
        [self addSubview:self.immagine];
        [self addSubview:self.step];
        [self addSubview:self.timerLabel];
        [self addSubview:self.start];
        [self addSubview:self.stop];
        [self addSubview:self.avanti];
        [self addSubview:self.descrizione];
    }
    
    return self;
}


@end
