//
//  CustomTableViewHeader.h
//  CasaPlus
//
//  Created by Luca Finocchio on 16/11/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SectionHeaderViewDelegate;

@interface CustomTableViewHeader : UIView

@property (nonatomic, weak) id <SectionHeaderViewDelegate> delegate;
@property (nonatomic, weak) UILabel *categoryLabel;

@property (nonatomic, weak) UIImageView *categoryImg;

- (id)initWithFrame:(CGRect)frame section:(NSInteger)sectionNumber delegate:(id <SectionHeaderViewDelegate>)delegate;
- (void)toggleOpenWithUserAction:(BOOL)userAction;

@end

@protocol SectionHeaderViewDelegate <NSObject>

@optional

-(void)sectionHeaderView:(CustomTableViewHeader*)sectionHeaderView sectionOpened:(NSInteger)section;
-(void)sectionHeaderView:(CustomTableViewHeader*)sectionHeaderView sectionClosed:(NSInteger)section;

@end
