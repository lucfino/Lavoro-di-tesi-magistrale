//
//  StepView.h
//  CasaPlus
//
//  Created by Daniele Leombruni on 26/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StepView : UIView

@property (strong, nonatomic) UIImageView *immagine;
@property (strong, nonatomic) UILabel *step;
@property (strong, nonatomic) UILabel *timerLabel;
@property (strong, nonatomic) UIButton *start;
@property (strong, nonatomic) UIButton *stop;
@property (strong, nonatomic) UIButton *avanti;
@property (strong, nonatomic) UILabel *descrizione;

@property (nonatomic) NSInteger ore;
@property (nonatomic) NSInteger minuti;
@property (nonatomic) NSInteger secondi;
@property (nonatomic) bool isTimer;

- (id)initWithFrame:(CGRect)frame image:(NSString *)img step:(NSString *)step descrizione:(NSString *)desc timer:(bool)isTimer countdown:(NSString *)countdown;

@end
