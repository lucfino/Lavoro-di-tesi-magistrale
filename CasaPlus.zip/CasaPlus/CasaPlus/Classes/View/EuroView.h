//
//  EuroView.h
//  CasaPlus
//
//  Created by Daniele Leombruni on 16/01/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EuroView : UIView

@property (strong, nonatomic) UILabel* b1;
@property (strong, nonatomic) UILabel* b2;
@property (strong, nonatomic) UILabel* b3;

@property (strong, nonatomic) UIButton* img1;
@property (strong, nonatomic) UIButton* img2;
@property (strong, nonatomic) UIButton* img3;

- (id)initWithFrame:(CGRect)frame page:(int)page;

@end
