//
//  RecipeTableView.m
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RecipeTableView.h"

@implementation RecipeTableView

@end
