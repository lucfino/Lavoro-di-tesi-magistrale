//
//  quantityTableView.h
//  CasaPlus
//
//  Created by Luca Finocchio on 15/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface quantityTableView : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *name;

@property (strong, nonatomic) IBOutlet UILabel *category;

@property (strong, nonatomic) IBOutlet UIButton *deleteButton;

@property (strong, nonatomic) IBOutlet UITextField *quantity;

@property (strong, nonatomic) IBOutlet UIImageView *image;

@end
