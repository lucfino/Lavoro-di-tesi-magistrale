//
//  euroTableView.m
//  CasaPlus
//
//  Created by Luca Finocchio on 23/12/13.
//  Copyright (c) 2013 GLDeV. All rights reserved.
//

#import "euroTableView.h"

@implementation euroTableView

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
