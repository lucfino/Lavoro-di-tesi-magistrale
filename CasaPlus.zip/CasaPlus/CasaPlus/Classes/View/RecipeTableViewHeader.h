//
//  RecipeTableViewHeader.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SectionRecipeHeaderViewDelegate;

@interface RecipeTableViewHeader : UIView

@property (nonatomic, weak) id <SectionRecipeHeaderViewDelegate> delegate;
@property (nonatomic, weak) UILabel *categoryLabel;
@property (nonatomic, weak) UIImageView *categoryImg;

- (id)initWithFrame:(CGRect)frame section:(NSInteger)sectionNumber delegate:(id <SectionRecipeHeaderViewDelegate>)delegate;
- (void)toggleOpenWithUserAction:(BOOL)userAction;

@end

@protocol SectionRecipeHeaderViewDelegate <NSObject>

@optional

-(void)sectionHeaderView:(RecipeTableViewHeader*)sectionHeaderView sectionOpened:(NSInteger)section;
-(void)sectionHeaderView:(RecipeTableViewHeader*)sectionHeaderView sectionClosed:(NSInteger)section;

@end
