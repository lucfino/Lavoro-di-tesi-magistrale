//
//  EuroView.m
//  CasaPlus
//
//  Created by Daniele Leombruni on 16/01/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "EuroView.h"

@implementation EuroView

- (id)initWithFrame:(CGRect)frame page:(int)page
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.b1 = [[UILabel alloc] initWithFrame:CGRectMake(100, 130, 120, 25)];
        [[self.b1 layer] setBorderColor:[UIColor blackColor].CGColor];
        [[self.b1 layer] setBorderWidth:2.0f];
        [self.b1 layer].cornerRadius = 5.0f;
        self.b1.backgroundColor = [UIColor whiteColor];
        self.b1.textAlignment = 1;
        self.img1 = [[UIButton alloc] initWithFrame:CGRectMake(100, 5, 120, 120)];
        [self.img1.imageView setContentMode:UIViewContentModeScaleAspectFit];
        if (! ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )) {
            [self.img1 setFrame:CGRectMake(264, 75, 240, 240)];
            [self.b1 setFrame:CGRectMake(264, 300, 240, 50)];
            NSLog(@"%@", self.b1.font);
            [self.b1 setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        
        self.b2 = [[UILabel alloc] initWithFrame:CGRectMake(100, 290, 120, 25)];
        [[self.b2 layer] setBorderColor:[UIColor blackColor].CGColor];
        [[self.b2  layer] setBorderWidth:2.0f];
        [self.b2 layer].cornerRadius = 5.0f;
        self.b2.backgroundColor = [UIColor whiteColor];
        self.b2.textAlignment = 1;
        self.img2 = [[UIButton alloc] initWithFrame:CGRectMake(100, 160, 120, 120)];
        [self.img2.imageView setContentMode:UIViewContentModeScaleAspectFit];
        if (! ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )) {
            [self.img2 setFrame:CGRectMake(264, 350, 240, 240)];
            [self.b2 setFrame:CGRectMake(264, 575, 240, 50)];
            [self.b2 setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        
        self.b3 = [[UILabel alloc] initWithFrame:CGRectMake(100, 440, 120, 25)];
        [[self.b3 layer] setBorderColor:[UIColor blackColor].CGColor];
        [[self.b3 layer] setBorderWidth:2.0f];
        [self.b3 layer].cornerRadius = 5.0f;
        self.b3.textAlignment = 1;
        self.b3.backgroundColor = [UIColor whiteColor];
        self.img3 = [[UIButton alloc] initWithFrame:CGRectMake(100, 315, 120, 120)];
        [self.img3.imageView setContentMode:UIViewContentModeScaleAspectFit];
        if (! ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )) {
            [self.img3 setFrame:CGRectMake(264, 625, 240, 240)];
            [self.b3 setFrame:CGRectMake(264, 850, 240, 50)];
            [self.b3 setFont:[UIFont fontWithName:@"HelveticaNeue" size:25]];
        }
        
        switch (page) {
                
            case 0:
                self.b1.text = @"0.01 €";
                self.img1.tag = 1;
                [self.img1 setImage:[UIImage imageNamed:@"money_1"] forState:UIControlStateNormal];
                
                self.b2.text = @"0.02 €";
                self.img2.tag = 2;
                [self.img2 setImage:[UIImage imageNamed:@"money_2"] forState:UIControlStateNormal];
                
                self.b3.text = @"0.05 €";
                self.img3.tag = 5;
                [self.img3 setImage:[UIImage imageNamed:@"money_5"] forState:UIControlStateNormal];
                
                break;
            case 1:
                self.b1.text = @"0.10 €";
                self.img1.tag = 10;
                [self.img1 setImage:[UIImage imageNamed:@"money_10"] forState:UIControlStateNormal];
                
                self.b2.text = @"0.20 €";
                self.img2.tag = 20;
                [self.img2 setImage:[UIImage imageNamed:@"money_20"] forState:UIControlStateNormal];
                
                self.b3.text = @"0.50 €";
                self.img3.tag = 50;
                [self.img3 setImage:[UIImage imageNamed:@"money_50"] forState:UIControlStateNormal];
                
                break;
            case 2:
                self.b1.text = @"1.00 €";
                self.img1.tag = 100;
                [self.img1 setImage:[UIImage imageNamed:@"money_100"] forState:UIControlStateNormal];
                
                self.b2.text = @"2.00 €";
                self.img2.tag = 200;
                [self.img2 setImage:[UIImage imageNamed:@"money_200"] forState:UIControlStateNormal];
                
                self.b3.text = @"0.50 + 0.50 €";
                self.img3.tag = 51;
                [self.img3 setImage:[UIImage imageNamed:@"money_51"] forState:UIControlStateNormal];
                if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"])
                    [self.img3 setFrame:CGRectMake(60, 275, 200, 200)];
                else
                    [self.img3 setFrame:CGRectMake(260, 575, 240, 400)];
                
                break;
            case 3:
                self.b1.text = @"5.00 €";
                [self.b1 setFrame:CGRectMake(100, 190, 120, 25)];
                self.img1.tag = 500;
                [self.img1 setFrame:CGRectMake(60, 25, 200, 200)];
                [self.img1 setImage:[UIImage imageNamed:@"money_500"] forState:UIControlStateNormal];
                
                self.b2.text = @"10.00 €";
                [self.b2 setFrame:CGRectMake(100, 390, 120, 25)];
                self.img2.tag = 1000;
                [self.img2 setFrame:CGRectMake(60, 220, 200, 200)];
                [self.img2 setImage:[UIImage imageNamed:@"money_1000"] forState:UIControlStateNormal];
                
                if (! ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )) {
                    [self.b1 setFrame:CGRectMake(184, 375, 400, 50)];
                    [self.img1 setFrame:CGRectMake(184, 50, 400, 400)];
                    [self.b2 setFrame:CGRectMake(184, 725, 400, 50)];
                    [self.img2 setFrame:CGRectMake(184, 400, 400, 400)];
                }
                
                [self.b3 setHidden:YES];
                [self.img3 setHidden:YES];
                
                break;
            case 4:
                self.b1.text = @"20.00 €";
                [self.b1 setFrame:CGRectMake(100, 190, 120, 25)];
                self.img1.tag = 2000;
                [self.img1 setFrame:CGRectMake(60, 25, 200, 200)];
                [self.img1 setImage:[UIImage imageNamed:@"money_2000"] forState:UIControlStateNormal];
                
                self.b2.text = @"50.00 €";
                [self.b2 setFrame:CGRectMake(100, 390, 120, 25)];
                self.img2.tag = 5000;
                [self.img2 setFrame:CGRectMake(60, 220, 200, 200)];
                [self.img2 setImage:[UIImage imageNamed:@"money_5000"] forState:UIControlStateNormal];
                
                if (! ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )) {
                    [self.b1 setFrame:CGRectMake(184, 375, 400, 50)];
                    [self.img1 setFrame:CGRectMake(184, 50, 400, 400)];
                    [self.b2 setFrame:CGRectMake(184, 725, 400, 50)];
                    [self.img2 setFrame:CGRectMake(184, 400, 400, 400)];
                }
                
                [self.b3 setHidden:YES];
                [self.img3 setHidden:YES];
                
                break;
            case 5:
                self.b1.text = @"100.00 €";
                [self.b1 setFrame:CGRectMake(100, 190, 120, 25)];
                self.img1.tag = 10000;
                [self.img1 setFrame:CGRectMake(60, 25, 200, 200)];
                [self.img1 setImage:[UIImage imageNamed:@"money_10000"] forState:UIControlStateNormal];
                
                self.b2.text = @"200.00 €";
                [self.b2 setFrame:CGRectMake(100, 390, 120, 25)];
                self.img2.tag = 20000;
                [self.img2 setFrame:CGRectMake(60, 220, 200, 200)];
                [self.img2 setImage:[UIImage imageNamed:@"money_20000"] forState:UIControlStateNormal];
                
                if (! ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )) {
                    [self.b1 setFrame:CGRectMake(184, 375, 400, 50)];
                    [self.img1 setFrame:CGRectMake(184, 50, 400, 400)];
                    [self.b2 setFrame:CGRectMake(184, 725, 400, 50)];
                    [self.img2 setFrame:CGRectMake(184, 400, 400, 400)];
                }
                
                [self.b3 setHidden:YES];
                [self.img3 setHidden:YES];
                
                break;
            case 6:
                self.b1.text = @"500.00 €";
                [self.b1 setFrame:CGRectMake(100, 300, 120, 25)];
                self.img1.tag = 50000;
                [self.img1 setFrame:CGRectMake(60, 135, 200, 200)];
                [self.img1 setImage:[UIImage imageNamed:@"money_50000"] forState:UIControlStateNormal];
                
                if (! ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )) {
                    [self.b1 setFrame:CGRectMake(184, 600, 400, 50)];
                    [self.img1 setFrame:CGRectMake(184, 250, 400, 400)];
                }
                
                [self.b2 setHidden:YES];
                [self.img2 setHidden:YES];
                
                [self.b3 setHidden:YES];
                [self.img3 setHidden:YES];
                
                break;
            default:
                break;
        }
        
        [self addSubview:self.b1];
        [self addSubview:self.img1];
        [self addSubview:self.b2];
        [self addSubview:self.img2];
        [self addSubview:self.b3];
        [self addSubview:self.img3];
    }
    
    return self;
}


@end
