//
//  RecipeTableView.h
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeTableView : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *label;
@property (strong, nonatomic) IBOutlet UILabel *categoria;
@property (strong, nonatomic) IBOutlet UIImageView *immagine;

@end
