//
//  RecipeTableViewHeader.m
//  CasaPlus
//
//  Created by Luca Finocchio on 25/02/14.
//  Copyright (c) 2014 GLDeV. All rights reserved.
//

#import "RecipeTableViewHeader.h"

@interface RecipeTableViewHeader()

@property (nonatomic, weak) UIButton *disclosureButton;
@property (nonatomic, strong) UIImageView *productBorderImage;
@property (nonatomic, assign) NSInteger section;

@end

@implementation RecipeTableViewHeader

-(id)initWithFrame:(CGRect)frame section:(NSInteger)sectionNumber delegate:(id <SectionRecipeHeaderViewDelegate>)delegate
{
    self = [super initWithFrame:frame];
    
    if (self != nil) {
        
        // Aggiungo l'azione al tap dell'header
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleOpen:)];
        [self addGestureRecognizer:tapGesture];
        self.userInteractionEnabled = YES;
        
        // Setto il delegate
        self.delegate = delegate;
        
        // Setto il colore dello sfondo, e l'arrotondamento degli angoli
        self.backgroundColor = [UIColor colorWithRed:0.0 green:0.56 blue:0.80 alpha:1];
        self.layer.borderWidth = 0.5f;
        self.layer.cornerRadius = 3.0f;
        
        // Setto il bottone (chiuso o aperto)
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )
            button.frame = CGRectMake(2.0, 20.0, 35.0, 35.0);
        else
            button.frame = CGRectMake(20.0, 42.5, 55.0, 55.0);
        button.backgroundColor = [UIColor clearColor];
        [button setImage:[UIImage imageNamed:@"down-arrow-icon"] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:@"up-arrow-icon"] forState:UIControlStateSelected];
        [button addTarget:self action:@selector(toggleOpen:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
        self.disclosureButton = button;
        
        // Immagine della categoria
        CGRect imageLabelFrame;
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] )
            imageLabelFrame = CGRectMake(38.0, 10.0, 60.0, 60.0);
        else
            imageLabelFrame = CGRectMake(80.0, 20.0, 100.0, 100.0);
        UIImageView *productImage = [[UIImageView alloc]initWithFrame:imageLabelFrame];
        productImage.layer.borderWidth = 0.5f;
        productImage.layer.borderColor = [[UIColor blackColor] CGColor];
        productImage.layer.cornerRadius = 3.0f;
        [self addSubview:productImage];
        self.categoryImg=productImage;
        
        // Nome della categoria
        CGRect titleLabelFrame;
        UILabel *label;
        if ([[UIDevice currentDevice].model isEqualToString:@"iPhone"] || [[UIDevice currentDevice].model isEqualToString:@"iPhone Simulator"] ) {
            titleLabelFrame = CGRectMake(100.0, 20.0, 235.0, 35.0);
            label = [[UILabel alloc] initWithFrame:titleLabelFrame];
            label.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
        } else {
            titleLabelFrame = CGRectMake(200.0, 50.0, 535.0, 40.0);
            label = [[UILabel alloc] initWithFrame:titleLabelFrame];
            label.font = [UIFont fontWithName:@"HelveticaNeue" size:27];
        }
        label.textColor = [UIColor blackColor];
        [self addSubview:label];
        self.categoryLabel = label;
        
        self.section = sectionNumber;
    }
    return self;
}

-(void)toggleOpen:(id)sender {
    
    [self toggleOpenWithUserAction:YES];
}

-(void)toggleOpenWithUserAction:(BOOL)userAction {
    
    self.disclosureButton.selected = !self.disclosureButton.selected;
    
    //Se viene riconosciuta un'azione dell'utente viene inviato al delegate il messaggio corretto
    if (userAction /*&& ([[NSUserDefaults standardUserDefaults] boolForKey:@"pref_visual_grouped"] == YES)*/){
        if (self.disclosureButton.selected) {
            if ([self.delegate respondsToSelector:@selector(sectionHeaderView:sectionOpened:)]) {
                [self.delegate sectionHeaderView:self sectionOpened:self.section];
            }
        }
        else {
            if ([self.delegate respondsToSelector:@selector(sectionHeaderView:sectionClosed:)]) {
                [self.delegate sectionHeaderView:self sectionClosed:self.section];
            }
        }
    }
}



@end
