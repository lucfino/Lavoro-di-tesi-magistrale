var arr = new Array();

function compatta ( array, index ) {
	var j;
	for ( j=index; j<(array.length - 1); j++ )
		array[j] = array[j+1];
	array.length--;
}

function checkAll(check, values, max){
	var nodeList = document.getElementsByName('checkDev');
	if (check.checked){
		for (i=0; i<nodeList.length; i++){
			nodeList[i].checked = true;
		}
		arr = values.split('&');
		arr.pop();
	}else {
		for (i=0; i<nodeList.length; i++){
			nodeList[i].checked = false;
		}
		arr = new Array();
	}
	document.getElementById("check").value = arr;
}

function callSetDevlist(token, uid, badgeCount){
	if (arr.indexOf(token+";"+uid+";"+badgeCount) == -1)
		arr.push(token+";"+uid+";"+badgeCount);
	else
		compatta(arr ,arr.indexOf(token+";"+uid+";"+badgeCount));

	if(arr.length == 0)
		document.getElementById("checkAll").checked = false;
	
	document.getElementById("check").value = arr;
}

