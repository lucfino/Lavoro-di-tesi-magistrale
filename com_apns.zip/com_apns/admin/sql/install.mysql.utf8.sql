CREATE TABLE `#__apns_devlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `appName` varchar(100) NOT NULL,
  `appVersion` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL default 'not logged',
  `pushBadge` varchar(100) NOT NULL,
  `pushSound` varchar(100) NOT NULL,
  `pushAlert` varchar(100) NOT NULL,
  `badgeCount` int(4) NOT NULL,
  `devUid` varchar(100) NOT NULL,
  `devName` varchar(100) NOT NULL,
  `devModel` varchar(100) NOT NULL,
  `devSo` varchar(100) NOT NULL,
  `devToken` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

CREATE TABLE `#__apns_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certificato` varchar(100) NOT NULL,
  `production` varchar(255) NOT NULL,
  `developer` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `passwordPro` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

INSERT INTO `#__apns_general` (`id`, `certificato`, `production`, `developer`, `password`, `passwordPro`) VALUES
(1, 'Developer', '', '', '', '');
