DROP TABLE IF EXISTS `#__apns_devlist`;
DROP TABLE IF EXISTS `#__apns_general`;