<?php

defined('_JEXEC') or die('Restricted access');

class TableDevlist extends JTable
{
    function __construct( &$db ) {
        parent::__construct('#__apns_devlist', 'id', $db);
    }
}