<?php

defined('_JEXEC') or die('Restricted access');

class TableGeneral extends JTable
{
    function __construct( &$db ) {
        parent::__construct('#__apns_general', 'id', $db);
    }
}