<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controllerform');

class ApnsControllerGeneral extends JControllerForm{
	
	public function __construct($config = array())
	{
		$this->view_list = 'devlists';
		parent::__construct($config);
	}

	public function save()
	{
		// gestione del tipo di certificato
		$model = $this->getModel('General');
		$certificato = $_POST['jform']['certificato'];
		$password = $_POST['jform']['password'];
		$passwordPro = $_POST['jform']['passwordPro'];
		$model->updateCertificato($certificato, $password, $passwordPro);

		// gestione del certificato
		JClientHelper::setCredentialsFromRequest('ftp');
		$filename = $_FILES['jform']['name']['developerFile'];
		$tmp_name  = $_FILES['jform']['tmp_name']['developerFile'];
		$filename1 = $_FILES['jform']['name']['productionFile'];
		$tmp_name1  = $_FILES['jform']['tmp_name']['productionFile'];

		if ($filename != ""){
			$_POST['jform']['developer'] = $filename;
		}
		if ($filename1 != ""){
			$_POST['jform']['production'] = $filename1;
		}

		$filepath = JPATH_ROOT.DS.'media'.DS.'com_apns'.DS.'certificates'.DS.'dev'.DS.$filename;
		$filepath1 = JPATH_ROOT.DS.'media'.DS.'com_apns'.DS.'certificates'.DS.'prod'.DS.$filename1;
      
		$allowed = array('application/x-pem-file', 'application/x-x509-ca-cert', '', 'application/octet-stream');
		
		if ($filename == "" && $filename1 == ""){
			JFactory::getApplication()->enqueueMessage('Elemento salvato.');
			$this->setRedirect('index.php?option=com_apns&view=general&layout=edit&id=1');
			$this->redirect();
		}      

		if (!in_array($_FILES['jform']['type']['developerFile'], $allowed) || !in_array($_FILES['jform']['type']['productionFile'], $allowed)) 
		{
		        echo "<script> alert('The file you are trying to upload is not supported.');
		      window.history.back();</script>\n";
		        exit;
		}
		else 
		{
			if ($tmp_name != ""){
		    	JFile::upload($tmp_name, $filepath);
		    	$model->updateDev($filename);
		    }
		    if ($tmp_name1 != ""){
		    	JFile::upload($tmp_name1, $filepath1);
		    	$model->updateProd($filename1);
		    }
		}

		JFactory::getApplication()->enqueueMessage('Elemento salvato.');
		$this->setRedirect(
			JRoute::_(
						'index.php?option=com_apns&view=general&layout=edit&id=1', false
					)
		);
		$this->redirect();

	}


}