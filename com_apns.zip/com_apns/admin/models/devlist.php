<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modeladmin' );

class ApnsModelDevlist extends JModelAdmin{    

	public function getForm($data = array(), $loadData = true)
    {
    	$form = $this->loadForm('com_apns.devlist', 'devlist',
    			array('control' => 'jform', 'load_data' => $loadData));
    	if (!$form){
    		return false;} 
    	else{
    		return $form;}
    }
    	
    public function loadFormData()
    {
    	$data = $this->getItem();
    	return $data;
    }
    
}