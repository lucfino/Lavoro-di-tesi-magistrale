<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modeladmin' );

class ApnsModelGeneral extends JModelAdmin{    

    public function getForm($data = array(), $loadData = true)
    {
        $form = $this->loadForm('com_apns.general', 'general',
                array('control' => 'jform', 'load_data' => $loadData));
        if (!$form){
            return false;} 
        else{
            return $form;}
    }
        
    public function loadFormData()
    {
        $data = $this->getItem();
        return $data;
    }

    public function updateCertificato($certificato, $password, $passwordPro)
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query = "UPDATE `#__apns_general` SET `certificato`='".$certificato."', `password`='".$password."', `passwordPro`='".$passwordPro."' WHERE `id`=1";
        $db->setQuery($query);
        //die(var_dump($query));
        $db->query();
    }

    public function updateDev($filename)
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query = "UPDATE `#__apns_general` SET `developer`='".$filename."' WHERE `id`=1";
        $db->setQuery($query);
        $db->query();
    }


    public function updateProd($filename)
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query = "UPDATE `#__apns_general` SET `production`='".$filename."' WHERE `id`=1";
        $db->setQuery($query);
        $db->query();
    }
}