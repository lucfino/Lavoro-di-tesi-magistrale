<?php 

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$task = JRequest::getCmd('task');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

?>

<jdoc:include type="message" />

<form action="index.php" method="post" name="adminForm" id="devlist-admin-form" class="form-validate" enctype = "multipart/form-data">
    <input type="hidden" name="option" value="<?=$option?>" />
    <input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="id" value="<?=$this->item->id?>" />
    <?php echo JHtml::_('form.token'); ?>
 
	<fieldset class="adminform">
	    <legend><?=JText::_( 'COM_APNS_GENERAL_DETAILS' ); ?></legend>
	        <ul class="adminformlist">
	<?    foreach ($this->form->getFieldset() as $field) { ?>
	            <li><?=$field->label?><?=$field->input?></li>
	<?    } ?>
	        </ul>
	    <? 
	        $f = $this->form->getFieldset();
	     	
	        if ($f['jform_certificato']->value == "Developer"){
	        	if ($f['jform_developer']->value == "")
	        		echo '<h3 class="h3CheckCertDev"><img class="checkCert" src="../media/com_apns/images/no.png" height="20" width="20">  Nessun certificato caricato</h3>'; 
	        	else
	    			echo '<h3 class="h3CheckCertDev"><img class="checkCert" src="../media/com_apns/images/yes.png" height="20" width="20">  In uso : '.$f['jform_developer']->value.'</h3>'; 
	        }else{
	        	if ($f['jform_production']->value == "")
	        		echo '<h3 class="h3CheckCertPro"><img class="checkCert" src="../media/com_apns/images/no.png" height="20" width="20">  Nessun certificato caricato</h3>'; 
	        	else
	        		echo '<h3 class="h3CheckCertPro"><img class="checkCert" src="../media/com_apns/images/yes.png" height="20" width="20">  In uso : '.$f['jform_production']->value.'</h3>';
	    	}
	    ?>
	</fieldset>
</form>
