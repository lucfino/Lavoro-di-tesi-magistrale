<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.view' );

class ApnsViewGeneral extends JView{
    
    function display($tpl = null)
    {
        JRequest::setVar('hidemainmenu', true);
        JHtml::stylesheet('com_apns/admin.stylesheet.css', array(), true);

        $this->addToolBar(null);
        $this->setDocument();
        $item = $this->get( 'Item' );
        $form = $this->get( 'Form' );
        $isNew = ($item->id < 1);
        $this->item = $item;
        $this->form = $form;

        parent::display($tpl);
        
    }
    
    protected function addToolBar($total=null)
    {
        JToolBarHelper::title( JText::_( 'COM_APNS_CERTIFICATES_EDIT' ), 'users_edit.png' );
        JToolBarHelper::apply('general.apply');
        JToolBarHelper::back('Indietro', 'index.php?option=com_apns');
    }
    
    function setDocument()
    {
        $document = JFactory::getDocument();
        $document->addStyleDeclaration('.icon-48-users_add {background-image:
                                url(../media/com_apns/images/icon-48-user-add.png);}');
        $document->addStyleDeclaration('.icon-48-users_edit {background-image:
                                url(../media/com_apns/images/icon-48-edit.png);}');
    }
}