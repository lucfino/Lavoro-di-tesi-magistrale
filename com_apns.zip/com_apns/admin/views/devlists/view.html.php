<?php

defined('_JEXEC') or die('Restricted access');

jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.pagination' );

class ApnsViewDevlists extends JView{
    
    function display($tpl = null)
    {
        JHtml::_('behavior.framework');
        JHtml::stylesheet('apns/admin.stylesheet.css', array(), true);

        $this->addToolBar();
        $this->setDocument();
        $this->pagination = $this->get('Pagination');
        $this->items = $this->get('Items');
        $this->state = $this->get('State');
        
        parent::display($tpl);
    }
    
    protected function addToolBar($total=null)
    {
        JToolBarHelper::title( JText::_( 'COM_APNS_DEVLIST_MANAGER' ), 'users' );
        JToolBarHelper::editListX('devlist.edit');
        JToolBarHelper::deleteList( JText::_( 'COM_APNS_DEVLIST_CONFIRM_DELETE' ),'devlists.delete' );
        JToolBarHelper::divider();
        JToolBarHelper::back('Indietro', 'index.php?option=com_apns');
    }
    
    function setDocument()
    {
        $document = JFactory::getDocument();
        $document->addStyleDeclaration('.icon-48-users {background-image:
                                url(../media/com_apns/images/iphone.png);}');
    }
}