<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$option = JRequest::getCmd('option');
$view = JRequest::getCmd('view');
$task = JRequest::getCmd('task');

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');

?>

<form action="index.php" method="post" name="adminForm" id="devlistForm">
	<input type="hidden" name="option" value="<?=$option?>" />
	<input type="hidden" name="task" value="<?=$task?>" />
    <input type="hidden" name="view" value="<?=$view?>" />
    <input type="hidden" name="filter_order" value="<?=$listOrder?>" />
    <input type="hidden" name="filter_order_Dir" value="<?=$listDirn?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <?php echo JHtml::_('form.token'); ?>

	<div id="editcell">
		<table class="adminlist">
			<thead>
				<tr>
					<th width="1%"><input type="checkbox" onclick="Joomla.checkAll(this)" title="<?=JText::_( 'Check All' )?>" value="" name="checkall-toggle"></th>
					<th><?=JHtml::_('grid.sort', 'COM_APNS_APPNAME', 'appName', $listDirn, $listOrder);?></th>
					<th><?=JHtml::_('grid.sort', 'COM_APNS_APPVERSION', 'appversion', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_USER', 'user', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_PUSHBADGE', 'pushBadge', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_BADGECOUNT', 'badgeCount', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_PUSHALERT', 'pushAlert', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_PUSHSOUND', 'pushSound', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_DEVUID', 'devUid', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_DEVNAME', 'devName', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_DEVMODEL', 'devModel', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_DEVSO', 'devSo', $listDirn, $listOrder); ?></th>	
					<th><?=JHtml::_('grid.sort', 'COM_APNS_DEVTOKEN', 'devToken', $listDirn, $listOrder); ?></th>	
				</tr>
			</thead>
			
			<tfoot>
                <tr>
                    <td colspan="13">
                        <?=$this->pagination->getListFooter()?>
                    </td>
                </tr>
            </tfoot>
			
			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){
					$checked = JHTML::_('grid.id', $i++, $row->id );
					$link = JRoute::_( 'index.php?option=' . $option . '&task=devlist.edit&id=' . $row->id );
?>
					<tr class="row<?=$k?>">
						<td><?=$checked?></td>
						<td><a href="<?=$link?>"><?=$row->appName?></a></td>
						<td><a href="<?=$link?>"><?=$row->appVersion?></a></td>
						<td><a href="<?=$link?>"><?=$row->user?></a></td>
						<td><a href="<?=$link?>"><?=$row->pushBadge?></a></td>
						<td><a href="<?=$link?>"><?=$row->badgeCount?></a></td>
						<td><a href="<?=$link?>"><?=$row->pushAlert?></a></td>
						<td><a href="<?=$link?>"><?=$row->pushSound?></a></td>
						<td><a href="<?=$link?>"><?=$row->devUid?></a></td>
						<td><a href="<?=$link?>"><?=$row->devName?></a></td>
						<td><a href="<?=$link?>"><?=$row->devModel?></a></td>
						<td><a href="<?=$link?>"><?=$row->devSo?></a></td>
						<td><a href="<?=$link?>"><?=$row->devToken?></a></td>
					</tr>
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>
</form>