<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

?>

<div class="apns-manager">
	<div class="apns-manager-left">
		
		<div class="apns-icon">
			<div class="apns-inner-icon">
				<a href="<?php echo JRoute::_("index.php?option=com_apns&task=devlists"); ?>">
					<img src="../media/com_apns/images/ios-7-00.jpg" alt="dev list" height="160px" >
					<h2 id="h2GestioneDisp"><?= JText::_( 'COM_APNS_DEV_MANAGER' ) ?></h2>
				</a>
			</div>
		</div>
		
		<div class="apns-icon">
			<div class="apns-inner-icon">
				<a href="<?php echo JRoute::_("index.php?option=com_apns&view=general&layout=edit&id=1"); ?>">
					<img id="imgCertificates" src="../media/com_apns/images/certificates.png" alt="certificates" height="200px">
					<h2 id="h2GestioneCert"><?= JText::_( 'COM_APNS_CERTIFICATES_MANAGER' ) ?></h2>
				</a>
			</div>
		</div>
		
	</div>
</div>