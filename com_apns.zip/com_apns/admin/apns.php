<?php

defined('_JEXEC') or die('Restricted access');
JLoader::register('ApnsHelper', dirname(__FILE__) . DS . 'helpers' . DS . 'apns.php');
Jimport('joomla.application.component.controller');

$controller = JController::getInstance('Apns'); 															
$input = JFactory::getApplication()->input;
$controller->execute($input->getCmd('task'));
$controller->redirect();