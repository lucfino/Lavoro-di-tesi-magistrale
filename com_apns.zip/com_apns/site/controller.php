<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');


class ApnsController extends JController{

	public function display($cachable = false, $urlparams = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Apns'));
		parent::display($cachable);
	}

	public function sendtoall($cachable = false, $urlparams = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Sendtoall'));
		parent::display($cachable);
	}

	public function send($cachable = false, $urlparams = false){
		JRequest::setVar('view', JRequest::getCmd('view', 'Send'));
		parent::display($cachable);
	}
	
}