<?php

defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controlleradmin');

class ApnsControllerSend extends JControllerAdmin{

    private $arrayName;

    public function getModel($name = 'Devlists', $prefix = 'ApnsModel', $config = array())
    {
        return parent::getModel($name, $prefix, $config);
    }


    // manda una notifica a tutti i dispositivi registrati tramite la relativa interfaccia web
    public function sendtoall()
    {
        $model = $this->getModel();
        $items = $model->getAllDevices();
        $tmp = $model->getCertificate();
        $cer = $tmp[0];

        $num_rows = count($items);
        if($num_rows>0){

            if ($cer->certificato == 'Developer')
                $passphrase = $cer->password;
            else
                $passphrase = $cer->passwordPro;

            if (isset($_POST['textArea'])){
                $message = $_POST['textArea'];
            } else {
                $message = 'Nuova notifica';
            }

                $ctx = stream_context_create();
                if ($cer->certificato == 'Developer' && $cer->developer != ""){
                    stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/dev/'.$cer->developer);
                }else if ($cer->certificato == 'Production' && $cer->production != ""){
                    stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/prod/'.$cer->production);
                }else {
                    JFactory::getApplication()->enqueueMessage('Seleziona o carica un certificato', 'error');
                    $this->setRedirect('index.php?option=com_apns&task=sendtoall');
                    $this->redirect();
                }
                stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
                
                $i=0;
                do {
                    
                    $i++;
                    if ($cer->certificato == 'Developer'){
                        $fp = stream_socket_client(
                            'ssl://gateway.sandbox.push.apple.com:2195', $err,
                            $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

                    }else {
                        $fp = stream_socket_client(
                            'ssl://gateway.push.apple.com:2195', $err,
                            $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
                    }

                }while (!$fp || $i==5);

                $result = false;
                foreach ($items as &$row){
                    $body['aps'] = array(
                        'alert' => $message,
                        'sound' => 'default',
                        'badge' => $row->badgeCount+1  );

                    $payload = json_encode($body);
                    $msg = chr(0) . pack('n', 32) . pack('H*', $row->devToken) . pack('n', strlen($payload)) . $payload;
                    $result = fwrite($fp, $msg, strlen($msg));

                    $model->updateBadge($row->devToken, $row->badgeCount+1);
                }

                $application = JFactory::getApplication();
                if (!$result){
                    $application->enqueueMessage(JText::_('COM_APNS_ERROR_MESSAGE'), 'error');
                } else {
                    fclose($fp);
                    $application->enqueueMessage(JText::_('COM_APNS_MESSAGE'));
                }
                
                $this->setRedirect('index.php?option=com_apns&task=sendtoall');
                $this->redirect();


        } else {
            JFactory::getApplication()->enqueueMessage(JText::_('COM_APNS_NO_DEVICE_MESSAGE'), 'error');
            $this->setRedirect('index.php?option=com_apns&task=sendtoall');
            $this->redirect();
        }
    }

    // manda una notifica ai dispositivi selezionati tramite la relativa interfaccia web
    public function send()
    { 
        $model = $this->getModel();
        $tmp = $model->getCertificate();
        $cer = $tmp[0];

        if ($_POST['boxchecked'] != 0){
            $this->arrayName = explode(",", $_POST['boxchecked']);
            $num_rows = count($this->arrayName);
        } else {
            $num_rows=0;
        }

        if($num_rows>0){

            for($j=0; $j<$num_rows; $j++){
                $tmp = explode(";", $this->arrayName[$j]);
                $tmp['devToken'] = $tmp[0]; unset($tmp[0]);
                $tmp['devUid'] = $tmp[1]; unset($tmp[1]);
                $tmp['badgeCount'] = $tmp[2]; unset($tmp[2]);
                $this->arrayName[$j] = (object) $tmp;
            }

            if ($cer->certificato == 'Developer')
                $passphrase = $cer->password;
            else
                $passphrase = $cer->passwordPro;

            if (isset($_POST['textArea'])){
                $message = $_POST['textArea'];
            } else {
                $message = 'Nuova notifica';
            }

            $ctx = stream_context_create();
            if ($cer->certificato == 'Developer' && $cer->developer != ""){
                stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/dev/'.$cer->developer);
            }else if ($cer->certificato == 'Production' && $cer->production != ""){
                stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/prod/'.$cer->production);
            }else {
                JFactory::getApplication()->enqueueMessage('Seleziona o carica un certificato', 'error');
                $this->setRedirect('index.php?option=com_apns&task=sendtoall');
                $this->redirect();
            }
            stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
            
            $i=0;
            do {
                $i++;
                if ($cer->certificato == 'Developer'){
                    $fp = stream_socket_client(
                        'ssl://gateway.sandbox.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

                }else {
                    $fp = stream_socket_client(
                        'ssl://gateway.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
                }

            }while (!$fp || $i==5);

            $result = false;
            foreach ($this->arrayName as &$row){
                $body['aps'] = array(
                    'alert' => $message,
                    'sound' => 'default',
                    'badge' => $row->badgeCount+1  );

                $payload = json_encode($body);
                $msg = chr(0) . pack('n', 32) . pack('H*', $row->devToken) . pack('n', strlen($payload)) . $payload;
                $result = fwrite($fp, $msg, strlen($msg));

                $model->updateBadge($row->devToken, $row->badgeCount+1);
            }

            $application = JFactory::getApplication();
            if (!$result){
                $application->enqueueMessage(JText::_('COM_APNS_ERROR_MESSAGE'), 'error');
            } else {
                fclose($fp);
                $application->enqueueMessage(JText::_('COM_APNS_MESSAGE'));
            }

            $this->setRedirect('index.php?option=com_apns&task=send');
            $this->redirect();
        } else {
            JFactory::getApplication()->enqueueMessage(JText::_('COM_APNS_NO_DEVICE_MESSAGE'), 'error');
            $this->setRedirect('index.php?option=com_apns&task=send');
            $this->redirect();
        }

    }

    // script che consente di mandare una notifica a tutti i dispositivi registrati
    public function do_sendtoall()
    {
        $model = $this->getModel();
        $items = $model->getAllDevices();
        $tmp = $model->getCertificate();
        $cer = $tmp[0];

        $arrayName = array('type' => 'errore');
        $res = array('result' =>  $arrayName);
        
        $num_rows = count($items);
        if($num_rows>0){

            if ($cer->certificato == 'Developer')
                $passphrase = $cer->password;
            else
                $passphrase = $cer->passwordPro;

            if (isset($_GET['textArea'])){
                $message = $_GET['textArea'];
            } else {
                $message = 'Nuova notifica';
            }

                $ctx = stream_context_create();
                if ($cer->certificato == 'Developer' && $cer->developer != ""){
                    stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/dev/'.$cer->developer);
                }else if ($cer->certificato == 'Production' && $cer->production != ""){
                    stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/prod/'.$cer->production);
                }else {
                    die(json_encode($res));
                }
                stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
                
                $i=0;
                do {
                    
                    $i++;
                    if ($cer->certificato == 'Developer'){
                        $fp = stream_socket_client(
                            'ssl://gateway.sandbox.push.apple.com:2195', $err,
                            $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

                    }else {
                        $fp = stream_socket_client(
                            'ssl://gateway.push.apple.com:2195', $err,
                            $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
                    }

                }while (!$fp || $i==5);

                $result = false;
                foreach ($items as &$row){
                    $body['aps'] = array(
                        'alert' => $message,
                        'sound' => 'default',
                        'badge' => $row->badgeCount+1  );

                    $payload = json_encode($body);
                    $msg = chr(0) . pack('n', 32) . pack('H*', $row->devToken) . pack('n', strlen($payload)) . $payload;
                    $result = fwrite($fp, $msg, strlen($msg));

                    $model->updateBadge($row->devToken, $row->badgeCount+1);
                }

                $application = JFactory::getApplication();
                if ($result){
                    $arrayName['type'] = 'ok';
                    $res = array('result' =>  $arrayName);
                    fclose($fp);
                }
                die(json_encode($res));


        } else {
            die(json_encode($res));
        }
    }

    // script che consente di mandare una notifica a tutti i dispositivi loggati con un certo username
    public function do_sendByUser()
    { 
        $model = $this->getModel();
        $tmp = $model->getCertificate();
        $cer = $tmp[0];

        $array = array('type' => 'errore');
        $res = array('result' =>  $array);

        $user = $_GET['user'];
        $this->arrayName = $model->getDevByUser($user);
        $num_rows = count($this->arrayName);

        if($num_rows>0){

            if ($cer->certificato == 'Developer')
                $passphrase = $cer->password;
            else
                $passphrase = $cer->passwordPro;

            if (isset($_GET['textArea'])){
                $message = $_GET['textArea'];
            } else {
                $message = 'Nuova notifica';
            }

            $ctx = stream_context_create();
            if ($cer->certificato == 'Developer' && $cer->developer != ""){
                stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/dev/'.$cer->developer);
            }else if ($cer->certificato == 'Production' && $cer->production != ""){
                stream_context_set_option($ctx, 'ssl', 'local_cert', 'media/com_apns/certificates/prod/'.$cer->production);
            }else {
                die(json_encode($res));
            }
            stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
            
            $i=0;
            do {
                $i++;
                if ($cer->certificato == 'Developer'){
                    $fp = stream_socket_client(
                        'ssl://gateway.sandbox.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

                }else {
                    $fp = stream_socket_client(
                        'ssl://gateway.push.apple.com:2195', $err,
                        $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
                }

            }while (!$fp || $i==5);

            $result = false;
            foreach ($this->arrayName as &$row){
                $body['aps'] = array(
                    'alert' => $message,
                    'sound' => 'default',
                    'badge' => $row->badgeCount+1  );

                $payload = json_encode($body);
                $msg = chr(0) . pack('n', 32) . pack('H*', $row->devToken) . pack('n', strlen($payload)) . $payload;
                $result = fwrite($fp, $msg, strlen($msg));

                $model->updateBadge($row->devToken, $row->badgeCount+1);
            }

            $application = JFactory::getApplication();
            if ($result){
                $arrayName['type'] = 'ok';
                $res = array('result' =>  $arrayName);
                fclose($fp);
            }
            die(json_encode($res));

        } else {
            die(json_encode($res));
        }

    }

}



