<?php

defined('_JEXEC') or die();
jimport( 'joomla.application.component.modellist' );

class ApnsModelDevlists extends JModelList{
    
    public function __construct($config = array())
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = array('devToken');
        }
        parent::__construct($config);
    }
    
    function getListQuery()
    {              
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__apns_devlist');
        $query->order($this->getState('list.ordering', 'id') .
                ' ' . $this->getState('list.direction', 'ASC'));
        return $query;
    }

    protected function populateState($ordering = null, $direction = null)
    {
        $this->setState('list.limit', 0);
    } 

    function addDevice($appName, $appVersion, $pushBadge, $pushAlert, $pushSound, $badgeCount, $devUid, $devName, $devModel, $devSO, $devToken, $user)
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);

        $query = "SELECT `id` FROM `#__apns_devlist` WHERE `devToken` = '" . $devToken ."'";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 

        if (count($results) == 0){
            $insert = "INSERT INTO `#__apns_devlist`(`appName`, `appVersion`, `user`, `pushBadge`, `pushSound`, `pushAlert`, `badgeCount`, `devUid`, `devName`, `devModel`, `devSo`, `devToken`) VALUES ('".$appName."','".$appVersion."','".$user."','".$pushBadge."','".$pushSound."','".$pushAlert."','".$badgeCount."','".$devUid."','".$devName."','".$devModel."','".$devSO."','".$devToken."')";       
            $db->setQuery($insert);
            $db->query();
        }
    }

    function getAllDevices()
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query = "SELECT * FROM `#__apns_devlist`";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function getCertificate()
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query = "SELECT * FROM `#__apns_general`";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }

    function updateBadge($devToken, $badgeCount)
    {

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);

        $query = "SELECT `id` FROM `#__apns_devlist` WHERE `devToken` = '" . $devToken ."'";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 

        if (count($results) != 0){
            $update = "UPDATE `#__apns_devlist` SET `badgeCount`='".$badgeCount."' WHERE `devToken` = '" . $devToken ."'";       
            $db->setQuery($update);
            $db->query();
        } 
    }

    function setUser($user, $devToken)
    {

        $db = JFactory::getDBO();
        $query = $db->getQuery(true);

        $query = "SELECT `id` FROM `#__apns_devlist` WHERE `devToken` = '" . $devToken ."'";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 

        if (count($results) != 0){
            $update = "UPDATE `#__apns_devlist` SET `user`='".$user."' WHERE `devToken` = '" . $devToken ."'";       
            $db->setQuery($update);
            $db->query();
        } 
    }


    function getDevByUser($user)
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query = "SELECT `devToken`, `devUid`, `badgeCount` FROM `#__apns_devlist` WHERE `user`='".$user."'";
        $db->setQuery($query); 
        $results = $db->loadObjectList(); 
        return $results;
    }
}