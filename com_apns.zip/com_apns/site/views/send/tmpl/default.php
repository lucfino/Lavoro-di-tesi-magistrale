<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$listOrder = $this->state->get('list.ordering');
$listDirn = $this->state->get('list.direction');
$all = "";

$document = JFactory::getDocument();
$document->addScript(JURI::base() . './media/com_apns/js/send.js');
$document->addScript(JURI::base() . './media/com_apns/js/jquery-2.0.3.min.js');



?>

<h1><?= JText::_('COM_APNS_SEND_TO_SELECTED') ?></h1>

<jdoc:include type="message" />

<form action='index.php' method="post" name="siteForm" id="sendtoallForm">
	<input type="hidden" name="option" value="com_apns" />
	<input type="hidden" name="task" value="send.send" />
	<input id="check" type="hidden" name="boxchecked" />
    <?php echo JHtml::_('form.token'); ?>

	<textarea class="textAreaSend" name="textArea" rows="10" cols="60">Nuova notifica !</textarea>
  	<input class="buttonSend" type="submit" value='<?= JText::_('COM_APNS_SEND') ?>'>

</form>

<? if (count($this->items) != 0){ 

	foreach($this->items as $item){
		$all .= $item->devToken.";".$item->devUid.";".$item->badgeCount."&";
	}

?>

<h1 id="h1Send"><?= JText::_('COM_APNS_SELECT_DEVICE') ?></h1>

<div id="editcell">
		<table class="sitelist">
			<thead>
				<tr>
					<th width="1%"><input id="checkAll" type="checkbox" name="checkAll" onclick="checkAll(this, '<?=$all?>', '<?=count($this->items)?>')";</th>
					<th><?=JText::_('COM_APNS_APPNAME');?></th>
					<th><?=JText::_('COM_APNS_APPVERSION'); ?></th>	
					<th><?=JText::_('COM_APNS_USER'); ?></th>	
					<th><?=JText::_('COM_APNS_DEVNAME'); ?></th>	
					<th><?=JText::_('COM_APNS_DEVMODEL'); ?></th>	
					<th><?=JText::_('COM_APNS_DEVSO'); ?></th>	
				</tr>
			</thead>
 
			<tbody>
<?
				$k = 0;
				$i = 0;
				foreach ($this->items as &$row){

?>
					<tr class="row<?=$k?>">
						<td>
							<input type="checkbox" name="checkDev" onclick="callSetDevlist('<?=$row->devToken?>', '<?=$row->devUid?>', '<?=$row->badgeCount?>')">
						</td>
						<td><?=$row->appName?></td>
						<td><?=$row->appVersion?></td>
						<td><?=$row->user?></td>
						<td><?=$row->devName?></td>
						<td><?=$row->devModel?></td>
						<td><?=$row->devSo?></td>
					</tr>
<?
					$k = 1 - $k;
				}
?>
			
			</tbody>
		</table>
	</div>

<? } else {?>

<h1 id="h1Send"><?= JText::_('COM_APNS_NO_DEVICE') ?></h1>

<? } ?>
